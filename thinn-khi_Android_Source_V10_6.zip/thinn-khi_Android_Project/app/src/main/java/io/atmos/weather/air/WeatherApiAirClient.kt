package io.atmos.weather.air

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap

/** Optional WeatherAPI.com PM and visibility data, distinct from the weather forecast provider.
 * Never misrepresent US EPA index as Taiwan AQI. Missing key is an explicit "unavailable" state.
 */
data class WeatherApiAirData(val pm25: Double?, val pm10: Double?, val visibilityKm: Double?)
data class WeatherApiAirResult(val data: WeatherApiAirData?, val status: String)
object WeatherApiAirClient {
    private data class CacheEntry(val time: Long, val value: WeatherApiAirResult)
    private val cache=ConcurrentHashMap<String,CacheEntry>()
    suspend fun load(key: String, latitude: Double, longitude: Double): WeatherApiAirResult=withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext WeatherApiAirResult(null,"尚未設定 WeatherAPI 金鑰")
        val cacheKey="${"%.3f".format(java.util.Locale.US,latitude)}:${"%.3f".format(java.util.Locale.US,longitude)}:${key.hashCode()}"
        cache[cacheKey]?.takeIf { System.currentTimeMillis()-it.time < 15*60*1000L }?.let {return@withContext it.value}
        try {
            val q=URLEncoder.encode("$latitude,$longitude","UTF-8")
            val encoded=URLEncoder.encode(key,"UTF-8")
            val conn=(URL("https://api.weatherapi.com/v1/current.json?key=$encoded&q=$q&aqi=yes").openConnection() as HttpURLConnection)
            conn.connectTimeout=12000;conn.readTimeout=15000
            conn.setRequestProperty("Accept","application/json")
            val json=try { conn.inputStream.bufferedReader().use { it.readText() } } finally { conn.disconnect() }
            val current=JSONObject(json).getJSONObject("current")
            val air=current.optJSONObject("air_quality")
            val result=WeatherApiAirResult(WeatherApiAirData(
                air?.optDouble("pm2_5")?.takeUnless {it.isNaN() || it < 0},
                air?.optDouble("pm10")?.takeUnless {it.isNaN() || it < 0},
                current.optDouble("vis_km").takeUnless {it.isNaN() || it < 0}
            ),"WeatherAPI 最新資料 · ${current.optString("last_updated", "更新時間未提供")}")
            cache[cacheKey]=CacheEntry(System.currentTimeMillis(),result)
            result
        } catch (_: Exception) { WeatherApiAirResult(null,"WeatherAPI 暫時無法提供資料，請確認金鑰或網路") }
    }
}
