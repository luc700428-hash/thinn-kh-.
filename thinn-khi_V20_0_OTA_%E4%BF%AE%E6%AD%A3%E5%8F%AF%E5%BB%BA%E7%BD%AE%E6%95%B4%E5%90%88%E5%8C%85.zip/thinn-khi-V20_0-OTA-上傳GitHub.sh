#!/usr/bin/env bash
set -euo pipefail
REPO='luc700428-hash/thinn-kh-.'
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SOURCE='thinn-khi_Android_Source_V20_0_OTA_Compile_Fixed.zip'
WORKFLOW='thinn-khi-V20_0-OTA-FIXED-build-apk.yml'
for cmd in gh git unzip; do
  command -v "$cmd" >/dev/null || { echo "請先安裝 $cmd"; exit 1; }
done
for f in "$SOURCE" "$WORKFLOW"; do
  [[ -s "$DIR/$f" ]] || { echo "缺少 $DIR/$f，請先解壓縮整個下載包"; exit 1; }
done
unzip -tqq "$DIR/$SOURCE"
gh auth status >/dev/null
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
gh repo clone "$REPO" "$TMP_DIR/repo" -- --depth 1
mkdir -p "$TMP_DIR/repo/.github/workflows"
cp "$DIR/$SOURCE" "$TMP_DIR/repo/$SOURCE"
cp "$DIR/$WORKFLOW" "$TMP_DIR/repo/.github/workflows/build-apk.yml"
git -C "$TMP_DIR/repo" add "$SOURCE" .github/workflows/build-apk.yml
if git -C "$TMP_DIR/repo" diff --cached --quiet; then
  echo '儲存庫中的來源檔案已相同，無需再次上傳。'
else
  git -C "$TMP_DIR/repo" -c user.name='thinn-khi OTA' \
    -c user.email='thinn-khi-ota@users.noreply.github.com' \
    commit -m 'Fix V20.0 Kotlin compile and prepare OTA'
  git -C "$TMP_DIR/repo" push origin HEAD:main
fi
echo '已上傳，push 將觸發測試建置。請先確認 Actions 成功，再正式發布 OTA。'
echo "gh run list --repo '$REPO' --workflow build-apk.yml --limit 5"
