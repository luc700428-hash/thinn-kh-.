package io.atmos.weather.earthquake

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot

private val iceBlue = Color(0xFF82E5FF)
private val light = Color.White
private val muted = Color(0xFFC5D6E4)

/** A distinct second page. The Taiwan outline is schematic; station and epicenter markers
 * are rendered ONLY if provider supplied valid geodetic coordinates.
 */
@Composable
fun SeismicLiveMapPage(
    onClose: () -> Unit,
    onSettings: () -> Unit,
    reports: List<EarthquakeReport>,
    onRefreshReports: () -> Unit
) {
    val ctx = LocalContext.current
    val live by ExpTechSeismicService.live.collectAsState()
    var layer by remember { mutableStateOf("綜合") }
    var zoom by remember { mutableFloatStateOf(1f) }
    var selected by remember { mutableStateOf<SeismicStation?>(null) }
    var details by remember { mutableStateOf<EarthquakeReport?>(null) }
    var timestamp by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var waveNow by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var replayStatus by remember { mutableStateOf("") }
    var replayReport by remember { mutableStateOf<EarthquakeReport?>(null) }
    var replayIncident by remember { mutableStateOf<EewIncident?>(null) }
    var replayClock by remember { mutableLongStateOf(0L) }
    val replayScope = rememberCoroutineScope()
    val inReplay = replayStatus == "回放中"
    val devicePlace = remember(timestamp) { SeismicUserLocation.current(ctx) }

    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(5_000)
            timestamp = System.currentTimeMillis()
        }
    }
    val fresh = live.enabled && live.lastRtsAt > 0 && timestamp - live.lastRtsAt in 0..15_000L
    val stations = if (fresh) live.stations.filter { SeismicGeo.visible(it.latitude,it.longitude) } else emptyList()
    val quake = live.incident?.takeIf { SeismicGeo.visible(it.latitude,it.longitude) }
    val incidentRecent = quake != null && timestamp - quake.issuedAtMs in 0..120_000 && !quake.test && !quake.cancelled
    LaunchedEffect(incidentRecent, inReplay) {
        while(incidentRecent && !inReplay) {
            waveNow=System.currentTimeMillis()
            delay(120) // Smooth P/S expanding circles without frequent GPS lookups.
        }
    }
    val latestReport = reports.firstOrNull { SeismicGeo.visible(it.latitude,it.longitude) }
    val displayQuake = if(inReplay) replayIncident else quake.takeIf { incidentRecent }
    val displayReport = if(inReplay) replayReport else latestReport
    val waveLat = if(inReplay) replayReport?.latitude else displayQuake?.latitude
    val waveLon = if(inReplay) replayReport?.longitude else displayQuake?.longitude
    val originMillis = if(inReplay) replayReport?.origin?.toEpochMilli() else displayQuake?.originAtMs
    val wavefront = if(SeismicGeo.visible(waveLat,waveLon) && originMillis!=null)
        SeismicWavePhysics.wavefront(originMillis,if(inReplay)replayClock else waveNow,
            if(inReplay) (replayReport?.depthKm ?: 0.0) else (displayQuake?.depthKm ?: 0.0)) else null

    val maxI = stations.mapNotNull { it.intensity }.maxOrNull()
    val maxPga = stations.mapNotNull { it.accelerationGal }.maxOrNull()
    val pulse by rememberInfiniteTransition(label="seismic marker").animateFloat(
        initialValue=0.18f,targetValue=1f,
        animationSpec=infiniteRepeatable(tween(1900,easing=LinearEasing)),label="pulse")

    Dialog(onDismissRequest=onClose,properties=DialogProperties(usePlatformDefaultWidth=false)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06192D),Color(0xFF123B59),Color(0xFF0B223A))))) {
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick=onClose) { Icon(Icons.Rounded.ArrowBack,"返回地震總覽",tint=light) }
                Column(Modifier.weight(1f)) {
                    Text("臺灣即時地震監測",fontSize=21.sp,fontWeight=FontWeight.Bold,color=light)
                    Text("監測地圖 · TREM-Net／ExpTech EEW",fontSize=11.sp,color=muted)
                }
                IconButton(onClick=onSettings) { Icon(Icons.Rounded.Settings,"地震設定",tint=iceBlue) }
            }
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=15.dp)) {
                MapGlass {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Rounded.RadioButtonChecked,null,tint=if(live.enabled)Color(0xFF58E0A6) else muted,modifier=Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Column(Modifier.weight(1f)) {
                            Text(if(live.enabled) "持續監測已啟動" else "即時監測未啟動",color=light,fontWeight=FontWeight.Bold)
                            Text("EEW：${live.eewStatus}",fontSize=11.sp,color=muted,maxLines=2)
                            Text("RTS：${live.rtsStatus}",fontSize=11.sp,color=muted,maxLines=2)
                        }
                        Button(onClick={if(live.enabled) ExpTechSeismicService.stop(ctx) else ExpTechSeismicService.start(ctx)}) {
                            Text(if(live.enabled)"停止" else "啟動")
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text(if(fresh) "測站資料已更新 · ${formatted(live.lastRtsAt)}" else "測站資料未連線或已逾 15 秒，數值暫不顯示",
                        color=if(fresh)Color(0xFF7FE8BA) else Color(0xFFFFD09E),fontSize=12.sp)
                    Text("提醒位置：${devicePlace?.name ?: "定位資料不可用，請檢查權限或在設定指定地區"} · ${devicePlace?.source ?: "未指定"}",
                        color=iceBlue,fontSize=11.sp)
                    if(inReplay) {
                        Text("歷史資料回放中 · 不是真實地震預警",color=Color(0xFFFFD09E),fontWeight=FontWeight.Bold)
                    } else if(incidentRecent) {
                        Spacer(Modifier.height(7.dp))
                        Text("地震速報：${quake?.epicenter ?: "臺灣附近"}  ·  趴下、掩護、穩住",color=Color(0xFFFFD09E),fontWeight=FontWeight.Bold)
                    } else {
                        Text("暫無已確認的有效即時速報；不代表未發生地震",fontSize=11.sp,color=muted)
                    }
                }
                Spacer(Modifier.height(12.dp))
                MapGlass {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Rounded.History,null,tint=iceBlue)
                        Spacer(Modifier.width(8.dp))
                        Text("歷史地震速報回放",color=light,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                        Button(enabled=reports.isNotEmpty() && replayStatus!="讀取中" && !inReplay,
                            onClick={
                                replayScope.launch {
                                    replayStatus="讀取中";replayReport=null;replayIncident=null
                                    val chosen=reports.take(25).filter { SeismicGeo.visible(it.latitude,it.longitude) }.randomOrNull()
                                    if(chosen==null) { replayStatus="目前沒有可回放的地震報告";return@launch }
                                    val frames=try { SeismicHistoricalReplay.findFor(chosen) } catch (_:Exception) { emptyList() }
                                    if(frames.isEmpty()) {
                                        replayStatus="${chosen.location}：無可核對的歷史速報資料，未執行模擬";return@launch
                                    }
                                    replayReport=chosen;replayIncident=frames.first();replayStatus="回放中"
                                    SeismicSound.play(ctx,SeismicSound.Kind.DRILL_START)
                                    val origin=chosen.origin.toEpochMilli()
                                    // 120 historical seconds accelerated into about 12 seconds.
                                    repeat(80) { step ->
                                        replayClock=origin+step*1500L
                                        replayIncident=frames.filter { it.issuedAtMs<=replayClock }.lastOrNull() ?: frames.first()
                                        delay(150)
                                    }
                                    replayStatus="回放完成（僅供歷史研究）"
                                }
                            }) { Text("隨機回放") }
                    }
                    Spacer(Modifier.height(5.dp))
                    Text("隨機選取近期報告，尋找 ExpTech 封存的同事件 EEW 報次；無對應歷史速報不會造假。",color=muted,fontSize=11.sp)
                    if(replayStatus.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(if(inReplay)"歷史速報回放中 · 非真實警報" else replayStatus,
                            color=if(inReplay)Color(0xFFFFC17C) else iceBlue,fontWeight=FontWeight.Bold,fontSize=12.sp)
                    }
                    if(inReplay) {
                        Text("${replayReport?.location ?: ""} · 第 ${replayIncident?.serial ?: 0} 報 · 加速回放 · 不推送警報",color=muted,fontSize=11.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                MapGlass {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("即時監測地圖",color=light,fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                        Text("示意海岸輪廓",fontSize=10.sp,color=muted)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                        listOf("綜合","測站","震央").forEach { mode ->
                            val active=mode==layer
                            Box(Modifier.clip(RoundedCornerShape(12.dp))
                                .background(if(active)iceBlue.copy(alpha=.22f) else light.copy(alpha=.08f))
                                .border(1.dp,if(active)iceBlue.copy(alpha=.5f) else light.copy(alpha=.1f),RoundedCornerShape(12.dp))
                                .clickable { layer=mode;selected=null }.padding(horizontal=14.dp,vertical=8.dp)) {
                                Text(mode,color=light,fontSize=12.sp,fontWeight=if(active)FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Box(Modifier.fillMaxWidth().height(410.dp).clip(RoundedCornerShape(19.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF0A1D34),Color(0xFF152A41))))) {
                        val pins=if(layer=="震央") emptyList() else stations.take(900)
                        Canvas(Modifier.fillMaxSize().pointerInput(pins,zoom) {
                            detectTapGestures { clicked ->
                                val unscaledX = (clicked.x - size.width*0.5f) / zoom + size.width*0.5f
                                val unscaledY = (clicked.y - size.height*0.5f) / zoom + size.height*0.5f
                                selected = pins.minByOrNull { point ->
                                    val dx = SeismicGeo.x(point.longitude!!)*size.width - unscaledX
                                    val dy = SeismicGeo.y(point.latitude!!)*size.height - unscaledY
                                    hypot(dx,dy)
                                }?.takeIf { point ->
                                    hypot(SeismicGeo.x(point.longitude!!)*size.width-unscaledX,
                                        SeismicGeo.y(point.latitude!!)*size.height-unscaledY) < 32.dp.toPx()/zoom
                                }
                            }
                        }) {
                            withTransform({ scale(zoom,zoom,pivot=Offset(size.width/2f,size.height/2f)) }) {
                                for (i in 0..6) {
                                    val x=(i+.5f)/7f*size.width
                                    drawLine(iceBlue.copy(alpha=.08f),Offset(x,0f),Offset(x,size.height),1.dp.toPx())
                                }
                                for (i in 0..8) {
                                    val y=(i+.5f)/9f*size.height
                                    drawLine(iceBlue.copy(alpha=.08f),Offset(0f,y),Offset(size.width,y),1.dp.toPx())
                                }
                                val path=Path()
                                SeismicGeo.island.forEachIndexed { index,(longitude,latitude) ->
                                    val xx=SeismicGeo.x(longitude)*size.width
                                    val yy=SeismicGeo.y(latitude)*size.height
                                    if(index==0) path.moveTo(xx,yy) else path.lineTo(xx,yy)
                                }
                                path.close()
                                drawPath(path,Color(0xFF184762).copy(alpha=.9f))
                                drawPath(path,iceBlue.copy(alpha=.60f),style=Stroke(1.6.dp.toPx()))
                                // Distinct P (cyan) and S (amber) travel wavefronts. Educational speeds only.
                                if(layer!="測站" && wavefront!=null && waveLat!=null && waveLon!=null) {
                                    val epicenter=Offset(SeismicGeo.x(waveLon)*size.width,SeismicGeo.y(waveLat)*size.height)
                                    val latScale=111.2 * cos(Math.toRadians(waveLat)).coerceAtLeast(.2)
                                    listOf(wavefront.pSurfaceRadiusKm to Color(0xFF68E4FF),
                                        wavefront.sSurfaceRadiusKm to Color(0xFFFFB35B)).forEach { (radius,color) ->
                                        if(radius>0.0) {
                                            val rx=(radius/(latScale*(SeismicGeo.EAST-SeismicGeo.WEST))*size.width).toFloat()
                                            val ry=(radius/(111.2*(SeismicGeo.NORTH-SeismicGeo.SOUTH))*size.height).toFloat()
                                            if(rx.isFinite() && ry.isFinite()) {
                                                drawOval(color.copy(alpha=.75f),
                                                    topLeft=Offset(epicenter.x-rx,epicenter.y-ry),
                                                    size=Size(rx*2f,ry*2f),style=Stroke(2.dp.toPx()))
                                            }
                                        }
                                    }
                                }
                                pins.forEach { station ->
                                    val p=Offset(SeismicGeo.x(station.longitude!!)*size.width,SeismicGeo.y(station.latitude!!)*size.height)
                                    val hue=when {
                                        station.intensity==null -> iceBlue
                                        station.intensity>=5 -> Color(0xFFFF776F)
                                        station.intensity>=3 -> Color(0xFFFFB551)
                                        station.intensity>=1 -> Color(0xFF60CFFF)
                                        else -> Color(0xFF59E8AD)
                                    }
                                    drawCircle(hue.copy(alpha=.20f),6.dp.toPx(),p)
                                    drawCircle(hue,3.1.dp.toPx(),p)
                                }
                                if(layer!="測站") {
                                    val lat=if(inReplay) replayReport?.latitude else if(incidentRecent) quake?.latitude else latestReport?.latitude
                                    val lon=if(inReplay) replayReport?.longitude else if(incidentRecent) quake?.longitude else latestReport?.longitude
                                    if(SeismicGeo.visible(lat,lon)) {
                                        val p=Offset(SeismicGeo.x(lon!!)*size.width,SeismicGeo.y(lat!!)*size.height)
                                        val mark=if(incidentRecent)Color(0xFFFFAB62) else Color(0xFFD3B1FD)
                                        if(incidentRecent && !inReplay) drawCircle(mark.copy(alpha=.55f*(1f-pulse)),(11f+35f*pulse).dp.toPx(),p,style=Stroke(2.dp.toPx()))
                                        drawLine(mark,Offset(p.x-9.dp.toPx(),p.y),Offset(p.x+9.dp.toPx(),p.y),2.dp.toPx())
                                        drawLine(mark,Offset(p.x,p.y-9.dp.toPx()),Offset(p.x,p.y+9.dp.toPx()),2.dp.toPx())
                                        drawCircle(mark,4.dp.toPx(),p)
                                    }
                                }
                            }
                        }
                        Column(Modifier.align(Alignment.TopStart).padding(12.dp)) {
                            Text("TREM-Net 監測",color=light,fontSize=13.sp,fontWeight=FontWeight.Bold)
                            Text("${stations.size} 個有效座標測站",color=muted,fontSize=11.sp)
                        }
                        Column(Modifier.align(Alignment.TopEnd).padding(10.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
                            FilledTonalIconButton(onClick={zoom=(zoom+.25f).coerceAtMost(2.5f)},modifier=Modifier.size(37.dp)) {
                                Icon(Icons.Rounded.Add,"放大")
                            }
                            FilledTonalIconButton(onClick={zoom=(zoom-.25f).coerceAtLeast(1f)},modifier=Modifier.size(37.dp)) {
                                Icon(Icons.Rounded.Remove,"縮小")
                            }
                            FilledTonalIconButton(onClick={zoom=1f;selected=null},modifier=Modifier.size(37.dp)) {
                                Icon(Icons.Rounded.CenterFocusStrong,"重置地圖")
                            }
                        }
                        if (!fresh || (stations.isEmpty() && layer!="震央")) {
                            Text(if(!live.enabled) "點選上方「啟動」開始監測" else if(!fresh) "即時測站資料離線／過期" else "尚未取得可定位的測站資料",
                                color=light,modifier=Modifier.align(Alignment.BottomCenter).padding(12.dp)
                                    .clip(RoundedCornerShape(12.dp)).background(Color(0xC80B223A)).padding(10.dp),fontSize=12.sp)
                        }
                    }
                    Spacer(Modifier.height(9.dp))
                    Text("● 綠色 0　● 藍色 1–2　● 黃色 3–4　● 紅色 5+　✚ 震央",color=muted,fontSize=10.sp)
                    Text("青色圓環 P 波（示意 6 km/s） · 橘色圓環 S 波（示意 3.5 km/s）",color=iceBlue,fontSize=11.sp)
                    Text("波前僅為固定速度教育視覺，不代表實際地質傳播、抵達倒數或預警保證。資料不足時不畫波前。",color=muted,fontSize=11.sp)
                    Text("僅顯示來源提供且座標有效的測站。震度為測站值，非所在縣市震度；地圖輪廓僅供視覺定位。",
                        color=muted,fontSize=11.sp,lineHeight=16.sp)
                    selected?.let { station ->
                        Spacer(Modifier.height(10.dp))
                        HorizontalDivider(color=light.copy(alpha=.15f))
                        Text(station.label,color=light,fontSize=15.sp,fontWeight=FontWeight.Bold)
                        Text("測站代碼 ${station.id}",color=muted,fontSize=11.sp)
                        Text("震度 ${station.intensity?.toString() ?: "未提供"} · 最大加速度 ${station.accelerationGal?.let { "${"%.2f".format(Locale.US,it)} gal" } ?: "未提供"}",color=iceBlue,fontSize=12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    MapGlass(modifier=Modifier.weight(1f)) {
                        Text("有效測站",color=muted,fontSize=11.sp)
                        Text(stations.size.toString(),color=light,fontWeight=FontWeight.Bold,fontSize=28.sp)
                    }
                    MapGlass(modifier=Modifier.weight(1f)) {
                        Text("最大測站震度",color=muted,fontSize=11.sp)
                        Text(maxI?.toString() ?: "—",color=light,fontWeight=FontWeight.Bold,fontSize=28.sp)
                    }
                    MapGlass(modifier=Modifier.weight(1f)) {
                        Text("最大 PGA",color=muted,fontSize=11.sp)
                        Text(maxPga?.let { "%.1f".format(Locale.US,it) } ?: "—",color=light,fontWeight=FontWeight.Bold,fontSize=25.sp)
                        Text("gal",color=muted,fontSize=10.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                MapGlass {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("最近地震報告",color=light,fontSize=17.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                        TextButton(onClick=onRefreshReports) { Text("更新",color=iceBlue) }
                    }
                    if(reports.isEmpty()) Text("尚未取得震後報告，請檢查網路連線",color=muted,fontSize=12.sp)
                    reports.take(8).forEach { report ->
                        HorizontalDivider(color=light.copy(alpha=.12f),modifier=Modifier.padding(vertical=7.dp))
                        Row(Modifier.fillMaxWidth().clickable { details=report }.padding(vertical=3.dp),verticalAlignment=Alignment.CenterVertically) {
                            Box(Modifier.size(46.dp).clip(RoundedCornerShape(13.dp))
                                .background(Color(0xFF235C7C)),contentAlignment=Alignment.Center) {
                                Text("M${"%.1f".format(Locale.US,report.magnitude)}",color=light,fontWeight=FontWeight.Bold,fontSize=12.sp)
                            }
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(report.location,color=light,fontWeight=FontWeight.SemiBold,fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                                Text("${report.origin.atZone(java.time.ZoneId.of("Asia/Taipei")).format(java.time.format.DateTimeFormatter.ofPattern("MM/dd HH:mm"))} · 最大震度 ${report.maxIntensity ?: "未提供"}",color=muted,fontSize=11.sp)
                            }
                            Icon(Icons.Rounded.ChevronRight,"查看詳情",tint=iceBlue)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                MapGlass {
                    Text("速報接收紀錄",color=light,fontSize=17.sp,fontWeight=FontWeight.Bold)
                    Text("僅記錄這次啟動期間實際收到的第三方訊息；測試與取消事件不會觸發真實警報。",
                        color=muted,fontSize=11.sp,lineHeight=17.sp)
                    if(live.recentIncidents.isEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("尚未收到新的速報資料",color=muted,fontSize=12.sp)
                    }
                    live.recentIncidents.take(6).forEach { quake ->
                        HorizontalDivider(color=light.copy(alpha=.12f),modifier=Modifier.padding(vertical=8.dp))
                        Text("${quake.epicenter}  ·  ${quake.magnitude?.let { "M${"%.1f".format(Locale.US,it)}" } ?: "規模未提供"}",
                            color=light,fontWeight=FontWeight.SemiBold,fontSize=12.sp)
                        Text("${formatted(quake.issuedAtMs)}  ·  ${quake.source}  ·  第 ${quake.serial} 報  ·  ${when { quake.test->"演練／測試"; quake.cancelled->"已取消"; else->"速報" }}",
                            color=muted,fontSize=11.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                MapGlass {
                    Text("資料來源及使用提醒",color=light,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("TREM-Net RTS／ExpTech EEW：第三方公開串流。震後報告：ExpTech 彙整資料。無需讓一般使用者輸入個人 CWA 授權碼。",
                        color=muted,fontSize=12.sp,lineHeight=18.sp)
                    Text("離線、資料過期、Android 省電、第三方服務故障，都可能造成預警延遲或漏報；不可取代官方災防告警。地震來襲時，立即趴下、掩護、穩住。",
                        color=Color(0xFFFFD39B),fontSize=12.sp,lineHeight=18.sp)
                    Text("測站位置：${live.stationMetadataStatus}",color=muted,fontSize=11.sp)
                }
                Spacer(Modifier.height(28.dp))
            }
        }
        details?.let { report ->
            AlertDialog(onDismissRequest={details=null},
                title={Text("地震報告 · M${"%.1f".format(Locale.US,report.magnitude)}")},
                text={Column {
                    Text(report.location)
                    Text("震源深度：${report.depthKm?.toString() ?: "未提供"} 公里")
                    Text("最大震度：${report.maxIntensity ?: "未提供"}")
                    Text("時間：${report.origin.atZone(java.time.ZoneId.of("Asia/Taipei"))}")
                    Text("此為震後報告，並非提前預警。")
                }},confirmButton={TextButton(onClick={details=null}) {Text("關閉")} })
        }
    }
}

@Composable
private fun MapGlass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(RoundedCornerShape(23.dp))
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha=.145f),Color.White.copy(alpha=.055f))))
        .border(1.dp,Color.White.copy(alpha=.15f),RoundedCornerShape(23.dp)).padding(14.dp),content=content)
}

private fun formatted(ms:Long):String = SimpleDateFormat("HH:mm:ss",Locale.TAIWAN).format(Date(ms))
