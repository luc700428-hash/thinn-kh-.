#!/usr/bin/env bash
# Manually invoked in Termux: uploads build source and workflow, but NEVER publishes OTA.
set -euo pipefail
repo='luc700428-hash/thinn-kh-.'
archive='thinn-khi_Android_Source_V22_0_ExecutiveSummary_Integrated.zip'
sha='9eb44c91f7b21248c5689f33134d6cfc84d02fec22082d4e4202e85197d04ab7'
for bin in gh git unzip sha256sum; do
    command -v "$bin" >/dev/null || { echo "缺少 $bin；請先在 Termux 安裝"; exit 2; }
done
gh auth status >/dev/null || { echo '請先 gh auth login'; exit 2; }
# The user downloads the exact zip bundle from ChatGPT into Android Download, or runs in
# the extracted bundle directory; neither path accepts untrusted paths/URLs.
base="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -s "$base/$archive" && -s "$base/.github/workflows/build-apk.yml" ]]; then
    payload="$base"
else
    echo '請先將完整交付包解壓至 deploy-to-github.sh 同一個資料夾。'; exit 2
fi
printf '%s  %s\n' "$sha" "$payload/$archive" | sha256sum -c -
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
# Auth is handled by GitHub CLI; don't put tokens in the script.
gh auth setup-git
git clone --depth 1 "https://github.com/$repo.git" "$work/repo"
cp "$payload/$archive" "$work/repo/$archive"
mkdir -p "$work/repo/.github/workflows"
cp "$payload/.github/workflows/build-apk.yml" "$work/repo/.github/workflows/build-apk.yml"
cd "$work/repo"
git add "$archive" .github/workflows/build-apk.yml
if git diff --cached --quiet; then echo '原始碼與工作流程已是最新版，無須重複上傳。'; exit 0; fi
# Use local Git author profile, never hardcode an email address.
git -c user.name='thinn-khì Termux publisher' -c user.email='termux@users.noreply.github.com' \
  commit -m 'feat: integrate audited thinn-khi executive summary source and public OTA'
git push origin HEAD:main
echo '已將原始碼與工作流程推送到 GitHub，僅開始 CI 測試；尚未發布正式 OTA。'
echo "請先使用：gh workflow run build-apk.yml --repo '$repo' --ref main -f publish_release=false"
