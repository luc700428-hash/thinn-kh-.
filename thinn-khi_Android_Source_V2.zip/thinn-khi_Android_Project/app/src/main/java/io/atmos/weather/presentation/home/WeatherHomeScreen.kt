package io.atmos.weather.presentation.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import io.atmos.weather.R
import io.atmos.weather.audio.WeatherAudio
import io.atmos.weather.alerts.CwaWarningFeed
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.atmos.weather.domain.model.*
import io.atmos.weather.domain.visual.*
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.cos

private val White = Color.White
private val TextSoft = Color.White.copy(alpha = .77f)
private val GlassShape = RoundedCornerShape(30.dp)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherHomeScreen(viewModel: WeatherViewModel, onLocate: () -> Unit, onOpen3D: (WeatherScene?)->Unit) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snapshot = state.weather
    val isNight = snapshot?.isDay == false
    val stormy = snapshot?.condition == WeatherCondition.THUNDERSTORM
    val rainy = snapshot?.condition in setOf(WeatherCondition.RAIN,WeatherCondition.THUNDERSTORM)
    val heavyRain = snapshot?.weatherCode in setOf(65,67,82,95,96,99)
    val snow = snapshot?.condition == WeatherCondition.SNOW
    val colors = when {
        stormy -> listOf(Color(0xFF0C1930), Color(0xFF273E59), Color(0xFF526E86))
        isNight -> listOf(Color(0xFF071328), Color(0xFF1B3556), Color(0xFF465776))
        rainy -> listOf(Color(0xFF102F48), Color(0xFF386883), Color(0xFF82A6B6))
        snow -> listOf(Color(0xFF4A7296), Color(0xFF88AEC8), Color(0xFFCAE2F0))
        else -> listOf(Color(0xFF1F67A0), Color(0xFF64B5DD), Color(0xFFA8DDEC))
    }
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val settingsPrefs = remember { context.getSharedPreferences("thinn_settings", android.content.Context.MODE_PRIVATE) }
    var locationOpen by remember { mutableStateOf(false) }
    var settingsOpen by remember { mutableStateOf(false) }
    var soundOn by remember { mutableStateOf(settingsPrefs.getBoolean("sound_enabled", false)) }
    var soundVolume by remember { mutableFloatStateOf(settingsPrefs.getFloat("sound_volume", .28f)) }
    WeatherAudio(snapshot?.condition, soundOn, soundVolume)
    var details by remember { mutableStateOf<Pair<String,String>?>(null) }
    val transition = rememberInfiniteTransition(label="sky")
    val motion by transition.animateFloat(0f,1f,infiniteRepeatable(tween(11500, easing=LinearEasing)), label="weather motion")

    MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFFB5EDFF))) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(colors))) {
            Box(Modifier.fillMaxWidth().height(340.dp).offset(x=110.dp,y=(-130).dp)
                .blur(92.dp).background(Color.White.copy(alpha=if (isNight) .03f else .2f),CircleShape))
            AtmosphereCanvas(snapshot?.condition ?: WeatherCondition.CLEAR, isNight, motion, Modifier.fillMaxSize())
            if (snapshot != null) SkyParticles(snapshot.condition, motion, heavyRain, Modifier.fillMaxSize())
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal=20.dp).padding(top=42.dp,bottom=36.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically,
                    horizontalArrangement=Arrangement.SpaceBetween) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Image(painterResource(R.drawable.brand_mark),"thinn-khì 品牌圖示",modifier=Modifier.size(37.dp).clip(RoundedCornerShape(12.dp)))
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("thinn-khì",color=White,fontWeight=FontWeight.SemiBold,fontSize=19.sp,letterSpacing=.4.sp)
                            Text("即時天氣 · 每一刻都有溫度",color=TextSoft,fontSize=10.sp)
                        }
                    }
                    Row {
                        HeaderButton(Icons.Rounded.Search,"搜尋城市") { locationOpen=true }
                        Spacer(Modifier.width(8.dp))
                        HeaderButton(Icons.Rounded.Settings,"設定與環境音") { settingsOpen=true }
                        Spacer(Modifier.width(8.dp))
                        HeaderButton(Icons.Rounded.Refresh,"更新資料") { viewModel.onIntent(WeatherIntent.Refresh) }
                    }
                }
                Spacer(Modifier.height(28.dp))
                // Weather, real place name and landmark form ONE immersive hero.
                Row(Modifier.fillMaxWidth().clickable { locationOpen=true },
                    horizontalArrangement=Arrangement.Center, verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Place,null,tint=White.copy(alpha=.87f),modifier=Modifier.size(17.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(state.city.name,color=White,fontSize=22.sp,fontWeight=FontWeight.Medium,maxLines=2,textAlign=TextAlign.Center)
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Rounded.KeyboardArrowDown,null,tint=White,modifier=Modifier.size(18.dp))
                }
                Spacer(Modifier.height(6.dp))
                if (snapshot != null) {
                    Text("${snapshot.temperatureC.roundToInt()}°",fontSize=104.sp,lineHeight=106.sp,
                        fontWeight=FontWeight.Thin,color=White,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
                    Text(if(heavyRain && !stormy) "強降雨" else snapshot.condition.label(),color=White,fontSize=18.sp,fontWeight=FontWeight.Medium,
                        modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
                    Spacer(Modifier.height(7.dp))
                    Text("最高 ${snapshot.maxTempC?.roundToInt()?.let { "$it°" } ?: "—"}   最低 ${snapshot.minTempC?.roundToInt()?.let { "$it°" } ?: "—"}     體感 ${snapshot.feelsLikeC?.roundToInt()?.let { "$it°" } ?: "—"}",
                        color=TextSoft,fontSize=14.sp,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
                } else if(state.loading) {
                    Spacer(Modifier.height(60.dp)); CircularProgressIndicator(color=White,modifier=Modifier.align(Alignment.CenterHorizontally))
                } else {
                    Text("尚無天氣資料，請檢查網路連線",color=White,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(6.dp))
                Box(Modifier.fillMaxWidth()) {
                    LandmarkCanvas(state.scene, motion, Modifier.fillMaxWidth().height(258.dp))
                    Box(Modifier.align(Alignment.BottomCenter).clip(CircleShape)
                        .background(Color(0xFF0A243D).copy(alpha=.42f))
                        .border(1.dp,White.copy(alpha=.24f),CircleShape)
                        .clickable { onOpen3D(state.scene) }.padding(horizontal=18.dp, vertical=9.dp)) {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Refresh,null,tint=White,modifier=Modifier.size(17.dp))
                            Spacer(Modifier.width(7.dp))
                            Text("${state.scene?.landmark?.label() ?: "微縮景觀"}   ·   3D 探索",color=White,fontSize=12.sp)
                        }
                    }
                }
                Spacer(Modifier.height(26.dp))
                if (state.city.name.startsWith("台灣") || state.city.name.startsWith("臺灣")) {
                    if (state.cwaWarnings.isNotEmpty()) {
                        val warning = state.cwaWarnings.first()
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                            .background(Color(0xFF9C3434).copy(alpha=.50f))
                            .border(1.dp,Color(0xFFFFC6AF).copy(alpha=.55f),RoundedCornerShape(22.dp))
                            .clickable { uriHandler.openUri(warning.link) }.padding(16.dp)) {
                            Row(verticalAlignment=Alignment.CenterVertically) {
                                Icon(Icons.Rounded.WarningAmber,null,tint=Color(0xFFFFD8B3),modifier=Modifier.size(20.dp))
                                Spacer(Modifier.width(7.dp))
                                Text("中央氣象署 · 近期警特報",color=White,fontWeight=FontWeight.Bold,fontSize=13.sp)
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(warning.title,color=White,fontSize=14.sp,fontWeight=FontWeight.Medium)
                            Text("請點擊查看官方原文及有效時間",color=TextSoft,fontSize=11.sp)
                        }
                    } else {
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(21.dp))
                            .background(White.copy(alpha=.10f)).border(1.dp,White.copy(alpha=.18f),RoundedCornerShape(21.dp))
                            .clickable { uriHandler.openUri(CwaWarningFeed.OFFICIAL_URL) }
                            .padding(horizontal=16.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically) {
                            Icon(Icons.Rounded.NotificationsActive,null,tint=White.copy(alpha=.83f),modifier=Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("中央氣象署警特報",color=White,fontSize=13.sp,fontWeight=FontWeight.Medium)
                                Text("查看官方最新資訊 · 非無警報保證",color=TextSoft,fontSize=11.sp)
                            }
                            Icon(Icons.Rounded.ChevronRight,null,tint=TextSoft,modifier=Modifier.size(18.dp))
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
                if(snapshot != null) {
                    GlassCard {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Schedule,null,tint=White.copy(alpha=.8f),modifier=Modifier.size(17.dp))
                            Spacer(Modifier.width(8.dp)); Text("未來 24 小時",fontSize=14.sp,color=White,fontWeight=FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(13.dp))
                        LazyRow(horizontalArrangement=Arrangement.spacedBy(17.dp)) {
                            items(snapshot.nextHours.filterIndexed { index,_ -> index % 2 == 0 }.take(12)) { hour ->
                                val hourLabel = hour.at.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
                                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                                    Text(hourLabel,color=TextSoft,fontSize=11.sp)
                                    Spacer(Modifier.height(10.dp))
                                    Icon(if(rainy) Icons.Rounded.WaterDrop else Icons.Rounded.WbSunny,null,
                                        tint=White,modifier=Modifier.size(19.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("${hour.temperatureC?.roundToInt() ?: "—"}°",color=White,fontSize=15.sp,fontWeight=FontWeight.SemiBold)
                                    Spacer(Modifier.height(5.dp))
                                    Text("${hour.precipitationProbabilityPct ?: "—"}%",color=Color(0xFFD8F3FF),fontSize=10.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(15.dp))
                        TemperatureCurve(snapshot.nextHours.take(24),Modifier.fillMaxWidth().height(68.dp))
                    }
                    Spacer(Modifier.height(15.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        MetricCard("濕度",snapshot.humidityPct?.let { "$it%" } ?: "—", "相對濕度", Icons.Rounded.WaterDrop, Modifier.weight(1f)) { details="濕度" to "目前空氣的相對濕度，數值越高通常體感越潮濕。" }
                        MetricCard("降雨機率",snapshot.nextHourRainProbabilityPct?.let { "$it%" } ?: "—", "下一小時",Icons.Rounded.Umbrella,Modifier.weight(1f)) { details="降雨機率" to "逐小時降雨機率為氣象模型預測，並非實際降雨量。" }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        MetricCard("風速",snapshot.windKmh?.let { "${it.roundToInt()}" } ?: "—", "km/h",Icons.Rounded.Air,Modifier.weight(1f)) { details="風速" to "地表約 10 公尺高度的預報風速，單位為公里每小時。" }
                        MetricCard("氣壓",snapshot.pressureHpa?.let { "${it.roundToInt()}" } ?: "—", "hPa",Icons.Rounded.Speed,Modifier.weight(1f)) { details="氣壓" to "目前地表氣壓，單位為百帕。" }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        MetricCard("紫外線",snapshot.currentUv?.let { String.format("%.1f",it) } ?: "—","UV Index",Icons.Rounded.WbSunny,Modifier.weight(1f)) { details="紫外線指數" to "UV 指數越高，外出時越需要注意遮陽與防曬。" }
                        MetricCard("日出 / 日落", snapshot.sunrise?.atZone(ZoneId.systemDefault())?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: "—",
                            "日落 ${snapshot.sunset?.atZone(ZoneId.systemDefault())?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: "—"}", Icons.Rounded.WbTwilight,Modifier.weight(1f)) { details="日出日落" to "時間會以手機時區顯示，跨時區城市也依此規則。" }
                    }
                }
                if(state.loading && snapshot!=null) {
                    Spacer(Modifier.height(14.dp)); LinearProgressIndicator(Modifier.fillMaxWidth(),color=White)
                }
                if(state.stale || state.error != null) {
                    Spacer(Modifier.height(13.dp))
                    Text(if(state.stale) "目前顯示離線快取，可能已過時" else "更新失敗：${state.error}",
                        color=Color(0xFFFFE4C6),fontSize=13.sp,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
                }
                Spacer(Modifier.height(22.dp))
                Text("數據提供：Open-Meteo.com  ·  依其授權條款使用",color=TextSoft,fontSize=11.sp,
                    modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text("天氣是預測資訊，請以當地官方警報為準。",color=TextSoft,fontSize=11.sp,
                    modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
            }
        }
        if (locationOpen) LocationSheet(state.city,state.searchResults,state.searching,onLocate={onLocate(); locationOpen=false},
            onQuery=viewModel::search, onSelect={ viewModel.onIntent(WeatherIntent.SelectCity(it)); locationOpen=false }, onClose={locationOpen=false})
        if (settingsOpen) ModalBottomSheet(onDismissRequest={settingsOpen=false}, containerColor=Color(0xFF132C46),contentColor=White) {
            Column(Modifier.fillMaxWidth().padding(horizontal=24.dp).padding(bottom=32.dp)) {
                Text("偏好設定",fontSize=24.sp,fontWeight=FontWeight.Bold,color=White)
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.GraphicEq,null,modifier=Modifier.size(23.dp),tint=White)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text("天氣環境音",color=White,fontSize=17.sp); Text("晴天、下雨、雷雨、下雪",color=TextSoft,fontSize=12.sp) }
                    Switch(checked=soundOn,onCheckedChange={ soundOn=it;settingsPrefs.edit().putBoolean("sound_enabled",it).apply() })
                }
                Spacer(Modifier.height(14.dp))
                Text("環境音量 ${(soundVolume*100).roundToInt()}%",color=TextSoft,fontSize=13.sp)
                Slider(value=soundVolume,onValueChange={soundVolume=it},onValueChangeFinished={settingsPrefs.edit().putFloat("sound_volume",soundVolume).apply()})
                Text("僅在 App 前景播放；預設關閉以節省電量。",color=TextSoft,fontSize=12.sp)
                Spacer(Modifier.height(20.dp))
                Text("天氣警特報提醒",color=White,fontSize=17.sp)
                Text("官方 RSS 對照所在地，系統允許通知後每 30 分鐘排程檢查；並非緊急細胞廣播替代品。",color=TextSoft,fontSize=12.sp)
                Spacer(Modifier.height(16.dp))
                TextButton(onClick={uriHandler.openUri(CwaWarningFeed.OFFICIAL_URL)}) { Text("查看中央氣象署官方警報",color=White) }
            }
        }
        details?.let { info -> AlertDialog(onDismissRequest={details=null},
            confirmButton={ TextButton(onClick={details=null}) { Text("了解") } },
            title={Text(info.first)},text={Text(info.second)}) }
    }
}

@Composable
private fun HeaderButton(image: androidx.compose.ui.graphics.vector.ImageVector, description: String, click: ()->Unit) {
    Box(Modifier.size(37.dp).clip(CircleShape).background(White.copy(alpha=.13f))
        .border(1.dp,White.copy(alpha=.16f),CircleShape).clickable(onClick=click), contentAlignment=Alignment.Center) {
        Icon(image,contentDescription=description,tint=White,modifier=Modifier.size(19.dp))
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxWidth().clip(GlassShape)
        .background(Brush.linearGradient(listOf(White.copy(alpha=.22f), White.copy(alpha=.1f))))
        .border(1.dp,White.copy(alpha=.26f),GlassShape).padding(19.dp), content=content)
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String,
                       symbol: androidx.compose.ui.graphics.vector.ImageVector,
                       modifier: Modifier=Modifier, onClick:()->Unit) {
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(White.copy(alpha=.14f))
        .border(1.dp,White.copy(alpha=.23f),RoundedCornerShape(24.dp)).clickable(onClick=onClick).padding(17.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Icon(symbol,contentDescription=null,tint=TextSoft,modifier=Modifier.size(16.dp))
            Spacer(Modifier.width(7.dp))
            Text(title,color=TextSoft,fontSize=12.sp)
        }
        Spacer(Modifier.height(17.dp))
        Text(value,color=White,fontSize=28.sp,fontWeight=FontWeight.Light)
        Text(subtitle,color=TextSoft,fontSize=11.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LocationSheet(selected: WeatherCity, results: List<WeatherCity>, searching: Boolean,
    onLocate: ()->Unit, onQuery:(String)->Unit,onSelect:(WeatherCity)->Unit,onClose:()->Unit) {
    var query by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest=onClose,containerColor=Color(0xFF102A44),contentColor=White) {
        Column(Modifier.fillMaxWidth().padding(horizontal=24.dp).padding(bottom=32.dp)) {
            Text("地點與城市",fontSize=24.sp,fontWeight=FontWeight.Bold,color=White)
            Spacer(Modifier.height(5.dp))
            Text("搜尋全球城市，或切換至目前 GPS 定位",fontSize=12.sp,color=TextSoft)
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(value=query,onValueChange={query=it;onQuery(it)},singleLine=true,
                leadingIcon={Icon(Icons.Rounded.Search,null)},label={Text("搜尋縣市、鄉鎮或國外城市")},modifier=Modifier.fillMaxWidth(),
                colors=OutlinedTextFieldDefaults.colors(focusedTextColor=White,unfocusedTextColor=White,
                    focusedBorderColor=White.copy(alpha=.65f),unfocusedBorderColor=White.copy(alpha=.22f),
                    focusedLabelColor=White,unfocusedLabelColor=TextSoft))
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(White.copy(alpha=.14f)).clickable(onClick=onLocate).padding(15.dp),verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Rounded.MyLocation,null,tint=White)
                Spacer(Modifier.width(12.dp))
                Column {Text("使用目前位置",color=White,fontWeight=FontWeight.Medium); Text("由 GPS 自動辨識所在地名",color=TextSoft,fontSize=12.sp)}
            }
            Spacer(Modifier.height(15.dp))
            if(searching) LinearProgressIndicator(Modifier.fillMaxWidth(),color=White)
            Text(if(query.isNotBlank()) "搜尋結果" else "精選地點",color=TextSoft,fontSize=12.sp)
            Spacer(Modifier.height(5.dp))
            val cities = if(query.trim().length >= 2) results else SampleCities.all
            LazyColumn(modifier=Modifier.heightIn(max=320.dp)) {
                items(cities) { city ->
                    Row(Modifier.fillMaxWidth().clickable { onSelect(city) }.padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Place,null,tint=TextSoft,modifier=Modifier.size(18.dp))
                        Spacer(Modifier.width(12.dp))
                        Text(city.name,color=White,modifier=Modifier.weight(1f),fontSize=15.sp)
                        if(city.id == selected.id) Icon(Icons.Rounded.Check,null,tint=Color(0xFF83E3E5),modifier=Modifier.size(19.dp))
                    }
                    HorizontalDivider(color=White.copy(alpha=.1f))
                }
            }
            if(query.trim().length >= 2 && results.isEmpty() && !searching) Text("沒有搜尋結果，可試試不同名稱",color=TextSoft,fontSize=12.sp)
        }
    }
}

@Composable
private fun TemperatureCurve(hours: List<HourlyWeather>, modifier: Modifier=Modifier) {
    val valid = hours.mapNotNull { it.temperatureC }
    Canvas(modifier) {
        if(valid.size<2) return@Canvas
        val min = valid.minOrNull() ?: 0.0
        val max = valid.maxOrNull() ?: 1.0
        val range = (max-min).coerceAtLeast(2.0)
        val points = valid.mapIndexed { i,value ->
            Offset(i.toFloat()/(valid.size-1)*size.width,
                size.height*.79f-((value-min)/range).toFloat()*size.height*.6f)
        }
        val path=Path().apply { moveTo(points[0].x,points[0].y);points.drop(1).forEach{lineTo(it.x,it.y)} }
        drawPath(path,White.copy(alpha=.8f),style=Stroke(width=3.dp.toPx(),cap=StrokeCap.Round,join=StrokeJoin.Round))
        points.forEach { drawCircle(White.copy(alpha=.87f),2.dp.toPx(),it) }
    }
}

@Composable
private fun AtmosphereCanvas(condition:WeatherCondition, isNight:Boolean, phase:Float, modifier:Modifier=Modifier) {
    Canvas(modifier) {
        val w=size.width; val h=size.height
        if (!isNight && condition != WeatherCondition.THUNDERSTORM) {
            val sun=Offset(w*.80f + sin(phase*6.283f)*w*.025f,h*.12f)
            drawCircle(Brush.radialGradient(listOf(Color(0xFFFFF4B5).copy(alpha=.38f),Color.Transparent),center=sun,radius=w*.57f),radius=w*.57f,center=sun)
            drawCircle(Color(0xFFFFF1BE).copy(alpha=if(condition==WeatherCondition.CLEAR) .76f else .28f),radius=w*.07f,center=sun)
        }
        if (isNight) for(i in 0 until 34) {
            val x=((i*.618033f)%1f)*w
            val y=((i*.2679f)%1f)*h*.65f
            drawCircle(Color.White.copy(alpha=.18f+((i%5)*.10f)),(if(i%7==0) 1.7f else .7f).dp.toPx(),Offset(x,y))
        }
        // Slowly drifting stylized layers, not static gradients.
        val drift=phase*w*.3f
        for(i in 0..3){
            val x=((i*.38f + phase*.15f)%1.55f-0.28f)*w
            val y=h*(.19f+i*.11f)
            drawOval(Color.White.copy(alpha=if(isNight) .035f else .065f),Offset(x,y),Size(w*.65f,h*.068f))
        }
        if(condition == WeatherCondition.THUNDERSTORM && phase>.80f && phase<.825f) {
            drawRect(Color.White.copy(alpha=.18f))
            val x=w*.73f
            val path=Path().apply {moveTo(x,h*.12f);lineTo(x-w*.08f,h*.34f);lineTo(x+w*.01f,h*.33f);lineTo(x-w*.12f,h*.55f)}
            drawPath(path,Color(0xFFD7EFFF),style=Stroke(width=2.8.dp.toPx(),cap=StrokeCap.Round))
        }
    }
}

@Composable
private fun SkyParticles(condition: WeatherCondition, phase:Float, heavyRain:Boolean=false, modifier:Modifier=Modifier) {
    val rainy = condition in setOf(WeatherCondition.RAIN,WeatherCondition.THUNDERSTORM)
    val snowy = condition == WeatherCondition.SNOW
    if(!rainy && !snowy) return
    Canvas(modifier) {
        for(i in 0 until if(condition == WeatherCondition.THUNDERSTORM || heavyRain) 155 else if(rainy) 78 else 48) {
            val x=((i*0.6180339f+.1f)%1f)*size.width
            val y=(((i*0.381966f+phase*(if(rainy) 3.8f else .72f))%1f))*size.height
            if(rainy) drawLine(White.copy(alpha=.17f),Offset(x,y),Offset(x-6.dp.toPx(),y+12.dp.toPx()),1.dp.toPx())
            else drawCircle(White.copy(alpha=.44f),1.8.dp.toPx(),Offset(x,y))
        }
    }
}

@Composable
private fun LandmarkCanvas(scene: WeatherScene?, phase:Float, modifier:Modifier=Modifier) {
    var tilt by remember { mutableFloatStateOf(0f) }
    val animatedTilt by animateFloatAsState(tilt, spring(dampingRatio=Spring.DampingRatioMediumBouncy, stiffness=Spring.StiffnessLow),label="landmark-tilt")
    Canvas(modifier.graphicsLayer { rotationY=animatedTilt; cameraDistance=12f * density }
        .pointerInput(Unit) { detectDragGestures(onDragEnd={tilt=0f}, onDragCancel={tilt=0f}) { change, amount ->
            change.consume();tilt=(tilt+amount.x*.14f).coerceIn(-12f,12f)
        } }) {
        val w=size.width; val h=size.height
        drawCircle(Color.White.copy(alpha=.13f),h*.33f,Offset(w*.52f,h*.51f))
        drawOval(Color(0xFF0A2037).copy(alpha=.18f),Offset(w*.09f,h*.77f),Size(w*.83f,h*.17f))
        drawOval(Color(0xFFB0DBD2).copy(alpha=.68f),Offset(w*.15f,h*.72f),Size(w*.73f,h*.14f))
        val landmark=scene?.landmark ?: LandmarkId.WEATHER_COTTAGE
        when (landmark) {
            LandmarkId.TAIPEI_101 -> drawTaipei101(w,h,scene?.nightLight==1f)
            LandmarkId.TOKYO_SKYTREE -> drawSkytree(w,h)
            LandmarkId.EIFFEL_TOWER -> drawEiffel(w,h)
            LandmarkId.WEATHER_COTTAGE -> drawCottage(w,h,scene?.nightLight==1f,scene?.snowAccumulation ?: 0f)
        }
        if((scene?.precipitationIntensity ?: 0f) > .1f) {
            val snowy=(scene?.snowAccumulation ?: 0f) > .1f
            for(i in 0..24) {
                val x=w*((i*.618f+phase*(if(snowy) .2f else -.08f))%1f)
                val y=h*((i*.37f+phase*(if(snowy) .6f else 2.5f))%1f)
                if(snowy) drawCircle(White.copy(alpha=.78f),2.1.dp.toPx(),Offset(x,y))
                else drawLine(Color.White.copy(alpha=.58f),Offset(x,y),Offset(x-4.dp.toPx(),y+9.dp.toPx()),1.5.dp.toPx())
            }
        }
    }
}

private fun DrawScope.drawTaipei101(w:Float,h:Float,night:Boolean) {
    val front=Color(0xFF5CB9BA);val side=Color(0xFF2F7F92)
    drawRect(Color(0xFF375973),Offset(w*.37f,h*.62f),Size(w*.31f,h*.15f))
    drawRect(Color(0xFF426C78),Offset(w*.43f,h*.24f),Size(w*.18f,h*.39f))
    for(i in 0..7){
        val yy=h*(.25f+i*.047f); val half=w*(.1f-i*.002f)
        val path=Path().apply { moveTo(w*.52f-half,yy);lineTo(w*.52f+half,yy);lineTo(w*.52f+half*.76f,yy+h*.038f);lineTo(w*.52f-half*.76f,yy+h*.038f);close() }
        drawPath(path,front)
        drawLine(White.copy(alpha=.39f),Offset(w*.52f-half,yy),Offset(w*.52f+half,yy),1.dp.toPx())
    }
    drawLine(side,Offset(w*.52f,h*.11f),Offset(w*.52f,h*.24f),5.dp.toPx())
    for(row in 0..7) for(col in 0..2){
        drawRect(if(night) Color(0xFFFFE5A4) else Color(0xFFC3EBEC),
            Offset(w*(.45f+col*.042f),h*(.27f+row*.048f)),Size(w*.018f,h*.011f))
    }
    drawRect(Color(0xFF2A5B72),Offset(w*.41f,h*.65f),Size(w*.23f,h*.11f))
}
private fun DrawScope.drawSkytree(w:Float,h:Float) {
    val c=Color(0xFFE9EEF8);val center=w*.52f
    drawRect(Color(0xFF577D97),Offset(w*.35f,h*.69f),Size(w*.35f,h*.08f))
    drawLine(c,Offset(center-w*.065f,h*.7f),Offset(center-w*.025f,h*.21f),4.dp.toPx())
    drawLine(c,Offset(center+w*.065f,h*.7f),Offset(center+w*.025f,h*.21f),4.dp.toPx())
    drawLine(c,Offset(center,h*.09f),Offset(center,h*.69f),3.dp.toPx())
    for(i in 0..11){ val y=h*(.26f+i*.036f); val x=w*(.025f+.034f*i/12f)
        drawLine(Color(0xFF91BAD7),Offset(center-x,y),Offset(center+x,y),2.dp.toPx()) }
    drawRoundRect(Color(0xFFBDDDE9),Offset(center-w*.11f,h*.28f),Size(w*.22f,h*.065f),androidx.compose.ui.geometry.CornerRadius(12.dp.toPx()))
    drawLine(Color(0xFFB8CFDC),Offset(center,h*.1f),Offset(center,h*.23f),3.dp.toPx())
}
private fun DrawScope.drawEiffel(w:Float,h:Float) {
    val metal=Color(0xFFC18E6A); val center=w*.5f
    drawLine(metal,Offset(center-w*.18f,h*.74f),Offset(center-w*.025f,h*.18f),9.dp.toPx())
    drawLine(metal,Offset(center+w*.18f,h*.74f),Offset(center+w*.025f,h*.18f),9.dp.toPx())
    drawLine(Color(0xFFE8BD96),Offset(center-w*.15f,h*.72f),Offset(center+w*.15f,h*.72f),4.dp.toPx())
    for(i in 0..6){val y=h*(.27f+i*.06f); val width=w*(.036f+i*.018f)
        drawLine(metal,Offset(center-width,y),Offset(center+width,y),3.dp.toPx())
        if(i<6){drawLine(Color(0xFFF3D2AC),Offset(center-width,y),Offset(center+width+w*.01f,y+h*.06f),1.dp.toPx())}}
    drawRect(metal,Offset(center-w*.12f,h*.57f),Size(w*.24f,h*.022f))
    drawLine(metal,Offset(center,h*.11f),Offset(center,h*.21f),4.dp.toPx())
}
private fun DrawScope.drawCottage(w:Float,h:Float,night:Boolean,snow:Float) {
    val x=w*.32f; val y=h*.43f; val rw=w*.36f;val rh=h*.28f
    drawRect(Color(0xFFFFD7AD),Offset(x,y),Size(rw,rh))
    val roof=Path().apply {moveTo(x-w*.07f,y);lineTo(x+rw*.49f,y-h*.17f);lineTo(x+rw+w*.07f,y);close()}
    drawPath(roof,if(snow>.1f) Color(0xFFF3FAFD) else Color(0xFFBD6F67))
    drawRect(Color(0xFF7A9DAB),Offset(x+rw*.37f,y+rh*.49f),Size(rw*.25f,rh*.51f))
    for(i in 0..1){
        drawRoundRect(if(night) Color(0xFFFFECAD) else Color(0xFF98D5E7),Offset(x+rw*(.1f+.64f*i),y+rh*.26f),Size(rw*.15f,rh*.22f),androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
    }
    drawRect(Color(0xFF9E8071),Offset(x+rw*.69f,y-h*.14f),Size(rw*.09f,h*.14f))
    drawCircle(Color(0xFF689E89),h*.074f,Offset(x-w*.05f,y+rh*.75f))
    drawCircle(Color(0xFF77AB93),h*.07f,Offset(x+rw+w*.02f,y+rh*.69f))
}
private fun WeatherCondition.label() = when(this){
    WeatherCondition.CLEAR -> "晴朗";WeatherCondition.PARTLY_CLOUDY -> "晴時多雲"
    WeatherCondition.CLOUDY -> "多雲";WeatherCondition.FOG -> "有霧"
    WeatherCondition.RAIN -> "正在下雨";WeatherCondition.SNOW -> "正在下雪"
    WeatherCondition.THUNDERSTORM -> "雷雨";WeatherCondition.UNKNOWN -> "天氣資訊更新中"
}
private fun LandmarkId.label()=when(this){
    LandmarkId.TAIPEI_101 -> "臺北 101 · 微縮城市"
    LandmarkId.TOKYO_SKYTREE -> "東京晴空塔 · 微縮城市"
    LandmarkId.EIFFEL_TOWER -> "艾菲爾鐵塔 · 微縮城市"
    LandmarkId.WEATHER_COTTAGE -> "微縮氣象小屋"
}
