package io.atmos.weather.widgets

import android.content.Context
import androidx.work.*
import androidx.glance.appwidget.updateAll
import io.atmos.weather.AppContainer
import io.atmos.weather.domain.model.*
import java.util.concurrent.TimeUnit

/** Widgets never run continuously; they update after a foreground refresh or periodic sync. */
object WidgetSync {
    fun schedule(context: Context) {
        val work = PeriodicWorkRequestBuilder<WeatherWidgetWorker>(60, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("weather-widget-hourly",
            ExistingPeriodicWorkPolicy.KEEP, work)
    }
    fun request(context: Context) {
        WorkManager.getInstance(context).enqueueUniqueWork("weather-widget-now", ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<WeatherWidgetWorker>().build())
    }
}
class WeatherWidgetWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("atmos_settings", Context.MODE_PRIVATE)
        val id = prefs.getString("city_id", null)
        val city = SampleCities.all.find { it.id == id } ?: if(id != null && prefs.contains("lat")) {
            WeatherCity(id, prefs.getString("city_name", "我的位置") ?: "我的位置", GeoPoint(
                Double.fromBits(prefs.getLong("lat", 0L)), Double.fromBits(prefs.getLong("lon", 0L))))
        } else SampleCities.all.first()
        val result = AppContainer.repository(applicationContext).load(city, false)
        for (widget in listOf(
            AtmosWidget00(),
            AtmosWidget01(),
            AtmosWidget02(),
            AtmosWidget03(),
            AtmosWidget04(),
            AtmosWidget05(),
            AtmosWidget06(),
            AtmosWidget07(),
            AtmosWidget08(),
            AtmosWidget09(),
            AtmosWidget10(),
            AtmosWidget11(),
            AtmosWidget12(),
            AtmosWidget13(),
            AtmosWidget14(),
            AtmosWidget15(),
            AtmosWidget16(),
            AtmosWidget17(),
            AtmosWidget18(),
            AtmosWidget19(),
            AtmosWidget20(),
            AtmosWidget21(),
            AtmosWidget22(),
            AtmosWidget23(),
            AtmosWidget24()
        )) {
            if (isStopped) return Result.success()
            try { widget.updateAll(applicationContext) }
            catch (_: Exception) { /* Some launchers deny widget updates when inactive */ }
        }
        return if (result is io.atmos.weather.domain.repository.WeatherLoadResult.Failure) Result.retry() else Result.success()
    }
}
