package io.atmos.weather

import android.content.Intent
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import io.atmos.weather.domain.visual.LandmarkId
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max

/** Native real-time 3D viewer: OpenGL ES 2.0, vertex-coloured models baked from source GLBs. */
class LandmarkViewerActivity : ComponentActivity() {
    private var glView: ModelSurface? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val landmark = runCatching { LandmarkId.valueOf(intent.getStringExtra("landmark") ?: "WEATHER_COTTAGE") }
            .getOrDefault(LandmarkId.WEATHER_COTTAGE)
        val night=intent.getBooleanExtra("night",false)
        val snow=intent.getBooleanExtra("snow",false)
        val rain=intent.getBooleanExtra("rain",false)
        setContent {
            Box(Modifier.fillMaxSize().background(if(night) Color(0xFF0C1932) else Color(0xFF689EB4))) {
                AndroidView(modifier=Modifier.fillMaxSize(), factory={context ->
                    ModelSurface(context,landmark,night,snow,rain).also { glView=it }
                })
                Row(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(18.dp),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text("thinn-khì  ·  3D LANDMARK", color=Color.White)
                    TextButton(onClick={ finish() }) { Text("關閉",color=Color.White) }
                }
                Text("左右滑動旋轉 · 真正 3D 微縮地標",color=Color.White,
                    modifier=Modifier.align(Alignment.BottomCenter).padding(32.dp))
            }
        }
    }
    override fun onResume() { super.onResume();glView?.onResume() }
    override fun onPause() { glView?.onPause();super.onPause() }
}
private class ModelSurface(
    context: android.content.Context,
    landmark: LandmarkId,night:Boolean,snow:Boolean,rain:Boolean
) : GLSurfaceView(context) {
    private val drawEngine=LandmarkRenderer(context,landmark,night,snow,rain)
    private var lastX=0f
    init {
        setEGLContextClientVersion(2)
        setRenderer(drawEngine)
        renderMode=RENDERMODE_WHEN_DIRTY
        requestRender()
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when(event.actionMasked) {
            MotionEvent.ACTION_DOWN -> lastX=event.x
            MotionEvent.ACTION_MOVE -> {
                val delta=event.x-lastX; lastX=event.x
                queueEvent { drawEngine.rotation=(drawEngine.rotation+delta*.35f)%360f }
                requestRender()
            }
        }
        return true
    }
}
private class LandmarkRenderer(
    private val context:android.content.Context,
    private val landmark:LandmarkId,
    private val night:Boolean,
    private val snow:Boolean,
    private val rain:Boolean
) : GLSurfaceView.Renderer {
    var rotation:Float=16f
    private val projection=FloatArray(16)
    private val view=FloatArray(16)
    private val mvp=FloatArray(16)
    private val model=FloatArray(16)
    private val mv=FloatArray(16)
    private var program=0
    private var vertexCount=0
    private var vertices:FloatBuffer?=null
    private val vShader="""
        uniform mat4 uMVP;
        attribute vec3 aPosition;
        attribute vec3 aColor;
        varying vec3 vColor;
        void main() { gl_Position=uMVP*vec4(aPosition,1.0); vColor=aColor; }
    """.trimIndent()
    private val fShader="""
        precision mediump float;
        varying vec3 vColor;
        uniform float uNight;
        uniform float uSnow;
        void main() {
            vec3 c = vColor*(1.0-uNight*0.27);
            c=mix(c,vec3(0.95,0.97,1.0),uSnow*0.17);
            gl_FragColor=vec4(c,1.0);
        }
    """.trimIndent()
    private fun shader(type:Int,source:String):Int {
        val id=GLES20.glCreateShader(type)
        GLES20.glShaderSource(id,source)
        GLES20.glCompileShader(id)
        return id
    }
    override fun onSurfaceCreated(gl:GL10?,cfg:EGLConfig?) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vs=shader(GLES20.GL_VERTEX_SHADER,vShader)
        val fs=shader(GLES20.GL_FRAGMENT_SHADER,fShader)
        program=GLES20.glCreateProgram()
        GLES20.glAttachShader(program,vs);GLES20.glAttachShader(program,fs)
        GLES20.glLinkProgram(program)
        GLES20.glDeleteShader(vs);GLES20.glDeleteShader(fs)
        val name=when(landmark){
            LandmarkId.TAIPEI_101 -> "taipei_101"
            LandmarkId.TOKYO_SKYTREE -> "tokyo_skytree"
            LandmarkId.EIFFEL_TOWER -> "eiffel_tower"
            LandmarkId.WEATHER_COTTAGE -> "weather_cottage"
        }
        val bytes=context.assets.open("landmarks/$name.mesh").use{it.readBytes()}
        val buffer=ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        vertexCount=buffer.getInt()
        vertices=ByteBuffer.allocateDirect(bytes.size-4).order(ByteOrder.nativeOrder()).asFloatBuffer().also { dest ->
            while(buffer.remaining()>=4)dest.put(buffer.getFloat())
            dest.position(0)
        }
        val blue=if(night) floatArrayOf(.04f,.075f,.16f) else if(rain) floatArrayOf(.23f,.37f,.52f) else floatArrayOf(.39f,.62f,.73f)
        GLES20.glClearColor(blue[0],blue[1],blue[2],1f)
        Matrix.setLookAtM(view,0,8f,6.2f,10f,0f,2.0f,0f,0f,1f,0f)
    }
    override fun onSurfaceChanged(gl:GL10?,width:Int,height:Int) {
        GLES20.glViewport(0,0,width,height)
        Matrix.perspectiveM(projection,0,39f,width.toFloat()/max(height,1),.1f,100f)
    }
    override fun onDrawFrame(gl:GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val data=vertices ?: return
        if(program==0||vertexCount==0)return
        GLES20.glUseProgram(program)
        Matrix.setIdentityM(model,0)
        Matrix.rotateM(model,0,rotation,0f,1f,0f)
        Matrix.multiplyMM(mv,0,view,0,model,0)
        Matrix.multiplyMM(mvp,0,projection,0,mv,0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"uMVP"),1,false,mvp,0)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uNight"),if(night) 1f else 0f)
        GLES20.glUniform1f(GLES20.glGetUniformLocation(program,"uSnow"),if(snow) 1f else 0f)
        val p=GLES20.glGetAttribLocation(program,"aPosition")
        val c=GLES20.glGetAttribLocation(program,"aColor")
        data.position(0)
        GLES20.glVertexAttribPointer(p,3,GLES20.GL_FLOAT,false,6*4,data)
        GLES20.glEnableVertexAttribArray(p)
        data.position(3)
        GLES20.glVertexAttribPointer(c,3,GLES20.GL_FLOAT,false,6*4,data)
        GLES20.glEnableVertexAttribArray(c)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,vertexCount)
        GLES20.glDisableVertexAttribArray(p);GLES20.glDisableVertexAttribArray(c)
    }
}
