package io.atmos.weather.audio

import android.media.MediaPlayer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import io.atmos.weather.R
import io.atmos.weather.domain.model.WeatherCondition

/** Generated, royalty-free synthesized soundscapes. No playback while activity is backgrounded. */
@Composable
fun WeatherAudio(condition: WeatherCondition?, enabled: Boolean, volume: Float) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val raw = when (condition) {
        WeatherCondition.RAIN -> R.raw.light_rain
        WeatherCondition.THUNDERSTORM -> R.raw.heavy_rain
        WeatherCondition.SNOW -> R.raw.snow_wind
        WeatherCondition.CLEAR, WeatherCondition.PARTLY_CLOUDY -> R.raw.sunny_breeze
        else -> R.raw.snow_wind
    }
    val player = androidx.compose.runtime.remember(raw, enabled, context) {
        if (enabled && condition != null) {
            MediaPlayer.create(context, raw)?.apply { isLooping = true; setVolume(volume, volume) }
        } else null
    }
    androidx.compose.runtime.SideEffect { player?.setVolume(volume, volume) }
    DisposableEffect(player, owner) {
        fun begin() { runCatching { if (player?.isPlaying == false) player.start() } }
        fun stop() { runCatching { if (player?.isPlaying == true) player.pause() } }
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> begin()
                Lifecycle.Event.ON_STOP -> stop()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(observer)
        if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) begin()
        onDispose { owner.lifecycle.removeObserver(observer); stop(); player?.release() }
    }
}
