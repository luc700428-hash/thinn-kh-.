# thinn-khì V2 — 天氣 App Android 原始碼

> **狀態：V2 preview source。尚未在 Android SDK 完整編譯或經實機驗收，不是 APK。**

## 品牌與台灣地名

- App 名稱 `thinn-khì`，有完整圖示（Android Launcher + 首頁）及 Android 12 啟動畫面設定。
- 台灣一律寫成 **「台灣」**，不會顯示「台灣省」、「臺灣省」、「Taiwan, Province of China」。
- 手機 GPS 獲得位置後，Android Geocoder 以繁體中文做反向地理編碼，例如 `台灣 · 嘉義縣 · 民雄鄉`；若無 Geocoder/無網路，台灣使用最近縣市中心作為**近似**備援，並不代表真實區界定位。
- 首次啟動依權限請求定位；手動切換的城市會被保留，不會下次啟動強制覆蓋。沒有權限時仍可搜尋全球城市。

## V2 已寫入的功能

1. **視覺：** 重新設計首頁主視覺，讓地點＋大溫度＋天氣＋微縮地標直接整合；移除頂部城市膠囊列，改成搜尋 / 地點管理 Bottom Sheet。雨 / 雷雨 / 雪 / 日夜對應粒子、雲、光暈、閃電效果，使用 Android 12+ Compose 預設 stretch overscroll。下大雨時使用 WMO 氣象代碼驅動較密集的雨滴。氣象署的「豪雨特報」不得以 WMO 雨碼推測冒充。
2. **城市：** GPS + Geocoder + 搜尋全球城市 + 精選地點清單。台灣地名標準化使用 `LocationLabels`；反向解析失敗會使用明確的近似備援。
3. **中央氣象署警特報：** 使用官方 RSS `https://www.cwa.gov.tw/rss/Data/cwa_warning.xml`，僅顯示內容匹配選定縣市且發布時間在近六小時的警報（**不保證警報目前仍有效；需點擊官方原文確認有效時間**）。半小時 WorkManager 檢查、首次通知權限請求、去重；背景工作可能被系統延後。不是災防告警細胞廣播的替代品；若 RSS 存取失敗仍有官方警報連結，不宣稱「目前無警報」。需在台灣實際測試 RSS 格式、內容、發布時效及不同手機通知行為。
4. **音效：** 四款本地生成的免授權合成音檔（小雨、大雨 / 雷雨、雪天風聲、晴天微風）；可在設定頁開關及調節音量。預設關閉、背景暫停播放。
5. **3D：** 主畫面微縮景觀融入 Hero，點選進入原生 OpenGL ES 3D 檢視器。隨原天氣資料切換夜間 / 雨 / 雪。現有真正建模資產仍為 4 組：台北 101、東京晴空塔、艾菲爾鐵塔和通用氣象小屋。**全台 22 縣市及全世界所有城市的專屬 3D 地標尚未完成**，其他地區會顯示通用小屋，避免冒充不存在的獨有地標。
6. **Widgets：** 25 個 Widget 收納於五大系列，重新產出 25 張獨立高解析漸層磨砂玻璃風格背景（預算電量與 Glance/RemoteViews 限制），並透過相同氣象資料快取更新。這是**預渲染玻璃視覺**，不是桌布後景即時模糊或在桌面運行的 60fps 3D。

## 編譯 V2 APK

你原本 GitHub repo 已可使用 Actions。請：

1. 將 `thinn-khi_Android_Source_V2.zip` 上傳到 repo **根目錄**（不是只貼一個解壓後的子檔案）。
2. 將現有 `.github/workflows/build-apk.yml` 的全部內容替換為附帶的 `thinn-khi-V2-build-apk.yml`（兩者 ZIP 內的路徑設定一致）。
3. 儲存到 `main`；Actions 成功時 Artifacts `thinn-khi-V2-APK` 包含 `app-debug.apk`。
4. 若出現紅色失敗，下載 `thinn-khi-V2-build-errors` 內 `compiler-errors.txt` 才能精確修正。**未實測編譯成功不可視為已交付可安裝 APK。**

### 安裝和升級提醒

原本 V1 的 applicationId 仍為 `io.atmos.weather`，V2 versionCode 為 4。GitHub Actions 的 debug 簽署金鑰可能與前次不同，如更新出現簽章不符，需先移除舊測試版再安裝（會清除舊版 App 儲存的地點/設定）。正式發行需要固定私有簽署金鑰並妥善保護。

## 專案規格與限制

- Kotlin、Compose、Glance、Open-Meteo、OpenGL ES 2.0、WorkManager；Android 12+（minSDK 31）。
- Open-Meteo 免費存取並不自動授權商用，正式商業發布前需取得合適的方案和使用條款授權。
- 沒有營運後端與伺服器級推播，不保證即時警報抵達。
- 虛擬 3D 地標、量測雨雪等渲染效果是簡化視覺，沒有完成全球每城專屬模型。
- 高風險天氣請以中央氣象署與政府緊急通知為準。

## 開發驗證

純 Kotlin 台灣地名格式化 smoke test、29 個資源 XML 的 parser 檢查、PNG / GLB 格式驗證已通過。無 Android SDK 所以 **未做 APK 編譯、UI 自動化或機種/品牌 Widget 相容性測試**。
