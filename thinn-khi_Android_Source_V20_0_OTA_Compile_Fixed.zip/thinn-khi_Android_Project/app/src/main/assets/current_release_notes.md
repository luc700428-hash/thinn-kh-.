# thinn-khì V20.0

<!-- THINN_INCREMENTAL_CHANGES -->
- 新增：台澎金馬地震監測地圖與歷史速報回放控制。
- 改善：P／S 波視覺示意、Liquid Glass 互動與四分頁滑動。
- 修復：天氣首頁 Kotlin 編譯錯誤、CWA 地震報告授權參數、版本差異顯示及美國 AQI 空氣品質提醒。
<!-- END_THINN_INCREMENTAL_CHANGES -->
