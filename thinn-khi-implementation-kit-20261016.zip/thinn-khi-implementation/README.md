# thinn-khì App｜完整需求研究與可測實作包

此包針對使用者上傳的《執行摘要.docx》及既有專案 `luc700428-hash/thinn-kh-.` V22，提供可測的 Kotlin/Node 實作核心、Android UI/通知整合樣板、雷達網頁、逐段需求清單和驗收規格。

## 本包 **不是** 正式升級 APK

既有 GitHub 專案將 Android 原始碼包封裝於 ZIP，由 `.github/workflows/build-apk.yml` 解壓建置；本次 GitHub connector 讀取成功，但 `create_branch` 寫入回應 HTTP 403 `Resource not accessible by integration`。因此**不能**把本地 ZIP 假裝為已提交 GitHub 的 App 更新。仍需取得既有原始碼、人工審閱並完成 Android 工程整合、實機測試與原金鑰簽章。

## 檔案

- `android-core/.../WeatherLogic.kt`：完整可獨立 Kotlin 編譯的穿搭規則、地震來源隔離、測站更新、天氣配色、觸覺設定與 10 秒演練狀態。
- `backend/src/eew.mjs`：可信來源約束、HMAC 驗證、即時有效時間、FCM 高優先 payload、不混淆演練與正式事件。
- `backend/src/rainviewer.mjs`：2026 版 Radar 歷史實況 API 解析、主機白名單、定期快取、圖塊 URL 驗證。
- `backend/src/outfit-ai.mjs`：可配置 Ollama/Qwen 的精簡穿搭建議，網路失敗即使用規則引擎。
- `android-integration/*.kt`：Compose 頁面、分頁、station pulse、回顧警告、觸覺設定、Android 高優先通知、TTS、版本更新中心及 2×1/2×2 Widget 參考實作；**尚未針對 V22 專案編譯**。
- `web/radar.html`：Leaflet + 雷達歷史影像時間軸 + 未來 3 小時數值降雨預報（明示非衛星 nowcast）。衛星按鈕在真正可用前為 disabled，不裝飾偽功能。
- `docs/實作與驗收總表.md`：全部類別驗收點與 API/平台限制。
- `docs/逐段需求盤點.csv`：原 DOCX 每個有內容段落、表格項目的索引與交付狀態。
- `tools/test-core.sh`：本地測試。

## 測試（已實際執行）

```bash
bash tools/test-core.sh
```

需已安裝 JDK、Kotlin CLI、Node 20+；執行 Kotlin 核心與 Node 後端測試。不要將這個結果誤解成 Android APK 已建置。

## 整合至 V22（必須依原工程確認）

1. 從官方 repository 原有 `thinn-khi_V22_0_Gradle…OTA….zip` 的內層 `thinn-khi_Android_Source_V22_0_GradleDSL_Fixed.zip` 解壓，確認工程根目錄為 `thinn-khi_Android_Project/`，**不應替換原有 keystore 或更改 package ID**。
2. 將 `android-core/src/main/kotlin/io/atmos/weather/core/WeatherLogic.kt` 放入 `app/src/main/java/io/atmos/weather/core/`；核心僅 Kotlin 標準庫。
3. 將 `android-integration` 的 Compose/通知/TTS 樣板與既有 `ThinnFirebaseMessagingService.kt`、路由、res 與設定儲存整合。Firebase receiver 只能維持一套，避免重複通知。
4. `widget-res` 中的三類 XML 必須合併到既有 `res/layout`、`res/xml`、`res/drawable`，並加入 `widget-manifest-snippet.xml`，再接上既有天氣資料更新工作。Widget 無天氣資料時須顯示「尚無天氣資料」，不可編造數值。
5. 雷達介面須以正式地圖方案及安全 WebView 設定（或改原生 Compose/Map SDK）串接；不要直接在 WebView 中暴露 CWA API key。
6. 針對 RainViewer 的非商用授權、OpenStreetMap tiles policy、CWA 授權碼與開源模型授權做正式上架前審查。
7. Kotlin/JVM、後端、Gradle、Android instrumentation、通知權限/前後台、Widget 及 UI 無障礙測試通過後，才能沿用原版號規則與原簽章金鑰進行 OTA 發布。

## 重要限制

官方 EEW 經授權資料來源、FCM 配置/正式權杖、真實衛星圖層來源、GitHub 可寫入授權和原 APK 更新簽章都沒有被本次獨立程式包取代。無上述整合/授權時，任何宣稱「功能已全部完成／可立即 OTA」都是不正確的。
