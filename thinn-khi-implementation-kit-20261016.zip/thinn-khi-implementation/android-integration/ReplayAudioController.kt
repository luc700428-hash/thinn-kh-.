package io.atmos.weather.integration

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Play on user-requested replay; only foreground UI should call this, never a silent background auto-play. */
class ReplayAudioController(private val context:Context) {
    private var player:MediaPlayer?=null
    private var voice:TextToSpeech?=null
    fun playReplayAlert(soundResourceId:Int, message:String="歷史地震回顧演練，非即時警報") {
        stop()
        player=MediaPlayer.create(context,soundResourceId)?.apply {
            setOnCompletionListener { it.release(); if(player===it)player=null }
            start()
        }
        voice=TextToSpeech(context) {status->
            if(status==TextToSpeech.SUCCESS) {
                voice?.language=Locale.TAIWAN
                voice?.speak(message,TextToSpeech.QUEUE_FLUSH,null,"thinn-replay")
            }
        }
    }
    fun stop() {
        player?.let { if(it.isPlaying) it.stop();it.release() }
        player=null
        voice?.stop();voice?.shutdown();voice=null
    }
}
