package io.atmos.weather.integration

// Template: merge into existing FirebaseMessagingService/notification architecture;
// do not register a second receiver or duplicate notifications on background FCM delivery.
import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Proper user-visible heads-up alert with platform permission checks; no bypass of Android 14 FSI rules. */
class EewNotificationPresenter(private val context: Context) {
    private val manager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val channel="earthquake_alert"
    fun setupChannel() {
        if(Build.VERSION.SDK_INT >= 26) {
            val newChannel=NotificationChannel(channel,"地震安全警報",NotificationManager.IMPORTANCE_HIGH)
            newChannel.description="僅用於可信任來源的即時地震資訊"
            newChannel.enableVibration(true)
            // Sound and voice behavior require an in-app foreground controller, not a forbidden background TTS launch.
            manager.createNotificationChannel(newChannel)
        }
    }
    fun showTrustedEew(eventId:String, place:String, intensity:Double, openAlertIntent:Intent):Boolean {
        setupChannel()
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(context,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            return false
        val pending=PendingIntent.getActivity(context,eventId.hashCode(),openAlertIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n=NotificationCompat.Builder(context,channel)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("緊急地震速報")
            .setContentText("$place 預估震度 $intensity；預警估計可能有誤差及盲區")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pending)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
        NotificationManagerCompat.from(context).notify(eventId.hashCode(),n)
        return true
    }
}
