package io.atmos.weather.integration

// Reference integration; review against the existing project's Compose and Material dependencies.
// This file is not included in the portable Kotlin test: it requires Android SDK/Compose build.

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.atmos.weather.core.*

private fun Long.argb() = Color(this.toULong())

@Composable
fun WeatherGlassPage(
    mood: WeatherMood, dark: Boolean, title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = WeatherTheme.palette(mood, dark)
    Column(Modifier.fillMaxSize().background(p.background.argb()).padding(16.dp)) {
        Text(title, fontSize=24.sp, color=p.primaryText.argb(), style=MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(p.surface.argb()).padding(16.dp),
            content=content
        )
    }
}

@Composable
fun WeatherBottomTabs(selected: Int, onSelect: (Int)->Unit, onHaptic:()->Unit) {
    val names=listOf("天氣", "地震", "工具", "設定")
    NavigationBar(containerColor=MaterialTheme.colorScheme.surface.copy(alpha=.82f)) {
        names.forEachIndexed { index, label ->
            NavigationBarItem(
                selected=selected==index,
                onClick={onHaptic(); onSelect(index)},
                icon={Text(listOf("☀", "≋", "◇", "⚙")[index], fontSize=24.sp)},
                label={Text(label, fontSize=13.sp)},
                modifier=Modifier.sizeIn(minWidth=48.dp,minHeight=48.dp)
                    .semantics { contentDescription="切換到${label}分頁" }
            )
        }
    }
}

@Composable
fun OutfitCompactCard(snapshot: WeatherSnapshot, activity: ActivityType,
                      onActivityChanged:(ActivityType)->Unit, onDetails:()->Unit) {
    val result=remember(snapshot,activity){OutfitRules.advise(snapshot,activity)}
    Column(Modifier.fillMaxWidth(), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text(result.headline, style=MaterialTheme.typography.titleLarge)
        Text(result.advice, style=MaterialTheme.typography.bodyLarge)
        if(result.reminders.isNotEmpty()) Text(result.reminders.joinToString("・"), style=MaterialTheme.typography.bodyLarge)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf(ActivityType.COMMUTE to "通勤", ActivityType.EXERCISE to "運動", ActivityType.LEISURE to "休閒").forEach {(key,label)->
                FilterChip(selected=activity==key, onClick={onActivityChanged(key)},
                    label={Text(label, fontSize=14.sp)})
            }
        }
        TextButton(onClick=onDetails, modifier=Modifier.sizeIn(minHeight=48.dp)) {Text("更多資訊")}
    }
}

@Composable
fun StationMonitor(stations:List<SeismicStation>, refreshedIds:Set<String>, lastUpdated:String) {
    Column {
        Text("監測中・更新 $lastUpdated", style=MaterialTheme.typography.titleMedium)
        LazyColumn {
            items(stations,key={it.id}) {s->
                var pulse by remember(s.id) { mutableStateOf(false) }
                LaunchedEffect(s.observationEpochMillis, s.id in refreshedIds) {
                    if(s.id in refreshedIds) {pulse=true; kotlinx.coroutines.delay(280);pulse=false}
                }
                val opacity by animateFloatAsState(if(pulse) .48f else 1f,label="測站刷新閃爍")
                Row(Modifier.fillMaxWidth().heightIn(min=56.dp).alpha(opacity).padding(vertical=8.dp),
                    horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(s.displayName,style=MaterialTheme.typography.bodyLarge)
                    Text("震度 ${s.measuredIntensity}",style=MaterialTheme.typography.bodyLarge)
                }
            }
        }
    }
}

@Composable
fun EarthquakeReplayOverlay(event: EarthquakeEvent?, remainingSeconds:Int, onStop:()->Unit) {
    if(event == null) return
    // MediaPlayer/TTS/audio focus are handled by ReplayAudioController in Android activity layer.
    AlertDialog(onDismissRequest=onStop, title={Text("【歷史回顧】地震演練",fontSize=20.sp)},
        text={Text("${event.affectedLocation}・估計震度 ${event.measuredOrForecastIntensity}\n"+
                "此為歷史資料重播，非即時警報。\n剩餘 $remainingSeconds 秒",fontSize=17.sp)},
        confirmButton={TextButton(onClick=onStop){Text("結束回顧")}})
}

@Composable
fun SingleHapticSlider(intensity:Int, onIntensityChanged:(Int)->Unit) {
    Column {
        Text("觸覺回饋強度 $intensity%", style=MaterialTheme.typography.bodyLarge)
        Slider(value=intensity.toFloat(), onValueChange={onIntensityChanged(it.toInt().coerceIn(0,100))},
            valueRange=0f..100f, modifier=Modifier.semantics {contentDescription="觸覺回饋強度"})
    }
}

@Composable
fun FeatureSwitch(label:String, enabled:Boolean, available:Boolean,
                  onChange:(Boolean)->Unit, disabledReason:String="功能尚未實作") {
    Row(Modifier.fillMaxWidth().heightIn(min=56.dp),
        verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween){
        Column(Modifier.weight(1f)) {
            Text(label,style=MaterialTheme.typography.bodyLarge)
            if(!available) Text(disabledReason,style=MaterialTheme.typography.bodySmall)
        }
        Switch(checked=enabled,onCheckedChange=if(available) onChange else null, enabled=available)
    }
}
