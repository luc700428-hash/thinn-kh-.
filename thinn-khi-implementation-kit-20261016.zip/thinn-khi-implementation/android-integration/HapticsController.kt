package io.atmos.weather.integration

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** All page controls must call one central intensity controller (0–100%, 100 default). */
class HapticsController(private val context:Context) {
    private val prefs=context.getSharedPreferences("thinn_accessibility",Context.MODE_PRIVATE)
    var intensity:Int
       get()=prefs.getInt("haptic_intensity",100).coerceIn(0,100)
       set(value){ prefs.edit().putInt("haptic_intensity",value.coerceIn(0,100)).apply() }
    fun tap(){ vibrate(20) }
    fun warning(){ vibrate(150) }
    private fun vibrate(durationMs:Long){
        val strength=intensity
        if(strength<=0)return
        val vibrator=if(Build.VERSION.SDK_INT>=31){
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else @Suppress("DEPRECATION") (context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator)
        if(!vibrator.hasVibrator())return
        if(Build.VERSION.SDK_INT>=26) vibrator.vibrate(VibrationEffect.createOneShot(durationMs,(255.0*strength/100.0).toInt().coerceIn(1,255)))
        else @Suppress("DEPRECATION") vibrator.vibrate(durationMs)
    }
}
