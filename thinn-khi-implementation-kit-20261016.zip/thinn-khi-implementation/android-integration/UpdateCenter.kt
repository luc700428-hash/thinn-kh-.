package io.atmos.weather.integration

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Never guess next version. Show latest actual release and let user explicitly open its browser release page. */
data class AvailableRelease(val tag:String,val notes:String,val url:String)
object ReleaseRepository {
    suspend fun queryLatest():AvailableRelease? = withContext(Dispatchers.IO) {
        val url=URL("https://api.github.com/repos/luc700428-hash/thinn-kh-./releases/latest")
        val c=(url.openConnection() as HttpURLConnection).apply {
            connectTimeout=5000;readTimeout=5000
            setRequestProperty("Accept","application/vnd.github+json")
            setRequestProperty("User-Agent","thinn-khi-app")
        }
        try {
            if(c.responseCode!=200)return@withContext null
            val json=JSONObject(c.inputStream.bufferedReader().readText())
            val tag=json.optString("tag_name").takeIf{it.matches(Regex("v?\\d+(\\.\\d+){1,3}"))}?:return@withContext null
            val link=json.optString("html_url")
            if(!link.startsWith("https://github.com/luc700428-hash/thinn-kh-./releases/tag/"))return@withContext null
            AvailableRelease(tag,json.optString("body"),link)
        }finally{c.disconnect()}
    }
}
@Composable
fun AppUpdateCenter(context:Context, currentVersion:String, currentNotes:String){
    var latest by remember { mutableStateOf<AvailableRelease?>(null) }
    var checked by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }
    LaunchedEffect(currentVersion) {
        latest=try{ReleaseRepository.queryLatest()}catch(t:Exception){error=true;null}
        checked=true
    }
    Column(Modifier.fillMaxWidth().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("應用程式更新",style=MaterialTheme.typography.titleLarge)
        Text("目前版本 $currentVersion",style=MaterialTheme.typography.titleMedium)
        Text(currentNotes.ifBlank{"此版本尚無說明"})
        HorizontalDivider()
        when {
            !checked->CircularProgressIndicator()
            latest==null->Text(if(error) "暫時無法檢查更新" else "目前沒有可公開查詢的發行版本")
            else->{
                Text("GitHub 最新公開版本：${latest!!.tag}",style=MaterialTheme.typography.titleMedium)
                Text(latest!!.notes.ifBlank{"未提供更新說明"})
                Button(onClick={
                    context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(latest!!.url)))
                }){Text("查看官方更新與下載")}
            }
        }
    }
}
