package io.atmos.weather.integration

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import io.atmos.weather.R

/** 2x1 / 2x2 examples, matching widget_weather_compact/expanded XML in widget-res. */
open class WeatherWidgetProvider:AppWidgetProvider() {
    override fun onUpdate(context:Context, manager:AppWidgetManager, appWidgetIds:IntArray){
        appWidgetIds.forEach {id->updateOne(context,manager,id,null,null,null)}
    }
    companion object {
        fun updateOne(context:Context, manager:AppWidgetManager, id:Int,
                      location:String?,temperature:String?,condition:String?){
            val opts=manager.getAppWidgetOptions(id)
            val expanded=opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT,0)>=90
            val view=RemoteViews(context.packageName,if(expanded) R.layout.widget_weather_expanded else R.layout.widget_weather_compact)
            view.setTextViewText(R.id.widget_location,location?:"尚無天氣資料")
            view.setTextViewText(R.id.widget_temperature,temperature?:"—°")
            view.setTextViewText(R.id.widget_condition,condition?:"點按查看天氣")
            val launch=context.packageManager.getLaunchIntentForPackage(context.packageName)
            if(launch!=null){
                launch.putExtra("open_tab","weather")
                val pending=PendingIntent.getActivity(context,id,launch,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                view.setOnClickPendingIntent(R.id.widget_root,pending)
            }
            manager.updateAppWidget(id,view)
        }
    }
}
class WeatherCompactWidget:WeatherWidgetProvider()
class WeatherExpandedWidget:WeatherWidgetProvider()
