/** RainViewer API only provides radar HISTORY; it does not provide future nowcast or satellite IR as of 2026. */
export const METADATA_URL = 'https://api.rainviewer.com/public/weather-maps.json';
export const MIN_REFRESH_MS = 5 * 60_000;
export const FRAME_INTERVAL_REPORTED_MIN = 10;
const allowedHosts = new Set(['tilecache.rainviewer.com','api.rainviewer.com']);
export function parseRadarMetadata(input) {
  if (!input || !Array.isArray(input.radar?.past)) throw Error('Malformed radar metadata');
  const host = new URL(input.host);
  if (host.protocol !== 'https:' || !allowedHosts.has(host.hostname)) throw Error('Untrusted tile host');
  const frames = input.radar.past
    .filter(x=>Number.isInteger(x.time) && typeof x.path === 'string' && /^\/v2\/radar\/[\w/-]+$/.test(x.path))
    .sort((a,b)=>a.time-b.time).map(x=>({time:x.time,path:x.path}));
  if (!frames.length) throw Error('No observed radar frames available');
  return {host:host.origin,frames,latest:frames[frames.length-1],source:'RainViewer',forecast:false};
}
export function makeRadarTileUrl(parsed, frame, {z,x,y,size=256} = {}) {
  if (![z,x,y].every(Number.isInteger) || z<0 || z>7 || x<0 || y<0 || ![256,512].includes(size)) throw Error('Invalid radar tile index');
  if (!parsed.frames.some(f=>f.path===frame.path)) throw Error('Frame not in fetched timeline');
  return `${parsed.host}${frame.path}/${size}/${z}/${x}/${y}/2/1_1.png`;
}
export function createRadarCache(fetcher=fetch, now=()=>Date.now()) {
  let cache=null, expires=0;
  return async function getRadar(force=false) {
    if (cache && (!force || now() < expires)) return cache;
    const controller = new AbortController();
    const timer=setTimeout(()=>controller.abort(), 8000);
    try {
      const res=await fetcher(METADATA_URL,{signal:controller.signal,headers:{Accept:'application/json'}});
      if(!res.ok) throw Error(`Radar unavailable: ${res.status}`);
      cache=parseRadarMetadata(await res.json());
      expires=now()+MIN_REFRESH_MS;
      return cache;
    } catch(error) {
      if(cache) return {...cache,stale:true,error:String(error.message)};
      throw error;
    } finally {clearTimeout(timer);}
  };
}
