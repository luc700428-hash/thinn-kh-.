// Ollama must be hosted privately and called by trusted backend, not shipped as an open Internet endpoint.
const moods=new Set(['commute','exercise','leisure']);
export function deterministicOutfit(w) {
  const t=Number(w.feelsLikeC), rain=Number(w.rainProbabilityPercent), wind=Number(w.windSpeedMps);
  const activity=moods.has(w.activity)?w.activity:'commute';
  if (![t,rain,wind].every(Number.isFinite) || t < -100 || t > 80 || rain < 0 || rain > 100 || wind < 0 || wind > 130) throw Error('Invalid weather parameters');
  const clothes=t>28?'短袖、透氣下著':t>=20?'薄長袖或短袖搭薄外套':'外套、長褲';
  const suffix={commute:'通勤方便穿脫',exercise:'運動選吸濕排汗衣物',leisure:'休閒舒適分層'}[activity];
  const add=[rain>30?'帶雨具':null,wind>15?'注意強風':null,t>33?'注意補水防曬':null,t<10?'注意保暖':null].filter(Boolean);
  return [clothes,suffix,...add].join('；');
}
export async function outfitWithOptionalOllama(weather, {fetcher=fetch, model='qwen3:0.6b', baseUrl='http://127.0.0.1:11434'}={}) {
  const rules=deterministicOutfit(weather);
  const endpoint=new URL('/api/generate',baseUrl);
  if (!['127.0.0.1','localhost','::1'].includes(endpoint.hostname))
    return {text:rules,engine:'rules',reason:'External model endpoint rejected'};
  const controller=new AbortController(), timer=setTimeout(()=>controller.abort(),3500);
  try {
    const response=await fetcher(endpoint.toString(),{
      method:'POST',headers:{'Content-Type':'application/json'},signal:controller.signal,
      body:JSON.stringify({model,stream:false,options:{temperature:0.2,num_predict:100},
        system:'你是台灣天氣穿搭助手。只給繁體中文、40字以內，不可憑空推測天氣或過度承諾。',
        prompt:`根據資料提供穿搭建議。天氣參數：${JSON.stringify({feelsLikeC:Number(weather.feelsLikeC),rainProbabilityPercent:Number(weather.rainProbabilityPercent),windSpeedMps:Number(weather.windSpeedMps),activity:weather.activity})}。規則基準：${rules}`})
    });
    if(!response.ok) throw Error(`model status ${response.status}`);
    const value=await response.json();
    const text=typeof value.response==='string'?value.response.replace(/\s+/g,' ').trim():'';
    if(!text || text.length>100) throw Error('Invalid model answer');
    return {text,engine:'ollama',fallback:rules};
  } catch(error) {return {text:rules,engine:'rules',reason:String(error.message)};}
  finally {clearTimeout(timer);}
}
