import crypto from 'node:crypto';

// Never treat an ordinary post-earthquake bulletin, replay or user-supplied event as a live EEW.
export const CHANNEL_ID = 'earthquake_alert';
export const MIN_USER_WARNING_INTENSITY = 3;
export function verifyWebhookHmac(rawBody, signature, secret) {
  if (typeof secret !== 'string' || secret.length < 32 || !signature) return false;
  const actual = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  const claim = String(signature).replace(/^sha256=/i,'');
  return /^[0-9a-f]{64}$/i.test(claim) && crypto.timingSafeEqual(Buffer.from(actual,'hex'), Buffer.from(claim,'hex'));
}
export function validateEew(input, trustedAuth) {
  if (!trustedAuth) throw new Error('Unauthorized official EEW ingestion');
  if (input?.kind !== 'official_eew' || input?.sourceVerified !== true)
    throw new Error('Only authenticated official EEW is accepted');
  const id = String(input.id || '');
  const place = String(input.place || '');
  const intensity = Number(input.estimatedIntensity);
  const sourceTime = Number(input.sourceEpochMillis);
  if (!/^[\w.-]{4,100}$/.test(id) || !place || place.length > 50 || !Number.isFinite(intensity) || intensity < 0 || intensity > 10 || !Number.isFinite(sourceTime))
    throw new Error('Malformed EEW data');
  if (Math.abs(Date.now() - sourceTime) > 2 * 60_000) throw new Error('Stale EEW must not be delivered');
  return {id, place, intensity, sourceTime};
}
export function decideWarning(event, userThreshold = MIN_USER_WARNING_INTENSITY) {
  if (!Number.isFinite(userThreshold) || userThreshold < 0 || userThreshold > 10) throw new Error('Invalid threshold');
  return event.intensity > userThreshold;
}
export function buildFcmMessage(token, event) {
  if (typeof token !== 'string' || token.length < 20) throw new Error('Invalid device token');
  const body = `預估震度 ${event.intensity}，${event.place}。預警為初步估計，可能有誤差及盲區。`;
  return {
    token,
    notification: {title: '緊急地震速報', body},
    android: {
      priority: 'high', ttl: 30_000,
      notification: {channelId: CHANNEL_ID, priority:'max', sound:'default', visibility:'public'}
    },
    data: {event: 'official_eew', id:event.id, estimatedIntensity:String(event.intensity),
      place:event.place, sourceEpochMillis:String(event.sourceTime)}
  };
}
export function buildDrillMessage(id) {
  return {title:'【演練】地震速報測試', body:'此為測試，不代表真實地震。', data:{event:'exercise',id:String(id)}};
}
