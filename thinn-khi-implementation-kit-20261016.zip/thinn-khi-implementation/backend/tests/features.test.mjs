import {test} from 'node:test';
import assert from 'node:assert/strict';
import {buildFcmMessage, buildDrillMessage,decideWarning,validateEew,verifyWebhookHmac} from '../src/eew.mjs';
import {parseRadarMetadata,makeRadarTileUrl,createRadarCache} from '../src/rainviewer.mjs';
import {deterministicOutfit,outfitWithOptionalOllama} from '../src/outfit-ai.mjs';
import crypto from 'node:crypto';

test('official EEW requires trusted signature + freshness + source',()=>{
 const secret='x'.repeat(40),body=Buffer.from('{"kind":"official_eew"}');
 const hmac=crypto.createHmac('sha256',secret).update(body).digest('hex');
 assert.equal(verifyWebhookHmac(body,`sha256=${hmac}`,secret),true);
 assert.equal(verifyWebhookHmac(body,'sha256='+'0'.repeat(64),secret),false);
 const raw={kind:'official_eew',sourceVerified:true,id:'TW-2026',place:'嘉義',estimatedIntensity:5.5,sourceEpochMillis:Date.now()};
 const event=validateEew(raw,true);
 assert.equal(decideWarning(event),true);
 assert.equal(decideWarning({...event,intensity:3}),false);
 assert.throws(()=>validateEew({...raw,kind:'post_event_report'},true));
 assert.throws(()=>validateEew(raw,false));
 assert.throws(()=>validateEew({...raw,sourceEpochMillis:Date.now()-300_000},true));
 const msg=buildFcmMessage('f'.repeat(50),event);
 assert.equal(msg.android.priority,'high');
 assert.equal(msg.data.event,'official_eew');
 assert.match(buildDrillMessage('123').title,/演練/);
});
test('radar only past frames; tile URLs safe and zoom bounded',()=>{
 const radar=parseRadarMetadata({host:'https://tilecache.rainviewer.com',radar:{past:[{time:1609401600,path:'/v2/radar/1609401600'}]}});
 assert.equal(radar.forecast,false);
 assert.match(makeRadarTileUrl(radar,radar.latest,{z:5,x:26,y:14}),/^https:\/\/tilecache\.rainviewer\.com/);
 assert.throws(()=>makeRadarTileUrl(radar,radar.latest,{z:8,x:1,y:1}));
 assert.throws(()=>parseRadarMetadata({host:'https://evil.example',radar:{past:[{time:1,path:'/v2/radar/1'}]}}));
});
test('radar metadata cache limits fetch frequency',async()=>{
 let calls=0,now=0;
 const fetcher=async()=>{calls++;return {ok:true,json:async()=>({host:'https://tilecache.rainviewer.com',radar:{past:[{time:42,path:'/v2/radar/42'}]}})};};
 const get=createRadarCache(fetcher,()=>now);
 await get();await get();assert.equal(calls,1);
 now=300001;await get(true);assert.equal(calls,2);
});
test('outfit deterministic rules + mock AI fallback',async()=>{
 const w={feelsLikeC:30,rainProbabilityPercent:60,windSpeedMps:17,activity:'exercise'};
 assert.match(deterministicOutfit(w),/帶雨具/);
 assert.match(deterministicOutfit(w),/吸濕排汗/);
 const r=await outfitWithOptionalOllama(w,{fetcher:async()=>{throw Error('offline')}});
 assert.equal(r.engine,'rules');
 const a=await outfitWithOptionalOllama(w,{fetcher:async()=>({ok:true,json:async()=>({response:'短袖，雨具備妥。'})})});
 assert.equal(a.engine,'ollama');
});
