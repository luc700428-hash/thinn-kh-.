package io.atmos.weather.core

import kotlin.math.abs

/** Independent, testable logic: no Android framework calls or network side effects. */
data class WeatherSnapshot(
    val temperatureC: Double,
    val feelsLikeC: Double,
    val rainProbabilityPercent: Int,
    val windSpeedMps: Double,
    val condition: String,
    val observedEpochSeconds: Long
) {
    init {
        require(temperatureC in -90.0..65.0 && feelsLikeC in -100.0..80.0)
        require(rainProbabilityPercent in 0..100)
        require(windSpeedMps in 0.0..130.0)
    }
}

enum class ActivityType { COMMUTE, EXERCISE, LEISURE }

data class OutfitResult(val headline: String, val advice: String, val reminders: List<String>) {
    fun compactText() = (listOf(headline, advice) + reminders).joinToString("　")
}

object OutfitRules {
    fun advise(weather: WeatherSnapshot, activity: ActivityType): OutfitResult {
        val feel = weather.feelsLikeC
        val clothing = when {
            feel > 28.0 -> "短袖、透氣下著"
            feel >= 20.0 -> "薄長袖或短袖搭薄外套"
            else -> "外套、長褲"
        }
        val activityNote = when(activity) {
            ActivityType.COMMUTE -> "通勤以方便穿脫為主"
            ActivityType.EXERCISE -> "運動穿吸濕排汗衣物"
            ActivityType.LEISURE -> "休閒建議舒適分層"
        }
        val reminders = mutableListOf<String>()
        if (weather.rainProbabilityPercent > 30) reminders.add("帶雨具")
        if (weather.windSpeedMps > 15.0) reminders.add("強風，注意防風")
        if (feel > 33.0) reminders.add("注意補水與防曬")
        if (feel < 10.0) reminders.add("注意保暖")
        val headline = "${weather.condition} ${weather.temperatureC.round0()}°C（體感 ${feel.round0()}°C）"
        return OutfitResult(headline, "$clothing；$activityNote", reminders)
    }
    private fun Double.round0(): String = kotlin.math.round(this).toInt().toString()
}

data class SeismicStation(
    val id: String,
    val displayName: String,
    val latitude: Double,
    val longitude: Double,
    val measuredIntensity: Double,
    val observationEpochMillis: Long
) {
    init {
        require(id.isNotBlank() && displayName.isNotBlank())
        require(latitude in -90.0..90.0 && longitude in -180.0..180.0)
        require(measuredIntensity in 0.0..10.0)
    }
}

data class StationRefresh(val stations: List<SeismicStation>, val refreshedIds: Set<String>)

object SeismicStationReducer {
    /** Keep station markers permanently in a stable order; pulse only changed incoming measurements. */
    fun merge(old: List<SeismicStation>, incoming: List<SeismicStation>): StationRefresh {
        val previous = old.associateBy { it.id }
        val next = incoming.associateBy { it.id }
        val merged = old.map { next[it.id] ?: it } + incoming.filter { it.id !in previous }
        val refreshed = incoming.filter { s ->
            val p = previous[s.id]
            p == null || (s.observationEpochMillis > p.observationEpochMillis &&
                (abs(s.measuredIntensity - p.measuredIntensity) >= .01 || s.observationEpochMillis != p.observationEpochMillis))
        }.mapTo(mutableSetOf()) { it.id }
        return StationRefresh(merged, refreshed)
    }
}

enum class AlertOrigin { OFFICIAL_EEW, EXERCISE, HISTORICAL_REPLAY, POST_EVENT_REPORT }

data class EarthquakeEvent(
    val id: String,
    val origin: AlertOrigin,
    val measuredOrForecastIntensity: Double,
    val affectedLocation: String,
    val eventEpochMillis: Long,
    val verifiedOfficialSource: Boolean
)

data class AlertDecision(val emergency: Boolean, val userFacingTitle: String, val reason: String)

/** Strict separation: later USGS/post-event data and test replays must not become real EEW. */
object EarthquakePolicy {
    fun evaluate(event: EarthquakeEvent, warningThreshold: Double = 3.0): AlertDecision {
        require(warningThreshold in 0.0..10.0)
        return when (event.origin) {
            AlertOrigin.EXERCISE -> AlertDecision(false, "【演練】地震警報測試", "模擬事件，不發送正式警報")
            AlertOrigin.HISTORICAL_REPLAY -> AlertDecision(false, "【歷史回顧】地震警報", "回放事件，不發送正式警報")
            AlertOrigin.POST_EVENT_REPORT -> AlertDecision(false, "地震資訊", "震後資訊不得當作即時預警")
            AlertOrigin.OFFICIAL_EEW -> {
                if (!event.verifiedOfficialSource) AlertDecision(false, "待查證地震消息", "資料來源未經認證")
                else if (event.measuredOrForecastIntensity <= warningThreshold) AlertDecision(false, "地震資訊", "估計震度未超過設定門檻")
                else AlertDecision(true, "緊急地震速報", "初步估計值；預警可能有誤差及盲區")
            }
        }
    }
}

/** Dynamic theme tokens; authoritative foreground contrast still checked by Android UI tests. */
enum class WeatherMood { SUNNY, CLOUDY, RAINY, STORM, NIGHT }
data class Palette(val background: Long, val surface: Long, val primaryText: Long, val accent: Long)
object WeatherTheme {
    fun palette(mood: WeatherMood, dark: Boolean): Palette {
        if (dark) return Palette(0xFF121C2BL, 0xB7223042L, 0xFFFFFFFFL,
            if (mood == WeatherMood.STORM) 0xFFFFC66EL else 0xFF8ADCE8L)
        return when(mood) {
            WeatherMood.SUNNY -> Palette(0xFFE3F6FFL, 0xD9F8FDFFL, 0xFF12334BL, 0xFFA45200L)
            WeatherMood.CLOUDY -> Palette(0xFFDFE8EFL, 0xD9F6F9FCL, 0xFF243445L, 0xFF24638CL)
            WeatherMood.RAINY -> Palette(0xFFD6E1EAL, 0xE0F3F6F9L, 0xFF233345L, 0xFF235E8CL)
            WeatherMood.STORM -> Palette(0xFFC4D5E3L, 0xE8E7F0F7L, 0xFF182D46L, 0xFF6B3B00L)
            WeatherMood.NIGHT -> Palette(0xFF202F46L, 0xBB2B3A51L, 0xFFFFFFFFL, 0xFFA0DBEAL)
        }
    }
}

/** Single haptic setting 0..100%, default 100%. No decorative per-feature toggles. */
data class InteractionSettings(val hapticIntensityPercent: Int = 100) {
    init { require(hapticIntensityPercent in 0..100) }
    fun scaledAmplitude(): Int = if(hapticIntensityPercent == 0) 0
        else ((255 * hapticIntensityPercent / 100.0).toInt()).coerceIn(1,255)
}

data class DemoTick(val remainingSeconds: Int, val ongoing: Boolean, val label: String)
object DemoSession {
    fun fromElapsedSeconds(elapsedSeconds: Int): DemoTick {
        val remaining = (10 - elapsedSeconds.coerceAtLeast(0)).coerceAtLeast(0)
        return DemoTick(remaining, remaining > 0,
            if(remaining > 0) "演示中・剩餘 $remaining 秒" else "演示已結束")
    }
}
