package io.atmos.weather.core

object WeatherLogicTest {
  @JvmStatic fun main(args: Array<String>) {
    fun sample(t: Double, feels: Double, rain: Int, wind: Double) = WeatherSnapshot(t, feels, rain, wind, "多雲", 1L)
    val a = OutfitRules.advise(sample(30.0, 34.0, 50, 17.0), ActivityType.EXERCISE)
    check("帶雨具" in a.reminders)
    check("強風，注意防風" in a.reminders)
    check(a.advice.contains("吸濕排汗"))
    check(OutfitRules.advise(sample(16.0, 16.0, 10, 2.0), ActivityType.COMMUTE).advice.contains("外套"))
    val station = SeismicStation("A1", "嘉義", 23.48, 120.45, 0.2, 1)
    val updated = station.copy(measuredIntensity=1.8, observationEpochMillis=2)
    val m = SeismicStationReducer.merge(listOf(station), listOf(updated))
    check(m.stations.size == 1 && "A1" in m.refreshedIds)
    check(SeismicStationReducer.merge(listOf(updated), emptyList()).stations.size == 1)
    val eew = EarthquakeEvent("test", AlertOrigin.OFFICIAL_EEW, 5.0, "嘉義", 10, true)
    check(EarthquakePolicy.evaluate(eew).emergency)
    check(!EarthquakePolicy.evaluate(eew.copy(verifiedOfficialSource=false)).emergency)
    check(!EarthquakePolicy.evaluate(eew.copy(origin=AlertOrigin.HISTORICAL_REPLAY)).emergency)
    check(!EarthquakePolicy.evaluate(eew.copy(origin=AlertOrigin.POST_EVENT_REPORT)).emergency)
    check(!EarthquakePolicy.evaluate(eew.copy(origin=AlertOrigin.EXERCISE)).emergency)
    check(!EarthquakePolicy.evaluate(eew.copy(measuredOrForecastIntensity=3.0)).emergency)
    check(DemoSession.fromElapsedSeconds(5).remainingSeconds == 5)
    check(!DemoSession.fromElapsedSeconds(10).ongoing)
    check(InteractionSettings().scaledAmplitude() == 255)
    check(InteractionSettings(0).scaledAmplitude() == 0)
    check(WeatherTheme.palette(WeatherMood.RAINY,false) != WeatherTheme.palette(WeatherMood.SUNNY,false))
    println("PASS: pure Kotlin weather, outfit, stations, EEW separation, demo, haptic, theme")
  }
}
