#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
mkdir -p .test-output
kotlinc android-core/src/main/kotlin/io/atmos/weather/core/WeatherLogic.kt android-core/src/test/kotlin/io/atmos/weather/core/WeatherLogicTest.kt -include-runtime -d .test-output/core-tests.jar
java -jar .test-output/core-tests.jar
node --test backend/tests/*.test.mjs
