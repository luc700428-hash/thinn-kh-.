package io.atmos.weather.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Android-native, accessibility-first design tokens inspired by Apple's public HIG.
 * These engineering values are thinn-khì recommendations, NOT Apple's private iOS constants.
 */
object ThinnDesignTokens {
    val radiusControl=16.dp
    val radiusRow=20.dp
    val radiusCard=28.dp
    val radiusSheet=32.dp
    val radiusNav=34.dp
    val touchTarget=48.dp
    val spacingSmall=8.dp
    val spacingMedium=16.dp
    val spacingLarge=24.dp
    val lightBackground=Color(0xFFEAF5FB)
    val darkBackground=Color(0xFF091A30)
    val lightGlass=Color(0xE8FFFFFF)
    val darkGlass=Color(0xB8264562)
    val accent=Color(0xFF70C8EF)
    val positive=Color(0xFF54D1A3)
    val caution=Color(0xFFFFCE6D)
    val critical=Color(0xFFFF674D)
    val primaryInkDark=Color(0xFFFFFFFF)
    val secondaryInkDark=Color(0xFFDCECF5)
    const val shortMotionMillis=150
    const val mediumMotionMillis=260
    const val longMotionMillis=430
    const val springDamping=.78f
    const val springStiffness=380f
}
