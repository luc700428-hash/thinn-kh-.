# thinn-khì V22.0
- API 36 原始碼遷移：仍需完整 Android 16 實機驗證
- FCM 需要外部 Firebase 專案設定；預設關閉、使用者授權後登記裝置；過期、未授權來源與重複事件拒絕
- 可部署 Firebase Functions 安全推播雛形（未接通正式官方 EEW 資料源）
- 22 縣市程序化地標 GLB 藝術模型、Android 天氣 Canvas 顯示維持
- Liquid Glass 改善與天氣 Widget 安全訊息
- 非已簽署 APK，正式 OTA 需簽章金鑰、資料來源授權與 CI 實機驗收
