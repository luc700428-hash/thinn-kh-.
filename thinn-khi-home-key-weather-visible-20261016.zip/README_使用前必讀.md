# thinn-khì｜實機截圖問題修正包（2026-10-16）

這不是 APK，沒有更新使用者手機或 GitHub 正式版。此工程包提供已實際修改的 Kotlin/Compose Android 原始碼、可建置 GitHub Actions、地標資料庫及 17 個建模原型（含本次嘉義新增 5 個）。

**為什麼上一版在手機看不到？** 已確認 GitHub 最新 Release 為 `v22.0.107`，該儲存庫 main 工作流程仍在解壓固定舊版來源 ZIP。先前交付原始碼與已安裝 APK 是兩件事。

**首頁重做：** 重要資料不是隱藏項目：首頁直接顯示六小時降雨最高機率、氣溫趨勢、風速、空品模型或濕度；官方特報、實際穿著和雨具建議也直接呈現，只有計算依據與個人設定留在次級面板；地標名稱作為 24sp 主標，未建模不再顯示通用小屋；日間文字加深對比，24 小時預報與導覽標籤放大。

**請保持合理期待：** 17 個原創 GLB 是可解析幾何原型，不是高精度真實場景。115 筆仍待建模；即時 Filament 3D／日夜天氣／攝影機飛越未完成，Android Compose 尚未編譯與裝置驗收。

## 部署（Termux，在本人 GitHub 登入狀態下）

1. 下載 ZIP 到 Download，完整解壓到例如 `$HOME/storage/downloads/thinn-redesign`。
2. 使用 `bash deploy-to-github.sh`；腳本會備份遠端已有內容至 clone，替換專用 `android-project` 資料夾和工作流程，提交並推送到 main；**不會發布 OTA**。
3. 用 `gh run list --repo 'luc700428-hash/thinn-kh-.' --workflow build-apk.yml --limit 3` 確認 CI。成功後從工作流程下載 Debug 測試 APK 並驗收。
4. 確認 CI、實機介面、同簽章與 Android 權限運作後，才手動決定是否執行 `gh workflow run build-apk.yml --repo 'luc700428-hash/thinn-kh-.' --ref main -f publish_release=true`。不建議未測試即發布給朋友。

注意：由於使用者原本的舊版更新檢查可能經 GitHub API 而碰到 403，首個新版 OTA 可能需要**以官方 Release 中同簽章的 APK 手動覆蓋安裝一次**。切勿為了升級直接移除既有 App，以免清除個人資料。

閱讀 `docs/截圖問題修復與驗收.md` 瞭解問題根源、完成與尚未完成事項。
