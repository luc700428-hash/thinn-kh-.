# thinn-khì 首頁 — 重要天氣直接顯示修正

狀態：已修改 Kotlin/Compose 原始碼；**尚未進行完整 Android Gradle 編譯、實機畫面驗收或 OTA 發布**。

## 修正前（用戶提出的問題）

- 首頁重要的穿著、雨具與天氣預報被「查看詳情」操作隱藏。
- 重要特報在次要地標之後，首頁缺少六小時天氣變化摘要。
- 長篇技術依據佔據畫面，增加閱讀負擔。

## 修正後（目前在本工程原始碼中）

1. 城市、即時溫度、天氣現況、最高最低溫、體感溫度：首頁頂端直接顯示。
2. **重點天氣資訊**：新增明顯玻璃資訊卡（未來六小時最高降雨機率、未來六小時氣溫變化、目前風速、空品模型／濕度），字級 15–23sp；沒有資料就顯示「—／尚無資料」。空品模型不冒充環境部實測 AQI。
3. **中央氣象署特報**：存在已匹配所在地特報時，在地標模型之前逐條顯示並連至官方公告；無匹配時提供查詢狀態。
4. **今天出門**：直接呈現高優先天氣警示、穿著建議、雨具建議、外套／防曬；只有演算法證據、更多選項留在「計算依據與個人設定」。不再以整張可點擊卡片阻擋關鍵資訊。
5. **在地微縮地標**：仍顯示「縣市、地標名稱」，僅放在必要天氣與特報之後。未完成模型絕不冒稱真實建築。
6. 24 小時滑動預報、天氣儀表、空氣品質、能見度、雷達等原有功能保留於首頁往下捲動區域。

## 實際程式檔案

- `android-project/app/src/main/java/io/atmos/weather/presentation/home/WeatherHomeScreen.kt`：首頁卡片、排序、直接呈現雨具／衣物。
- `android-project/app/src/main/java/io/atmos/weather/presentation/home/HomeWeatherBriefing.kt`：純 Kotlin 天氣摘要，能測試的無捏造規則。
- `android-project/tools/tests/test_home_readability_regression.py`：新增首頁資訊可見性、排序回歸測試。
- `android-project/app/src/main/assets/current_release_notes.md`：記錄本次新增與未驗收狀態。

## 測試及待辦

- Python 單元／原始碼結構驗證：29 項通過（多數是靜態契約，**不是** UI 實機測試）。
- Node.js 地震推播政策：7 項通過。
- Kotlin：`WeatherModels.kt` + `HomeWeatherBriefing.kt` 實際編譯與執行，涵蓋有降雨、缺漏值、無風速、空氣品質模型與氣溫趨勢的測試斷言。
- 未驗收：Compose UI 全專案編譯、不同解析度／字級的真實排版、操作流程、Android 裝置安裝、CI 發布、地標模型精緻度。

這次 ZIP 是可交付工程專案，**不代表 GitHub main 或手機 APK 已更新**。
