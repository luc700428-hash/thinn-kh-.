package io.atmos.weather.domain.model

import java.time.Duration
import kotlin.math.roundToInt

data class WeatherAdvice(val heading: String, val detail: String, val priority: Int)

/** Explainable forecast-based advice; no cloud LLM, no fabricated forecasts. */
object WeatherAdviceEngine {
    fun suggest(weather: WeatherSnapshot): List<WeatherAdvice> {
        val suggestions = mutableListOf<WeatherAdvice>()
        val now = weather.observedAt
        val nextSixHours = weather.hourly.filter {
            !it.at.isBefore(now) && Duration.between(now,it.at).toHours() <= 6
        }
        val upcomingRain = nextSixHours.firstOrNull { (it.precipitationProbabilityPct ?: 0) >= 60 }
        when {
            weather.condition == WeatherCondition.THUNDERSTORM ->
                suggestions += WeatherAdvice("雷雨期間請留意安全", "減少戶外活動，遠離空曠高處；依官方最新警報安排外出。", 10)
            weather.condition == WeatherCondition.RAIN ->
                suggestions += WeatherAdvice("外出記得攜帶雨具", "目前有降雨，留意路面濕滑與能見度。", 8)
            upcomingRain != null -> {
                val hrs = Duration.between(now, upcomingRain.at).toHours().coerceAtLeast(0)
                suggestions += WeatherAdvice("未來 $hrs 小時內降雨機率提高", "預報該時段降雨機率約 ${upcomingRain.precipitationProbabilityPct}%，建議備妥雨具。", 7)
            }
        }
        val feels = weather.feelsLikeC ?: weather.temperatureC
        when {
            feels < 12 -> suggestions += WeatherAdvice("需要保暖", "體感約 ${feels.roundToInt()}°C，建議穿著保暖外套與多層次衣物。", 7)
            feels < 20 -> suggestions += WeatherAdvice("適合薄外套", "體感約 ${feels.roundToInt()}°C，可搭配長袖或輕薄外套。", 4)
            feels >= 30 -> suggestions += WeatherAdvice("天氣較熱", "體感約 ${feels.roundToInt()}°C，建議穿透氣衣物、補充水分並避免長時間曝曬。", 7)
            else -> suggestions += WeatherAdvice("穿搭建議", "體感約 ${feels.roundToInt()}°C，建議舒適透氣的日常衣物。", 3)
        }
        if ((weather.currentUv ?: 0.0) >= 6) suggestions += WeatherAdvice("紫外線偏強", "外出建議遮陽、防曬，並留意長時間日曬。", 6)
        if (weather.condition == WeatherCondition.FOG || (weather.visibilityM ?: Double.MAX_VALUE) < 1000.0) {
            suggestions += WeatherAdvice("能見度較差", "可能有霧，行車請減速並依實際路況使用燈光。", 8)
        }
        val aqi = weather.usAqi
        if (aqi != null && aqi > 100) suggestions += WeatherAdvice("空氣品質需留意", "模型預估美制 AQI 約 $aqi；敏感族群可酌減長時間戶外活動。", 7)
        return suggestions.sortedByDescending { it.priority }.take(4)
    }
}
