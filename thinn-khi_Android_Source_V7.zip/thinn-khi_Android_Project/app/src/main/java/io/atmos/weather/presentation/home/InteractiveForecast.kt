package io.atmos.weather.presentation.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.atmos.weather.domain.model.HourlyWeather
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

/** Smooth chart with horizontal drag-to-scrub. Vertical swipes are not consumed. */
@Composable
fun InteractiveForecast(hours: List<HourlyWeather>, timeZoneId:String? = null, modifier: Modifier = Modifier) {
    if (hours.size < 2) return
    val visible = hours.take(24)
    val zone = remember(timeZoneId) {
        runCatching { ZoneId.of(timeZoneId ?: ZoneId.systemDefault().id) }.getOrDefault(ZoneId.systemDefault())
    }
    val density = LocalDensity.current
    val step = 65.dp
    val stepPx = with(density) { step.toPx() }
    val scroll = rememberScrollState()
    var selected by remember(visible) { mutableIntStateOf(0) }
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val halfViewportPx = with(density) { maxWidth.toPx() / 2f }
        LaunchedEffect(scroll.value, halfViewportPx, stepPx, visible.size) {
            selected = ((scroll.value + halfViewportPx) / stepPx - .5f)
                .roundToInt().coerceIn(0, visible.lastIndex)
        }
        Column {
            val hour = visible[selected]
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Text("24 小時 · 左右拖曳查看", color=Color.White, fontSize=14.sp, fontWeight=FontWeight.SemiBold)
                Text("${hour.at.atZone(zone).format(DateTimeFormatter.ofPattern("HH:mm"))}  ${hour.temperatureC?.roundToInt()?.let{"$it°"} ?: "—"}",
                    color=Color(0xFFFFD88A), fontSize=15.sp, style=TextStyle(fontFeatureSettings="tnum"))
            }
            Spacer(Modifier.height(13.dp))
            Column(Modifier.fillMaxWidth().horizontalScroll(scroll)) {
                val totalWidth=step * visible.size
                val valid=visible.mapNotNull { it.temperatureC }
                val min=(valid.minOrNull() ?: 0.0) - 1.0
                val max=(valid.maxOrNull() ?: 1.0) + 1.0
                val range=(max-min).coerceAtLeast(3.0)
                Canvas(Modifier.width(totalWidth).height(107.dp).pointerInput(visible.size) {
                    detectTapGestures { point ->
                        selected = (point.x / stepPx).toInt().coerceIn(0,visible.lastIndex)
                    }
                }) {
                    val segment=size.width/visible.size
                    val points=visible.mapIndexed { i,h ->
                        Offset((i+.5f)*segment, size.height*.83f - (((h.temperatureC ?: min)-min)/range).toFloat()*size.height*.65f)
                    }
                    for(row in 0..3){
                        val y=size.height*(.17f+row*.23f)
                        drawLine(Color.White.copy(alpha=.1f), Offset(0f,y),Offset(size.width,y),1.dp.toPx())
                    }
                    val path=Path().apply {
                        moveTo(points.first().x,points.first().y)
                        for (i in 1 until points.size) {
                            val left=points[i-1];val right=points[i]
                            val mid=(left.x+right.x)/2f
                            cubicTo(mid,left.y,mid,right.y,right.x,right.y)
                        }
                    }
                    drawPath(path,Brush.horizontalGradient(listOf(Color(0xFFFFD17C), Color(0xFFFFA855))),
                        style=Stroke(width=3.dp.toPx(), cap=StrokeCap.Round))
                    val focus=points[selected]
                    drawLine(Color.White.copy(alpha=.4f),Offset(focus.x,4f),Offset(focus.x,size.height),1.dp.toPx())
                    drawCircle(Color(0xFFFFD181),6.dp.toPx(),focus)
                    drawCircle(Color.White,2.dp.toPx(),focus)
                }
                Row(Modifier.width(totalWidth)) {
                    visible.forEach { h ->
                        Column(Modifier.width(step), horizontalAlignment=Alignment.CenterHorizontally) {
                            Text(h.at.atZone(zone).format(DateTimeFormatter.ofPattern("HH")),
                                color=Color.White.copy(alpha=.82f),fontSize=12.sp,
                                style=TextStyle(fontFeatureSettings="tnum"))
                            Text(when (h.weatherCode) {
                                in 95..99 -> "⛈"
                                in 71..77,85,86 -> "❄"
                                in 51..67, in 80..82 -> "☂"
                                45,48 -> "≋"
                                0,1 -> "☀"
                                else -> "☁"
                            },fontSize=18.sp,color=Color.White)
                            Text("${h.windKmh?.roundToInt()?.toString() ?: "—"} km/h",fontSize=10.sp,
                                color=Color.White.copy(alpha=.69f),style=TextStyle(fontFeatureSettings="tnum"))
                            Text("${h.precipitationProbabilityPct ?: "—"}%",fontSize=11.sp,
                                color=Color(0xFFC5F1FF),style=TextStyle(fontFeatureSettings="tnum"))
                        }
                    }
                }
            }
        }
    }
}
