package io.atmos.weather.presentation.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.atmos.weather.domain.model.WeatherSnapshot
import kotlin.math.roundToInt

private val white=Color.White
private val dim=Color.White.copy(alpha=.70f)

@Composable
fun WeatherDial(title:String, value:String, description:String, fraction:Float, tint:Color, modifier:Modifier=Modifier) {
    val shape=RoundedCornerShape(24.dp)
    Column(modifier.background(white.copy(alpha=.10f),shape)
        .border(1.dp,white.copy(alpha=.15f),shape).padding(15.dp)) {
        Text(title,color=dim,fontSize=13.sp)
        Spacer(Modifier.height(5.dp))
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(value,color=white,fontSize=23.sp,fontWeight=FontWeight.Medium,
                    style=TextStyle(fontFeatureSettings="tnum"))
                Text(description,color=dim,fontSize=10.sp,maxLines=2)
            }
            Box(Modifier.size(65.dp),contentAlignment=Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw=5.dp.toPx()
                    drawArc(Color.White.copy(alpha=.14f),startAngle=135f,sweepAngle=270f,useCenter=false,
                        style=Stroke(width=sw,cap=StrokeCap.Round))
                    drawArc(Brush.sweepGradient(listOf(tint.copy(alpha=.72f),tint)),startAngle=135f,
                        sweepAngle=270f*fraction.coerceIn(0f,1f),useCenter=false,
                        style=Stroke(width=sw,cap=StrokeCap.Round))
                }
            }
        }
    }
}

fun windDirectionLabel(degrees: Int?):String {
    if (degrees == null) return "風向未提供"
    val directions=listOf("北","東北","東","東南","南","西南","西","西北")
    return "${directions[((degrees+22)%360)/45]}風"
}

@Composable
fun WeatherIndicatorGrid(weather:WeatherSnapshot) {
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        WeatherDial("紫外線",weather.currentUv?.let { String.format("%.1f",it) } ?: "—",
            when { (weather.currentUv ?: 0.0)>=8 -> "過量"; (weather.currentUv ?: 0.0)>=6 -> "偏高"; else -> "請留意日照" },
            ((weather.currentUv ?: 0.0)/11.0).toFloat(), Color(0xFFFFBD71),Modifier.weight(1f))
        WeatherDial("濕度", weather.humidityPct?.let{"$it%"} ?: "—", "相對濕度",
            (weather.humidityPct ?: 0)/100f,Color(0xFF46C4FF),Modifier.weight(1f))
    }
    Spacer(Modifier.height(12.dp))
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
        val feels=weather.feelsLikeC
        WeatherDial("體感",feels?.let{"${it.roundToInt()}°"} ?: "—", "目前體感溫度",
            (((feels ?: 15.0)+10)/50).toFloat(),Color(0xFF80D1E7),Modifier.weight(1f))
        WeatherDial("風速 · ${windDirectionLabel(weather.windDirectionDeg)}",weather.windKmh?.let{"${it.roundToInt()}"} ?: "—",
            "km/h · 10m",((weather.windKmh ?: 0.0)/60).toFloat(),Color(0xFF78D6B4),Modifier.weight(1f))
    }
}

fun usAqiLabel(value:Int?):String = when {
    value==null -> "暫無資料"
    value<=50 -> "良好"
    value<=100 -> "普通"
    value<=150 -> "敏感族群注意"
    value<=200 -> "不健康"
    value<=300 -> "非常不健康"
    else -> "危害"
}
