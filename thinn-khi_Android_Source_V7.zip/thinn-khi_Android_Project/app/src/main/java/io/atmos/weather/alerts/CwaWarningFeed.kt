package io.atmos.weather.alerts

import io.atmos.weather.location.LocationLabels
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import java.net.URL
import java.time.Instant
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

/** Reads official CWA RSS titles, not model-generated predictions. No fake alerts. */
data class CwaWarning(val title: String, val summary: String, val link: String, val issuedAt: Instant)

object CwaWarningFeed {
    const val OFFICIAL_URL = "https://www.cwa.gov.tw/V8/C/P/Warning/FIFOWS.html"
    private const val RSS_URL = "https://www.cwa.gov.tw/rss/Data/cwa_warning.xml"

    suspend fun forLocation(placeLabel: String): List<CwaWarning> = withContext(Dispatchers.IO) {
        try {
            val county = LocationLabels.clean(placeLabel).split(" · ")
                .drop(1).firstOrNull()?.replace('臺','台') ?: return@withContext emptyList()
            if (county.isBlank()) return@withContext emptyList()
            val conn = URL(RSS_URL).openConnection().apply {
                connectTimeout = 9000
                readTimeout = 9000
                setRequestProperty("User-Agent", "thinn-khi-weather/2.0")
            }
            val warnings = conn.getInputStream().use { input -> parse(input) }
            val now = Instant.now()
            warnings.filter { warning ->
                val haystack = (warning.title + " " + warning.summary).replace('臺','台')
                (haystack.contains(county) ||
                    haystack.contains("全台") || haystack.contains("各地") || haystack.contains("全國")) &&
                    warning.issuedAt.isAfter(now.minusSeconds(24 * 3600)) &&
                    warning.issuedAt.isBefore(now.plusSeconds(600))
            }.take(5)
        } catch (_: Exception) { emptyList() }
    }

    fun parse(input: java.io.InputStream): List<CwaWarning> {
        val parser = Xml.newPullParser().apply { setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false); setInput(input, "UTF-8") }
        val output = mutableListOf<CwaWarning>()
        var inside = false
        var field: String? = null
        var title = ""; var summary = ""; var link = ""; var date = ""
        while (parser.eventType != XmlPullParser.END_DOCUMENT) {
            when (parser.eventType) {
                XmlPullParser.START_TAG -> when (parser.name.lowercase()) {
                    "item" -> { inside = true; title = ""; summary = ""; link = ""; date = "" }
                    "title", "description", "link", "pubdate" -> if (inside) field = parser.name.lowercase()
                }
                XmlPullParser.TEXT -> if (inside) when (field) {
                    "title" -> title += parser.text
                    "description" -> summary += parser.text
                    "link" -> link += parser.text
                    "pubdate" -> date += parser.text
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name.equals("item", ignoreCase = true)) {
                        inside = false
                        val issuedAt = runCatching { ZonedDateTime.parse(date.trim(), DateTimeFormatter.RFC_1123_DATE_TIME).toInstant() }.getOrNull()
                        if (issuedAt != null && title.isNotBlank() && link.startsWith("https://www.cwa.gov.tw")) {
                            output += CwaWarning(title.trim(), summary.replace(Regex("<[^>]*>"), " ").trim(), link, issuedAt)
                        }
                    }
                    field = null
                }
            }
            parser.next()
        }
        return output
    }
}
