# thinn-khì｜完整候選 Android 工程 + GitHub Actions OTA 建置套件

**這是完整可提交的候選原始碼和 CI 工作流程，不是已簽署 APK，也不是聲稱全部功能已完成的正式 App。**

## 必須一起部署的路徑

```text
.github/workflows/build-apk.yml       ← 必須覆蓋 GitHub main 的舊工作流程
android-project/                      ← 必須真正提交的 Kotlin/Compose、assets、tests、backend、tools
發送OTA.sh                            ← Termux 一鍵「提交 → 測試 → 確認發布」
OTA_檔案校驗.sha256                     ← 套件檔案完整性校驗
完整需求_聊天起點至今.md                ← 聊天最初至今完整需求，並非都已實作
目前App未完成功能清單.md                ← 候選功能、待驗收及未完成項目
```

**不要在 GitHub 網頁上只上傳本 ZIP！** 這是之前「版本號更新但畫面沒改」的原因之一。工作流程本身也仍是舊版。一定要把 ZIP **解壓**，讓 `android-project/` 和 `.github/workflows/build-apk.yml` 在 GitHub 儲存庫成為可追蹤的檔案。

## 手機 Termux 執行

1. 將本 ZIP 下載到 Download 資料夾，先安裝並開啟 Termux。
2. 若從未開放儲存空間，先執行 `termux-setup-storage` 並允許存取。
3. 確認 `gh auth login` 已登入對 repo 具有推送及 Actions 權限的 GitHub 帳號。

```bash
pkg install gh git unzip coreutils -y
cd ~/storage/downloads
unzip -o thinn-khi-完整Android工程與GitHub-OTA工作流程-20261016.zip -d thinn-full
bash thinn-full/發送OTA.sh
```

此腳本將：檢查檔案校驗值、clone 目前 `main`、**以本包完整 `android-project/` 取代舊候選程式**、提交新 workflow、觸發 `publish_release=false` 的測試流程、等待 GitHub Actions 逐步執行。在測試未成功時會停止；通過後才要求使用者輸入 **「發送」**。不必手動上傳 ZIP 至 GitHub。

原始碼 `android-project/` 及 workflow 都會在 main 可直接瀏覽。如果 GitHub 分支保護、程式編譯、測試或簽章不符合要求，程序應停止；查看錯誤後修正再繼續。

## `.github/workflows/build-apk.yml` 真正改了什麼？

1. **完全不再抽取固定 V22 ZIP**，直接執行 GitHub `main` commit 裡的 `android-project/`，包含全部 Kotlin 程式碼。
2. 執行 36 項 Python 原始碼／OTA 回歸測試、Node.js backend 測試、Gradle Android 單元測試並組建 APK（前兩項為本地已通過數字，最終 CI 數字以執行結果為準）。
3. 建置前產生 `build_source_proof.json`：記錄 **完整 commit SHA**、Android app 內容總指紋與代表性檔案 SHA-256。該檔作為 assets 打入 APK，簽章／debug 後與預期校驗值逐位比對。
4. 產生 `BuildConfig.THINN_BUILD_SHA`，於 **設定 → 系統更新中心 → 目前安裝版本** 下顯示 10 碼編譯來源識別碼。更新後若這欄沒出現，表示安裝的 APK 並非這次候選工程。
5. 若具備現有正式版簽章金鑰，產生簽署 APK；正式發布前比較**與上一正式版相同憑證**、版本碼確實遞增、GitHub `main` 未在建置期間發生變更，以及相較上一個具憑證的 Release，Android App 內容確有差異。
6. 發布四個資產：`thinn-khi.apk`、`thinn-khi.apk.sha256`、`ota.json`、`embedded-build-source-proof.json`。一般用戶不需要 GitHub API 登入；更新中心使用公開 Release asset `ota.json`。

正式發送需要 GitHub Actions Secrets：`APK_KEYSTORE_BASE64`、`APK_KEYSTORE_PASSWORD`、`APK_KEY_PASSWORD`、`APK_KEY_ALIAS`，必須是與手機目前正式 APK 一致的簽章。**不要把金鑰加進 ZIP 或傳到聊天室。**

## 真實完成狀態（不可略過）

- ✅ 本地整合 Android Kotlin/Compose 候選原始碼、介面元件、各模組與 OTA 工作流程；工作流程語法、套件校驗、本地靜態測試與 backend 測試通過。
- ⏳ **尚未實際執行 Android SDK/Gradle 全面編譯**，也尚未成功將本包推送 GitHub `main`；因此沒有可直接安裝的簽署新版 APK。
- ⏳ Android 手機真實畫面、不同字體尺寸、通知／簽章覆蓋／OTA 操作尚須驗收。
- ❌ 全臺 132 候選地標不等於 132 個完成的 3D 模型；現有只有 **17 個獨立 GLB 原創原型**且首頁仍使用 PNG 預覽，真正即時 3D 飛越與完整高精度建模尚未完成。
- ⏳ 地震 EEW 正式端到端、完整衛星資料授權與外部 AI/通知部署等要求仍待查驗。請看 `目前App未完成功能清單.md` 和 `完整需求_聊天起點至今.md`。

**交付完成 ≠ 功能開發完成 ≠ CI 編譯完成 ≠ 正式 OTA 發布完成 ≠ 實機驗收完成。**
