#!/usr/bin/env bash
# Run this directly in Termux with: bash 發送OTA.sh
# Phases: push source -> CI non-release build -> user confirmation -> signed release -> verify assets.
set -euo pipefail

REPO='luc700428-hash/thinn-kh-.'
WF='build-apk.yml'
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

err() { printf '\n❌ %s\n' "$*" >&2; exit 1; }
info() { printf '\n▶ %s\n' "$*"; }

for bin in gh git sha256sum; do
  command -v "$bin" >/dev/null 2>&1 || err "缺少 $bin，請先在 Termux 執行：pkg install gh git coreutils -y"
done
[[ -s "$BASE/android-project/app/src/main/java/io/atmos/weather/MainActivity.kt" ]] || err '工程原始碼不存在，ZIP 可能未完整解壓。'
[[ -s "$BASE/.github/workflows/$WF" ]] || err '缺少 GitHub Actions 建置工作流程。'
[[ -s "$BASE/OTA_檔案校驗.sha256" ]] || err '缺少完整性校驗表。'
info '檢查完整 Android 原始碼與 GitHub workflow 的 SHA-256（不是測試舊 ZIP）'
(cd "$BASE" && sha256sum --check --status OTA_檔案校驗.sha256) || err 'OTA 包內容不完整或被修改，停止發送。'

gh auth status >/dev/null 2>&1 || err '請先 gh auth login 登入具有 repo 和 workflow 權限的 GitHub 帳號。'
gh auth setup-git >/dev/null

info '從 GitHub 取得現在的 main（不強制覆蓋其他程式）'
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
gh repo clone "$REPO" "$WORK/repo" -- --depth 1 || err '無法複製 GitHub 專案。'
cd "$WORK/repo"
[[ "$(git branch --show-current)" == main ]] || err '預期 GitHub 的預設分支為 main，為避免誤改已停止。'
rm -rf android-project
cp -R "$BASE/android-project" android-project
mkdir -p .github/workflows
cp "$BASE/.github/workflows/$WF" ".github/workflows/$WF"
git add -A -- android-project ".github/workflows/$WF"
if ! git diff --cached --quiet; then
  info '即將真正提交的檔案修改如下（含 android-project 與 .github/workflows）'
  git diff --cached --stat | tail -n 28
  info '將完整 Kotlin Android 專案與新版 GitHub 工作流程提交到 main'
  git -c user.name='thinn-khì Termux OTA' -c user.email='termux@users.noreply.github.com' \
    commit -m 'build: integrate chat requirements into tracked Android OTA source'
  git push origin HEAD:main || err '推送失敗（可能是 GitHub 分支保護或登入權限）；未發布 OTA。'
else
  info 'main 已包含相同原始碼，不需重新提交。'
fi
SHA="$(git rev-parse HEAD)"
printf '本次要建置的 GitHub commit：%s\n' "$SHA"

previous_dispatch_id() {
  gh run list --repo "$REPO" --workflow "$WF" --branch main --event workflow_dispatch --limit 100 \
    --json databaseId --jq '[.[].databaseId] | max // 0'
}

find_new_dispatch() {
  local before="$1" id='' tries=0
  while (( tries < 36 )); do
    id="$(gh run list --repo "$REPO" --workflow "$WF" --branch main --event workflow_dispatch --limit 60 \
      --json databaseId,headSha --jq ".[] | select(.databaseId > $before and .headSha == \"$SHA\") | .databaseId" 2>/dev/null | head -n1 || true)"
    if [[ "$id" =~ ^[0-9]+$ ]]; then printf '%s\n' "$id"; return 0; fi
    tries=$((tries+1)); sleep 5
  done
  return 1
}

dispatch() {
  local publish="$1" attempt=0
  while (( attempt < 8 )); do
    if gh workflow run "$WF" --repo "$REPO" --ref main -f "publish_release=$publish"; then return 0; fi
    attempt=$((attempt+1))
    info 'GitHub 可能仍在登錄新版 workflow；稍後重試…'
    sleep 8
  done
  return 1
}

info '執行首次完整測試建置（不發布）'
BEFORE="$(previous_dispatch_id)" || err '無法取得 GitHub Actions 執行列表。'
dispatch false || err '無法啟動測試編譯；未發布 OTA。'
CI_ID="$(find_new_dispatch "$BEFORE")" || err '找不到剛啟動的測試建置；未發布 OTA。'
printf '首次建置紀錄：https://github.com/%s/actions/runs/%s\n' "$REPO" "$CI_ID"
gh run watch "$CI_ID" --repo "$REPO" --exit-status || err '測試、Android 編譯或簽章步驟失敗；未發布 OTA。請查看上面連結的錯誤。'

info 'CI 已通過。此時尚未發布更新。'
printf '\n⚠  CI 通過不代表所有功能已經過手機實機驗收。\n'
printf '⚠  已知全臺高精度即時 3D 與部分資料源仍未完成，請勿宣稱全部功能已完成。\n'
if [[ "${1:-}" != '--confirm-publish' ]]; then
  printf '\n如確定要將這個候選版本發布給已安裝 App 的使用者，請輸入「發送」：'
  IFS= read -r answer
  [[ "$answer" == '發送' ]] || { info '你選擇保留測試結果，不發布正式 OTA。'; exit 0; }
fi

info '開始正式 OTA 建置與簽章發布'
BEFORE="$(previous_dispatch_id)"
dispatch true || err '正式 OTA 建置啟動失敗。'
RELEASE_ID="$(find_new_dispatch "$BEFORE")" || err '找不到正式發送的工作流程。'
printf '正式發送紀錄：https://github.com/%s/actions/runs/%s\n' "$REPO" "$RELEASE_ID"
gh run watch "$RELEASE_ID" --repo "$REPO" --exit-status || err '正式 OTA 編譯／簽章／與舊版憑證比對／發布失敗，沒有可驗證的新 OTA。'

RUN_NUMBER="$(gh run view "$RELEASE_ID" --repo "$REPO" --json number --jq '.number')"
[[ "$RUN_NUMBER" =~ ^[0-9]+$ ]] || err '無法確認本次正式版號。'
TAG="v22.0.$RUN_NUMBER"
info "驗證正式發布 $TAG 含有 APK、SHA-256、ota.json 與編譯來源憑證"
ASSETS="$(gh release view "$TAG" --repo "$REPO" --json assets --jq '.assets[].name')" || err '已完成建置，但未確認 Release 存在。'
for name in thinn-khi.apk thinn-khi.apk.sha256 ota.json embedded-build-source-proof.json; do
  grep -qx "$name" <<<"$ASSETS" || err "Release 缺少 $name，請勿宣稱 OTA 可使用。"
done
printf '\n✅ 新 OTA 已在 GitHub 正式發布：\nhttps://github.com/%s/releases/tag/%s\n' "$REPO" "$TAG"
printf '✅ 使用者可在 App「系統更新中心」檢查公開 ota.json，查看程式來源 commit 識別碼。\n'
printf '⚠ 正式發布後，仍需在手機驗收首頁、事項、地震、定位、微縮地標與 OTA 安裝流程。\n'
