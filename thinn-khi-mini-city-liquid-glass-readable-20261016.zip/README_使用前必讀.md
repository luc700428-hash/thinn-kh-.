> **最新版改版說明：** 本交付已加入「微縮城市與文字重排」階段工程。以前一次 UI 交付的 15 項測試為歷史記錄；請以 `READ_THIS_微縮城市與文字改版.md` 和 `docs/微縮城市與文字重排_實作狀態.md` 的本次 23 項驗證及已知限制為準。

# thinn-khì — iOS 風格全域一致性改版工程

這不是可直接安裝的 APK；這是**實際修改的完整 Android 原始碼**、可編譯它的 GitHub Actions、測試與部署工具。未經 CI 與實機驗證前不得宣稱正式完成。

## 本次重大修正

1. `android-project/` **直接存放在 GitHub 原始碼目錄**。新版 `.github/workflows/build-apk.yml` 直接編譯它，**完全不依賴舊的 V22 ZIP**。
2. 新增一套 Android Jetpack Compose 的 iOS-inspired 全域字體、色彩、按鈕、圖示、玻璃材質、分組清單、動畫與無障礙組件，不移植或夾帶 Apple 私有 UI 字型、SF Symbols 或框架。
3. 實際修改首次啟動、主分頁導覽、工具中心、設定首頁、進階控制共享元件、更新中心、時間選擇器，以及全域共用對話框／文字輸入欄／滑桿／開關。
4. 新增離線「我的事項」：可新增、修改、標記完成、刪除、設定日期與時間、啟用本機 WorkManager 提醒（非精確鬧鐘）。資料不傳至第三方天氣或 AI 服務。
5. 既有天氣、地震、雷達、穿搭、Widget、天氣音效、FCM、簽章配置及 22 縣市地標保留。這些功能尚需正式 Android 回歸測試。

## 部署（僅需首次改用 GitHub 追蹤原始碼）

將本 ZIP 解壓，進入解壓資料夾，在 Termux 使用 `bash deploy-to-github.sh`。執行前必須已經使用 `gh auth login` 登入**你自己的 GitHub 帳號**；不會要求把任何 Token 放入 App。

該腳本會：驗證交付包中所有必要檔案 → 用 `gh repo clone` 取得原始 Repo → 提交可閱讀的 Kotlin、Compose、資源與 workflow → 推送 `main`。**不會主動發布正式 OTA**。GitHub `push` 會自動觸發一次 CI 編譯。若受 GitHub 分支規則限制，腳本會失敗並停止，不會繞過保護。

## 第一次先等 CI 測試成功

在 Termux：

```bash
gh run list --repo 'luc700428-hash/thinn-kh-.' --workflow build-apk.yml --limit 3
```

確認 GitHub Actions 建置成功後，再用原本熟悉的指令發布：

```bash
gh workflow run build-apk.yml --repo 'luc700428-hash/thinn-kh-.' --ref main -f publish_release=true
```

更新中心將從公開 GitHub Release 取得 `ota.json`，不需要朋友登入 GitHub；朋友目前手機上的舊版仍可能因 API 403 而無法發現首個新版，必要時**第一次手動下載同簽章 APK 覆蓋安裝**。未經確認原始簽章，不得建議刪除舊版 App，避免資料遺失。

## 已測試與未測試

**已本地測試：** 15 組 Python 靜態／OTA 規則測試、7 組 Node.js EEW 後端測試、5 項 Kotlin 模型斷言；GitHub workflow YAML 可解析，source layout 已檢查。

**尚未測試：** 本容器沒有 Android SDK/Gradle，尚未執行完整 `:app:assembleRelease`、Compose UI 儀器測試、TalkBack、實機震動／動畫效能、系統通知授權與完整 OTA 覆蓋升級。以上項目在 CI 及實機測試通過前不屬於已完成驗收。

詳細內容見 `docs/全頁面_UI與驗收追蹤.md` 和 `docs/測試與發布門檻.md`。
