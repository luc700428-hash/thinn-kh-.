# thinn-khì | 微縮城市、字體與液態玻璃一致性改版

這是 **Android App 完整原始碼交付包，不是已簽署可直接安裝的 APK**。

主要更新：全 App 10–14sp 小字調整（282 個明確字級）；22 縣市、20 個島嶼區域、132 地標目錄；12 個獨立原創 GLB 原型及對應預覽；GPS 區域優先、同地區輪換、玻璃卡片大標籤、減少動態相容；持續保留 Android 天氣、地震、通知、事項、Widget、公開 OTA 工作流程。

不能將此版本宣稱「132 地標都已完成真實精細建模」。12 個仍是示意原型，其他 120 個為目錄候選。Filament 即時 3D、完整 Fly-through、行政 GIS 高精度與 Android 實機驗收仍待後續整合。

完整差異與實作狀態：`docs/微縮城市與文字重排_實作狀態.md`。

## 交付到 GitHub

1. 在 Android 的 Download 資料夾解壓此 ZIP；Termux 切換至解壓後的資料夾。
2. 先使用 `gh auth status` 確認自己的 GitHub 權限。
3. 執行 `bash deploy-to-github.sh`。腳本只會推上原始碼並觸發 CI，**不直接發布官方 OTA**。
4. 用 `gh run list --repo 'luc700428-hash/thinn-kh-.' --workflow build-apk.yml --limit 3` 查看 CI；CI 失敗請先修正，勿勉強發布。

注意：目前原始碼完整 Android 編譯尚未在本機驗證。推送後須用 Actions 的 Kotlin 編譯結果與手機實測確認。
