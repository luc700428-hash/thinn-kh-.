package io.atmos.weather.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Query

/** Air-quality model estimates, not Taiwan EPA station measurements. */
interface OpenMeteoAirQualityApi {
    @GET("v1/air-quality")
    suspend fun currentAir(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String = "pm2_5,pm10,aerosol_optical_depth",
        @Query("timezone") timezone: String = "auto"
    ): AirQualityResponse
}
data class AirQualityResponse(val current: AirQualityCurrent?)
data class AirQualityCurrent(
    @SerializedName("us_aqi") val usAqi: Int?,
    @SerializedName("pm2_5") val pm25: Double?,
    @SerializedName("pm10") val pm10: Double?,
    @SerializedName("aerosol_optical_depth") val aerosolOpticalDepth: Double?
)
