package io.atmos.weather.update

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import io.atmos.weather.BuildConfig
import io.atmos.weather.haptics.HapticEngine
import io.atmos.weather.haptics.LocalHapticEngine
import io.atmos.weather.presentation.home.LocalAppearance
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private val glassText=Color.White
private val soft=Color.White.copy(alpha=.73f)
private val blue=Color(0xFF8EE6FF)

/** Full-screen liquid-glass release centre. Network operations are async and user-initiated. */
@Composable
fun AppUpdatePage(onClose:()->Unit) {
    val context=LocalContext.current
    val haptic=LocalHapticEngine.current
    val appearance=LocalAppearance.current
    val scope=rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var installing by remember { mutableStateOf(false) }
    var checked by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<ReleaseInfo?>(null) }
    var status by remember { mutableStateOf("開啟更新中心，正在檢查 GitHub 最新正式版本…") }
    var downloaded by remember { mutableLongStateOf(0L) }
    var totalBytes by remember { mutableStateOf<Long?>(null) }
    val highlights=listOf(
        "獨立 App 更新中心：目前版本與下一版版本特性",
        "液態玻璃頁面、柔光邊緣與觸覺互動",
        "觸覺強度整合為單一滑桿，預設 100%",
        "10 秒模擬天氣事件，包含倒數與畫面、音效、觸覺連動",
        "持續使用 Open-Meteo 空氣品質資料與正式簽章 OTA 更新"
    )
    fun check() {
        if(checking || installing) return
        checking=true; checked=false; pending=null
        haptic?.play(HapticEngine.Event.TAP)
        scope.launch {
            val outcome=runCatching { AppUpdater.findUpdate(context) }
            outcome.onSuccess {
                pending=it
                status=if(it==null) "目前沒有偵測到較新的正式版本" else "發現可安裝的新版本"
                if(it!=null) haptic?.play(HapticEngine.Event.RELEASE)
            }.onFailure { status="檢查失敗：${it.localizedMessage ?: "網路或 Release 不可用"}" }
            checked=true;checking=false
        }
    }
    LaunchedEffect(Unit) { check() }
    val glow=rememberInfiniteTransition(label="update glass glow")
    val light by glow.animateFloat(.10f,.25f,infiniteRepeatable(tween((3800 - appearance.liquidMotion.coerceIn(0f,1f)*2600).toInt(),easing=FastOutSlowInEasing),RepeatMode.Reverse),label="edge")
    Dialog(onDismissRequest=onClose,properties=DialogProperties(usePlatformDefaultWidth=false)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
            Color(0xFF07162A),Color(0xFF153B5A),Color(0xFF09243C))))) {
            Box(Modifier.fillMaxWidth().height(280.dp)
                .background(Brush.radialGradient(listOf(blue.copy(alpha=light),Color.Transparent))))
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal=22.dp).padding(top=39.dp,bottom=44.dp)) {
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
                    IconButton(onClick={haptic?.play(HapticEngine.Event.TAP); onClose()}) {
                        Icon(Icons.Rounded.ArrowBack,"返回",tint=glassText)
                    }
                    Spacer(Modifier.width(4.dp))
                    Column(Modifier.weight(1f)) {
                        Text("App 更新",color=glassText,fontSize=27.sp,fontWeight=FontWeight.Bold)
                        Text("版本與更新中心 · thinn-khì",color=soft,fontSize=12.sp)
                    }
                    Icon(Icons.Rounded.AutoAwesome,null,tint=blue,modifier=Modifier.size(25.dp))
                }
                Spacer(Modifier.height(25.dp))
                UpdateGlassBox(glow=light) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Rounded.CheckCircle,null,tint=blue,modifier=Modifier.size(30.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("目前安裝版本",color=soft,fontSize=12.sp)
                            Text("thinn-khì ${BuildConfig.VERSION_NAME}",color=glassText,
                                fontSize=22.sp,fontWeight=FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("本版本特性",color=glassText,fontWeight=FontWeight.SemiBold,fontSize=16.sp)
                    Spacer(Modifier.height(7.dp))
                    highlights.forEach { item ->
                        Row(Modifier.padding(vertical=5.dp),verticalAlignment=Alignment.Top) {
                            Icon(Icons.Rounded.Check,null,tint=blue,modifier=Modifier.size(17.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(item,color=soft,fontSize=13.sp,lineHeight=19.sp)
                        }
                    }
                }
                Spacer(Modifier.height(17.dp))
                UpdateGlassBox(glow=light) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Rounded.NewReleases,null,tint=blue,modifier=Modifier.size(28.dp))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("下一個版本",color=soft,fontSize=12.sp)
                            Text(pending?.version ?: if(checking) "檢查中…" else "暫無新版",
                                color=glassText,fontSize=21.sp,fontWeight=FontWeight.SemiBold)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    AnimatedVisibility(visible=checking) {
                        LinearProgressIndicator(Modifier.fillMaxWidth(),color=blue)
                    }
                    Text(status,color=soft,fontSize=13.sp,lineHeight=19.sp)
                    pending?.let { release ->
                        Spacer(Modifier.height(16.dp))
                        HorizontalDivider(color=Color.White.copy(alpha=.16f))
                        Spacer(Modifier.height(12.dp))
                        Text("新版本特性與更新說明",color=glassText,fontSize=16.sp,fontWeight=FontWeight.SemiBold)
                        Spacer(Modifier.height(9.dp))
                        Text(release.notes.ifBlank { "開發者沒有提供本次更新說明。" },
                            color=soft,fontSize=13.sp,lineHeight=20.sp)
                        Spacer(Modifier.height(17.dp))
                        if(installing) {
                            val fraction=totalBytes?.takeIf { it>0L }?.let { (downloaded.toFloat()/it).coerceIn(0f,1f) }
                            Text(if(fraction!=null) "下載進度 ${(fraction*100).roundToInt()}%" else "正在下載更新…",
                                color=glassText,fontSize=13.sp)
                            LinearProgressIndicator(progress={fraction ?: 0f},modifier=Modifier.fillMaxWidth(),color=blue)
                        }
                        Button(onClick={
                            haptic?.play(HapticEngine.Event.TAP)
                            installing=true;downloaded=0L;totalBytes=null
                            scope.launch {
                                val result=runCatching {
                                    AppUpdater.downloadAndInstall(context,release) { soFar,total ->
                                        downloaded=soFar;totalBytes=total
                                    }
                                }
                                status=result.fold({"APK 已下載驗證，請在 Android 安裝程式確認更新。"},
                                    {"更新失敗：${it.localizedMessage ?: "請稍後重試"}"})
                                installing=false
                            }
                        },enabled=!installing && !checking,modifier=Modifier.fillMaxWidth()) {
                            Icon(Icons.Rounded.Download,null)
                            Spacer(Modifier.width(8.dp))
                            Text(if(installing) "正在下載與驗證…" else "下載並更新")
                        }
                    }
                    Spacer(Modifier.height(13.dp))
                    OutlinedButton(onClick={check()},enabled=!checking && !installing,
                        modifier=Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.Refresh,null)
                        Spacer(Modifier.width(6.dp))
                        Text("重新檢查更新",color=glassText)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Text("更新來源：GitHub Releases。APK 會進行 SHA-256、套件名稱與版本檢查；覆蓋升級需相同簽署金鑰，安裝需經 Android 系統確認。",
                    color=soft,fontSize=11.sp,lineHeight=17.sp)
            }
        }
    }
}

@Composable
private fun UpdateGlassBox(glow:Float,content:@Composable ColumnScope.()->Unit) {
    val style=LocalAppearance.current
    val fill=(.035f + style.glassOpacity.coerceIn(0f,1f)*.12f + style.glassFrost.coerceIn(0f,1f)*.035f).coerceIn(0f,.28f)
    val rim=(.09f + style.edgeLight.coerceIn(0f,1f)*(.08f+glow*.9f)).coerceIn(0f,.58f)
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(27.dp))
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha=fill+.025f), Color.White.copy(alpha=fill*.67f))))
        .border(1.dp,Color.White.copy(alpha=rim),RoundedCornerShape(27.dp))
        .padding(19.dp),content=content)
}
