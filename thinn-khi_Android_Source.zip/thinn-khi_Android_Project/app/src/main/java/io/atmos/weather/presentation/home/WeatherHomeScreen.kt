package io.atmos.weather.presentation.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.atmos.weather.domain.model.*
import io.atmos.weather.domain.visual.*
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.cos

private val White = Color.White
private val TextSoft = Color.White.copy(alpha = .77f)
private val GlassShape = RoundedCornerShape(30.dp)

@Composable
fun WeatherHomeScreen(viewModel: WeatherViewModel, onLocate: () -> Unit, onOpen3D: (WeatherScene?)->Unit) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snapshot = state.weather
    val isNight = snapshot?.isDay == false
    val rainy = snapshot?.condition in setOf(WeatherCondition.RAIN,WeatherCondition.THUNDERSTORM)
    val snow = snapshot?.condition == WeatherCondition.SNOW
    val colors = when {
        isNight -> listOf(Color(0xFF0B152F), Color(0xFF24395C), Color(0xFF516078))
        rainy -> listOf(Color(0xFF21354D), Color(0xFF586F8D), Color(0xFF90A9BF))
        snow -> listOf(Color(0xFF4A7296), Color(0xFF88AEC8), Color(0xFFCAE2F0))
        else -> listOf(Color(0xFF1F67A0), Color(0xFF64B5DD), Color(0xFFA8DDEC))
    }
    val haptic = LocalHapticFeedback.current
    var searchOpen by remember { mutableStateOf(false) }
    var details by remember { mutableStateOf<Pair<String,String>?>(null) }
    val transition = rememberInfiniteTransition(label="sky")
    val motion by transition.animateFloat(0f,1f,infiniteRepeatable(tween(11500, easing=LinearEasing)), label="weather motion")

    MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFFB5EDFF))) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(colors))) {
            Box(Modifier.fillMaxWidth().height(340.dp).offset(x=110.dp,y=(-130).dp)
                .blur(92.dp).background(Color.White.copy(alpha=if (isNight) .03f else .2f),CircleShape))
            if (snapshot != null) SkyParticles(snapshot.condition, motion, Modifier.fillMaxSize())
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal=20.dp).padding(top=42.dp,bottom=36.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically,
                    horizontalArrangement=Arrangement.SpaceBetween) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Waves, null, tint=White, modifier=Modifier.size(22.dp))
                        Spacer(Modifier.width(9.dp))
                        Text("thinn-khì",color=White,fontWeight=FontWeight.SemiBold,fontSize=15.sp,letterSpacing=0.6.sp)
                    }
                    Row {
                        HeaderButton(Icons.Rounded.MyLocation,"使用目前位置") { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onLocate() }
                        Spacer(Modifier.width(8.dp))
                        HeaderButton(Icons.Rounded.Search,"搜尋城市") { searchOpen=true }
                        Spacer(Modifier.width(8.dp))
                        HeaderButton(Icons.Rounded.Refresh,"更新資料") { viewModel.onIntent(WeatherIntent.Refresh) }
                    }
                }
                Spacer(Modifier.height(25.dp))
                LazyRow(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                    items(SampleCities.all) { city ->
                        val selected = city.id == state.city.id
                        Box(Modifier.clip(CircleShape).background(White.copy(alpha=if(selected) .26f else .1f))
                            .border(1.dp,White.copy(alpha=if(selected) .58f else .19f),CircleShape)
                            .clickable { viewModel.onIntent(WeatherIntent.SelectCity(city));haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                            .padding(horizontal=14.dp,vertical=9.dp)) {
                            Text(city.name,color=White,fontSize=12.sp,fontWeight=if(selected) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
                Spacer(Modifier.height(32.dp))
                Text(state.city.name, color=White,fontSize=29.sp,fontWeight=FontWeight.Medium,
                    modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                if (snapshot != null) {
                    Text("${snapshot.temperatureC.roundToInt()}°",fontSize=104.sp,lineHeight=106.sp,
                        fontWeight=FontWeight.Thin,color=White,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
                    Text(snapshot.condition.label(),color=White,fontSize=18.sp,fontWeight=FontWeight.Medium,
                        modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
                    Spacer(Modifier.height(7.dp))
                    Text("最高 ${snapshot.maxTempC?.roundToInt()?.let { "$it°" } ?: "—"}   最低 ${snapshot.minTempC?.roundToInt()?.let { "$it°" } ?: "—"}     體感 ${snapshot.feelsLikeC?.roundToInt()?.let { "$it°" } ?: "—"}",
                        color=TextSoft,fontSize=14.sp,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
                } else if(state.loading) {
                    Spacer(Modifier.height(60.dp)); CircularProgressIndicator(color=White,modifier=Modifier.align(Alignment.CenterHorizontally))
                } else {
                    Text("尚無天氣資料，請檢查網路連線",color=White,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(28.dp))
                GlassCard {
                    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                        Column {
                            Text("LIVING LANDMARK",fontSize=10.sp,color=TextSoft,letterSpacing=2.sp)
                            Spacer(Modifier.height(5.dp))
                            Text(state.scene?.landmark?.label() ?: "天氣微縮景觀",color=White,fontSize=19.sp,fontWeight=FontWeight.SemiBold)
                        }
                        Text(if(isNight) "夜間模式" else "即時天氣",color=White.copy(alpha=.9f),fontSize=11.sp)
                    }
                    LandmarkCanvas(state.scene, motion, Modifier.fillMaxWidth().height(248.dp))
                    TextButton(onClick={onOpen3D(state.scene)}, modifier=Modifier.align(Alignment.CenterHorizontally)) {
                        Icon(Icons.Rounded.ThreeDRotation,null,tint=White,modifier=Modifier.size(18.dp));Spacer(Modifier.width(8.dp));Text("開啟 3D 互動地標",color=White)
                    }
                    Text("跟隨天氣變化的微縮地標 · 拖曳可微幅傾斜",fontSize=11.sp,color=TextSoft,
                        textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
                }
                Spacer(Modifier.height(15.dp))
                if(snapshot != null) {
                    GlassCard {
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Icon(Icons.Rounded.Schedule,null,tint=White.copy(alpha=.8f),modifier=Modifier.size(17.dp))
                            Spacer(Modifier.width(8.dp)); Text("未來 24 小時",fontSize=14.sp,color=White,fontWeight=FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(13.dp))
                        LazyRow(horizontalArrangement=Arrangement.spacedBy(17.dp)) {
                            items(snapshot.nextHours.filterIndexed { index,_ -> index % 2 == 0 }.take(12)) { hour ->
                                val hourLabel = hour.at.atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
                                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                                    Text(hourLabel,color=TextSoft,fontSize=11.sp)
                                    Spacer(Modifier.height(10.dp))
                                    Icon(if(rainy) Icons.Rounded.WaterDrop else Icons.Rounded.WbSunny,null,
                                        tint=White,modifier=Modifier.size(19.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("${hour.temperatureC?.roundToInt() ?: "—"}°",color=White,fontSize=15.sp,fontWeight=FontWeight.SemiBold)
                                    Spacer(Modifier.height(5.dp))
                                    Text("${hour.precipitationProbabilityPct ?: "—"}%",color=Color(0xFFD8F3FF),fontSize=10.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(15.dp))
                        TemperatureCurve(snapshot.nextHours.take(24),Modifier.fillMaxWidth().height(68.dp))
                    }
                    Spacer(Modifier.height(15.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        MetricCard("濕度",snapshot.humidityPct?.let { "$it%" } ?: "—", "相對濕度", Icons.Rounded.WaterDrop, Modifier.weight(1f)) { details="濕度" to "目前空氣的相對濕度，數值越高通常體感越潮濕。" }
                        MetricCard("降雨機率",snapshot.nextHourRainProbabilityPct?.let { "$it%" } ?: "—", "下一小時",Icons.Rounded.Umbrella,Modifier.weight(1f)) { details="降雨機率" to "逐小時降雨機率為氣象模型預測，並非實際降雨量。" }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        MetricCard("風速",snapshot.windKmh?.let { "${it.roundToInt()}" } ?: "—", "km/h",Icons.Rounded.Air,Modifier.weight(1f)) { details="風速" to "地表約 10 公尺高度的預報風速，單位為公里每小時。" }
                        MetricCard("氣壓",snapshot.pressureHpa?.let { "${it.roundToInt()}" } ?: "—", "hPa",Icons.Rounded.Speed,Modifier.weight(1f)) { details="氣壓" to "目前地表氣壓，單位為百帕。" }
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                        MetricCard("紫外線",snapshot.currentUv?.let { String.format("%.1f",it) } ?: "—","UV Index",Icons.Rounded.WbSunny,Modifier.weight(1f)) { details="紫外線指數" to "UV 指數越高，外出時越需要注意遮陽與防曬。" }
                        MetricCard("日出 / 日落", snapshot.sunrise?.atZone(ZoneId.systemDefault())?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: "—",
                            "日落 ${snapshot.sunset?.atZone(ZoneId.systemDefault())?.format(DateTimeFormatter.ofPattern("HH:mm")) ?: "—"}", Icons.Rounded.WbTwilight,Modifier.weight(1f)) { details="日出日落" to "時間會以手機時區顯示，跨時區城市也依此規則。" }
                    }
                }
                if(state.loading && snapshot!=null) {
                    Spacer(Modifier.height(14.dp)); LinearProgressIndicator(Modifier.fillMaxWidth(),color=White)
                }
                if(state.stale || state.error != null) {
                    Spacer(Modifier.height(13.dp))
                    Text(if(state.stale) "目前顯示離線快取，可能已過時" else "更新失敗：${state.error}",
                        color=Color(0xFFFFE4C6),fontSize=13.sp,modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
                }
                Spacer(Modifier.height(22.dp))
                Text("數據提供：Open-Meteo.com  ·  依其授權條款使用",color=TextSoft,fontSize=11.sp,
                    modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text("天氣是預測資訊，請以當地官方警報為準。",color=TextSoft,fontSize=11.sp,
                    modifier=Modifier.fillMaxWidth(),textAlign=TextAlign.Center)
            }
        }
        if (searchOpen) SearchDialog(state.searchResults,state.searching,
            onQuery=viewModel::search, onSelect={ viewModel.onIntent(WeatherIntent.SelectCity(it));searchOpen=false }, onClose={searchOpen=false})
        details?.let { info -> AlertDialog(onDismissRequest={details=null},
            confirmButton={ TextButton(onClick={details=null}) { Text("了解") } },
            title={Text(info.first)},text={Text(info.second)}) }
    }
}

@Composable
private fun HeaderButton(image: androidx.compose.ui.graphics.vector.ImageVector, description: String, click: ()->Unit) {
    Box(Modifier.size(37.dp).clip(CircleShape).background(White.copy(alpha=.13f))
        .border(1.dp,White.copy(alpha=.16f),CircleShape).clickable(onClick=click), contentAlignment=Alignment.Center) {
        Icon(image,contentDescription=description,tint=White,modifier=Modifier.size(19.dp))
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.()->Unit) {
    Column(Modifier.fillMaxWidth().clip(GlassShape)
        .background(Brush.linearGradient(listOf(White.copy(alpha=.22f), White.copy(alpha=.1f))))
        .border(1.dp,White.copy(alpha=.26f),GlassShape).padding(19.dp), content=content)
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String,
                       symbol: androidx.compose.ui.graphics.vector.ImageVector,
                       modifier: Modifier=Modifier, onClick:()->Unit) {
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(White.copy(alpha=.14f))
        .border(1.dp,White.copy(alpha=.23f),RoundedCornerShape(24.dp)).clickable(onClick=onClick).padding(17.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) {
            Icon(symbol,contentDescription=null,tint=TextSoft,modifier=Modifier.size(16.dp))
            Spacer(Modifier.width(7.dp))
            Text(title,color=TextSoft,fontSize=12.sp)
        }
        Spacer(Modifier.height(17.dp))
        Text(value,color=White,fontSize=28.sp,fontWeight=FontWeight.Light)
        Text(subtitle,color=TextSoft,fontSize=11.sp)
    }
}

@Composable
private fun SearchDialog(results: List<WeatherCity>, searching: Boolean, onQuery:(String)->Unit,
    onSelect:(WeatherCity)->Unit,onClose:()->Unit) {
    var query by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest=onClose,title={Text("尋找全球城市")},
        text={ Column {
            OutlinedTextField(value=query,onValueChange={query=it; onQuery(it)},singleLine=true,
                label={Text("城市名稱 / City")},modifier=Modifier.fillMaxWidth())
            if(searching) { Spacer(Modifier.height(9.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
            Spacer(Modifier.height(8.dp))
            results.take(6).forEach { city ->
                Text(city.name,modifier=Modifier.fillMaxWidth().clickable { onSelect(city) }.padding(vertical=12.dp),fontSize=15.sp)
                HorizontalDivider(color=Color.LightGray.copy(alpha=.22f))
            }
            if(query.length>1 && results.isEmpty() && !searching) Text("無符合結果，請嘗試其他關鍵字",fontSize=12.sp)
        } },confirmButton={TextButton(onClick=onClose){Text("關閉")}})
}

@Composable
private fun TemperatureCurve(hours: List<HourlyWeather>, modifier: Modifier=Modifier) {
    val valid = hours.mapNotNull { it.temperatureC }
    Canvas(modifier) {
        if(valid.size<2) return@Canvas
        val min = valid.minOrNull() ?: 0.0
        val max = valid.maxOrNull() ?: 1.0
        val range = (max-min).coerceAtLeast(2.0)
        val points = valid.mapIndexed { i,value ->
            Offset(i.toFloat()/(valid.size-1)*size.width,
                size.height*.79f-((value-min)/range).toFloat()*size.height*.6f)
        }
        val path=Path().apply { moveTo(points[0].x,points[0].y);points.drop(1).forEach{lineTo(it.x,it.y)} }
        drawPath(path,White.copy(alpha=.8f),style=Stroke(width=3.dp.toPx(),cap=StrokeCap.Round,join=PathJoin.Round))
        points.forEach { drawCircle(White.copy(alpha=.87f),2.dp.toPx(),it) }
    }
}

@Composable
private fun SkyParticles(condition: WeatherCondition, phase:Float, modifier:Modifier=Modifier) {
    val rainy = condition in setOf(WeatherCondition.RAIN,WeatherCondition.THUNDERSTORM)
    val snowy = condition == WeatherCondition.SNOW
    if(!rainy && !snowy) return
    Canvas(modifier) {
        for(i in 0 until if(rainy) 68 else 43) {
            val x=((i*0.6180339f+.1f)%1f)*size.width
            val y=(((i*0.381966f+phase*(if(rainy) 3.8f else .72f))%1f))*size.height
            if(rainy) drawLine(White.copy(alpha=.17f),Offset(x,y),Offset(x-6.dp.toPx(),y+12.dp.toPx()),1.dp.toPx())
            else drawCircle(White.copy(alpha=.44f),1.8.dp.toPx(),Offset(x,y))
        }
    }
}

@Composable
private fun LandmarkCanvas(scene: WeatherScene?, phase:Float, modifier:Modifier=Modifier) {
    var tilt by remember { mutableFloatStateOf(0f) }
    val animatedTilt by animateFloatAsState(tilt, spring(dampingRatio=Spring.DampingRatioMediumBouncy, stiffness=Spring.StiffnessLow),label="landmark-tilt")
    Canvas(modifier.graphicsLayer { rotationY=animatedTilt; cameraDistance=12f * density }
        .pointerInput(Unit) { detectDragGestures(onDragEnd={tilt=0f}, onDragCancel={tilt=0f}) { change, amount ->
            change.consume();tilt=(tilt+amount.x*.14f).coerceIn(-12f,12f)
        } }) {
        val w=size.width; val h=size.height
        drawCircle(Color.White.copy(alpha=.13f),h*.33f,Offset(w*.52f,h*.51f))
        drawOval(Color(0xFF0A2037).copy(alpha=.18f),Offset(w*.09f,h*.77f),Size(w*.83f,h*.17f))
        drawOval(Color(0xFFB0DBD2).copy(alpha=.68f),Offset(w*.15f,h*.72f),Size(w*.73f,h*.14f))
        val landmark=scene?.landmark ?: LandmarkId.WEATHER_COTTAGE
        when (landmark) {
            LandmarkId.TAIPEI_101 -> drawTaipei101(w,h,scene?.nightLight==1f)
            LandmarkId.TOKYO_SKYTREE -> drawSkytree(w,h)
            LandmarkId.EIFFEL_TOWER -> drawEiffel(w,h)
            LandmarkId.WEATHER_COTTAGE -> drawCottage(w,h,scene?.nightLight==1f,scene?.snowAccumulation ?: 0f)
        }
        if((scene?.precipitationIntensity ?: 0f) > .1f) {
            val snowy=(scene?.snowAccumulation ?: 0f) > .1f
            for(i in 0..24) {
                val x=w*((i*.618f+phase*(if(snowy) .2f else -.08f))%1f)
                val y=h*((i*.37f+phase*(if(snowy) .6f else 2.5f))%1f)
                if(snowy) drawCircle(White.copy(alpha=.78f),2.1.dp.toPx(),Offset(x,y))
                else drawLine(Color.White.copy(alpha=.58f),Offset(x,y),Offset(x-4.dp.toPx(),y+9.dp.toPx()),1.5.dp.toPx())
            }
        }
    }
}

private fun DrawScope.drawTaipei101(w:Float,h:Float,night:Boolean) {
    val front=Color(0xFF5CB9BA);val side=Color(0xFF2F7F92)
    drawRect(Color(0xFF375973),Offset(w*.37f,h*.62f),Size(w*.31f,h*.15f))
    drawRect(Color(0xFF426C78),Offset(w*.43f,h*.24f),Size(w*.18f,h*.39f))
    for(i in 0..7){
        val yy=h*(.25f+i*.047f); val half=w*(.1f-i*.002f)
        val path=Path().apply { moveTo(w*.52f-half,yy);lineTo(w*.52f+half,yy);lineTo(w*.52f+half*.76f,yy+h*.038f);lineTo(w*.52f-half*.76f,yy+h*.038f);close() }
        drawPath(path,front)
        drawLine(White.copy(alpha=.39f),Offset(w*.52f-half,yy),Offset(w*.52f+half,yy),1.dp.toPx())
    }
    drawLine(side,Offset(w*.52f,h*.11f),Offset(w*.52f,h*.24f),5.dp.toPx())
    for(row in 0..7) for(col in 0..2){
        drawRect(if(night) Color(0xFFFFE5A4) else Color(0xFFC3EBEC),
            Offset(w*(.45f+col*.042f),h*(.27f+row*.048f)),Size(w*.018f,h*.011f))
    }
    drawRect(Color(0xFF2A5B72),Offset(w*.41f,h*.65f),Size(w*.23f,h*.11f))
}
private fun DrawScope.drawSkytree(w:Float,h:Float) {
    val c=Color(0xFFE9EEF8);val center=w*.52f
    drawRect(Color(0xFF577D97),Offset(w*.35f,h*.69f),Size(w*.35f,h*.08f))
    drawLine(c,Offset(center-w*.065f,h*.7f),Offset(center-w*.025f,h*.21f),4.dp.toPx())
    drawLine(c,Offset(center+w*.065f,h*.7f),Offset(center+w*.025f,h*.21f),4.dp.toPx())
    drawLine(c,Offset(center,h*.09f),Offset(center,h*.69f),3.dp.toPx())
    for(i in 0..11){ val y=h*(.26f+i*.036f); val x=w*(.025f+.034f*i/12f)
        drawLine(Color(0xFF91BAD7),Offset(center-x,y),Offset(center+x,y),2.dp.toPx()) }
    drawRoundRect(Color(0xFFBDDDE9),Offset(center-w*.11f,h*.28f),Size(w*.22f,h*.065f),androidx.compose.ui.geometry.CornerRadius(12.dp.toPx()))
    drawLine(Color(0xFFB8CFDC),Offset(center,h*.1f),Offset(center,h*.23f),3.dp.toPx())
}
private fun DrawScope.drawEiffel(w:Float,h:Float) {
    val metal=Color(0xFFC18E6A); val center=w*.5f
    drawLine(metal,Offset(center-w*.18f,h*.74f),Offset(center-w*.025f,h*.18f),9.dp.toPx())
    drawLine(metal,Offset(center+w*.18f,h*.74f),Offset(center+w*.025f,h*.18f),9.dp.toPx())
    drawLine(Color(0xFFE8BD96),Offset(center-w*.15f,h*.72f),Offset(center+w*.15f,h*.72f),4.dp.toPx())
    for(i in 0..6){val y=h*(.27f+i*.06f); val width=w*(.036f+i*.018f)
        drawLine(metal,Offset(center-width,y),Offset(center+width,y),3.dp.toPx())
        if(i<6){drawLine(Color(0xFFF3D2AC),Offset(center-width,y),Offset(center+width+w*.01f,y+h*.06f),1.dp.toPx())}}
    drawRect(metal,Offset(center-w*.12f,h*.57f),Size(w*.24f,h*.022f))
    drawLine(metal,Offset(center,h*.11f),Offset(center,h*.21f),4.dp.toPx())
}
private fun DrawScope.drawCottage(w:Float,h:Float,night:Boolean,snow:Float) {
    val x=w*.32f; val y=h*.43f; val rw=w*.36f;val rh=h*.28f
    drawRect(Color(0xFFFFD7AD),Offset(x,y),Size(rw,rh))
    val roof=Path().apply {moveTo(x-w*.07f,y);lineTo(x+rw*.49f,y-h*.17f);lineTo(x+rw+w*.07f,y);close()}
    drawPath(roof,if(snow>.1f) Color(0xFFF3FAFD) else Color(0xFFBD6F67))
    drawRect(Color(0xFF7A9DAB),Offset(x+rw*.37f,y+rh*.49f),Size(rw*.25f,rh*.51f))
    for(i in 0..1){
        drawRoundRect(if(night) Color(0xFFFFECAD) else Color(0xFF98D5E7),Offset(x+rw*(.1f+.64f*i),y+rh*.26f),Size(rw*.15f,rh*.22f),androidx.compose.ui.geometry.CornerRadius(3.dp.toPx()))
    }
    drawRect(Color(0xFF9E8071),Offset(x+rw*.69f,y-h*.14f),Size(rw*.09f,h*.14f))
    drawCircle(Color(0xFF689E89),h*.074f,Offset(x-w*.05f,y+rh*.75f))
    drawCircle(Color(0xFF77AB93),h*.07f,Offset(x+rw+w*.02f,y+rh*.69f))
}
private fun WeatherCondition.label() = when(this){
    WeatherCondition.CLEAR -> "晴朗";WeatherCondition.PARTLY_CLOUDY -> "晴時多雲"
    WeatherCondition.CLOUDY -> "多雲";WeatherCondition.FOG -> "有霧"
    WeatherCondition.RAIN -> "正在下雨";WeatherCondition.SNOW -> "正在下雪"
    WeatherCondition.THUNDERSTORM -> "雷雨";WeatherCondition.UNKNOWN -> "天氣資訊更新中"
}
private fun LandmarkId.label()=when(this){
    LandmarkId.TAIPEI_101 -> "臺北 101 · 微縮城市"
    LandmarkId.TOKYO_SKYTREE -> "東京晴空塔 · 微縮城市"
    LandmarkId.EIFFEL_TOWER -> "艾菲爾鐵塔 · 微縮城市"
    LandmarkId.WEATHER_COTTAGE -> "微縮氣象小屋"
}
