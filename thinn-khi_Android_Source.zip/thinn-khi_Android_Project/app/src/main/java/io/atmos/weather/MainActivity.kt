package io.atmos.weather

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.content.Intent
import io.atmos.weather.domain.visual.WeatherScene
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import io.atmos.weather.domain.model.GeoPoint
import io.atmos.weather.domain.model.WeatherCity
import io.atmos.weather.presentation.home.*
import io.atmos.weather.widgets.WidgetSync

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.rgb(15, 26, 45)
        WidgetSync.schedule(this)
        setContent {
            val vm: WeatherViewModel = viewModel(factory=WeatherViewModel.Factory(AppContainer.repository(applicationContext), applicationContext))
            val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
                if (results.values.any { it }) currentLocation(vm)
            }
            WeatherHomeScreen(viewModel=vm, onOpen3D={ scene ->
                startActivity(Intent(this, LandmarkViewerActivity::class.java).apply {
                    putExtra("landmark",scene?.landmark?.name ?: "WEATHER_COTTAGE")
                    putExtra("night",(scene?.nightLight ?: 0f)>0f)
                    putExtra("rain",(scene?.wetness ?: 0f)>0f)
                    putExtra("snow",(scene?.snowAccumulation ?: 0f)>0f)
                })
            }, onLocate={
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) currentLocation(vm)
                else launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION))
            })
        }
    }
    @SuppressLint("MissingPermission")
    private fun currentLocation(vm: WeatherViewModel) {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val provider = when {
            manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        } ?: return
        try {
            manager.getCurrentLocation(provider, null, mainExecutor) { location ->
                location?.let {
                    vm.onIntent(WeatherIntent.SelectCity(WeatherCity("gps", "我的位置", GeoPoint(it.latitude, it.longitude))))
                }
            }
        } catch (_: SecurityException) { /* permission revoked between request and callback */ }
    }
}
