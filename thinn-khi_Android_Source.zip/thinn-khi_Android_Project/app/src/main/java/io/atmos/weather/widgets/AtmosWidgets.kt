package io.atmos.weather.widgets

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.background
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import io.atmos.weather.MainActivity
import io.atmos.weather.R
import io.atmos.weather.domain.model.WeatherCondition

/** 5 series x 5 palettes/layout variants = 25 distinct launcher entries. */
open class AtmosWidget(private val variant: Int) : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val prefs = context.getSharedPreferences("weather_cache", Context.MODE_PRIVATE)
        val city = prefs.getString("widget_city", "臺北") ?: "臺北"
        val time = prefs.getLong("widget_time", 0L)
        val temp = if (time == 0L) "--°" else "${prefs.getInt("widget_temp", 0)}°"
        val rain = prefs.getInt("widget_rain", -1).let { if (it < 0) "--" else "$it%" }
        val condition = runCatching { WeatherCondition.valueOf(prefs.getString("widget_condition", "CLEAR")!!) }.getOrDefault(WeatherCondition.UNKNOWN)
        provideContent { WidgetContent(variant, city, temp, rain, condition, time > 0L) }
    }
}

@Composable
private fun WidgetContent(variant: Int, city: String, temp: String, rain: String, condition: WeatherCondition, loaded: Boolean) {
    val family = variant / 5
    val scheme = variant % 5
    val size = LocalSize.current
    val wide = size.width > 230.dp
    val bg = when (family) {
        0 -> listOf(0xFF244767, 0xFF35576B, 0xFF25334E, 0xFF395D5A, 0xFF634F75)[scheme]
        1 -> listOf(0xFF547EAC, 0xFF607D99, 0xFF6489A1, 0xFF42668B, 0xFF776F98)[scheme]
        2 -> listOf(0xFF192B44, 0xFF26324B, 0xFF1D3C48, 0xFF2A3155, 0xFF36465D)[scheme]
        3 -> 0x00000000
        else -> listOf(0xFF1A304B, 0xFF31425D, 0xFF2F444F, 0xFF403B54, 0xFF50445A)[scheme]
    }
    val foreground = if (family == 3) Color(0xFF21364B) else Color.White
    val muted = if (family == 3) Color(0xFF51677E) else Color(0xFFDBECF7)
    Box(GlanceModifier.fillMaxSize().background(Color(bg.toInt()))
        .clickable(actionStartActivity<MainActivity>()).padding(12.dp)) {
        when (family) {
            0 -> Row(GlanceModifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                Image(ImageProvider(R.drawable.widget_landmark), "微縮氣象地標", modifier=GlanceModifier.width(if(wide) 104.dp else 62.dp).height(if(wide) 104.dp else 78.dp))
                Spacer(GlanceModifier.width(6.dp))
                Column {
                    WText(city, muted, 12)
                    WText(temp, foreground, if(wide) 38 else 26, true)
                    WText(condition.label(), muted, 12)
                }
            }
            1 -> Column {
                WText("thinn-khì  ·  $city", muted, 11)
                Spacer(GlanceModifier.height(6.dp))
                Row(verticalAlignment=Alignment.CenterVertically) {
                    WText(temp, foreground, if(wide) 40 else 29, true)
                    Spacer(GlanceModifier.width(10.dp))
                    Column { WText(condition.label(), foreground, 13); WText("降雨機率 $rain", muted, 11) }
                }
                if (size.height > 100.dp) { Spacer(GlanceModifier.height(5.dp)); WText("▁ ▂ ▄ ▆ ▅ ▃ ▂ ▄  ·  溫度趨勢", muted, 10) }
            }
            2 -> Column {
                WText("▤  thinn-khì / 儀表", muted, 11)
                Spacer(GlanceModifier.height(5.dp))
                Row {
                    Column { WText(temp, foreground, if(wide) 34 else 27, true); WText(city, muted, 12) }
                    if (wide) { Spacer(GlanceModifier.width(17.dp)); Column { WText("☔ $rain", foreground, 15); WText(condition.label(), muted, 12) } }
                }
            }
            3 -> Column {
                WText(city, foreground, 13, true)
                WText(temp, foreground, if(wide) 43 else 33, true)
                WText("${condition.label()}   ·   降雨 $rain", muted, 12)
            }
            else -> Row(GlanceModifier.fillMaxSize(), verticalAlignment=Alignment.CenterVertically) {
                Column { WText("thinn-khì / CLOCK", muted, 11); WText("${java.time.LocalTime.now().hour.toString().padStart(2,'0')}:${java.time.LocalTime.now().minute.toString().padStart(2,'0')}", foreground, if(wide) 30 else 24,true); WText("$city  $temp", muted, 12) }
                if (wide) { Spacer(GlanceModifier.width(10.dp)); WText("☀", foreground, 30) }
            }
        }
        if (!loaded) WText("開啟 App 以同步天氣", muted, 10)
    }
}

@Composable
private fun WText(content: String, color: Color, size: Int, bold: Boolean = false) {
    Text(content, maxLines=1, style=TextStyle(color=ColorProvider(color), fontSize=size.sp,
        fontWeight=if(bold) FontWeight.Bold else FontWeight.Normal))
}
private fun WeatherCondition.label(): String = when(this) {
    WeatherCondition.CLEAR -> "晴朗"; WeatherCondition.PARTLY_CLOUDY -> "局部多雲"
    WeatherCondition.CLOUDY -> "多雲"; WeatherCondition.FOG -> "有霧"
    WeatherCondition.RAIN -> "降雨"; WeatherCondition.SNOW -> "降雪"
    WeatherCondition.THUNDERSTORM -> "雷雨"; else -> "天氣資料更新中"
}
