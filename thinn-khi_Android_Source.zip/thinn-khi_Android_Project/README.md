# thinn-khì — Android App + 25 Widgets + Native 3D Viewer

**App display name: `thinn-khì`**. The internal `applicationId` remains `io.atmos.weather` to retain update compatibility.

**State: feature-rich source delivery, NOT a prebuilt or device-verified APK.**
This folder provides an Android Studio project and a GitHub Actions workflow that compiles a debug-installable APK. Compiling it requires the Android SDK and online Gradle dependencies. The authoring environment had none of these, so **no APK compilation or emulator validation has occurred**; the workflow has not been run yet.

## What's included

- Android 12+ (`minSdk=31`), Kotlin 2.1.20 + Jetpack Compose.
- Open-Meteo live weather: current temperature, feels-like, humidity, wind, pressure, UV, rain chance, sun times, daily high/low, 24h hourly forecast. Forecast data may be missing if the provider does not supply it. Correct status is displayed for missing fields.
- Location permission on demand, 9 city presets, worldwide city lookup through Open-Meteo geocoding.
- Custom glass-like cards, sunset/day/rain/night color mood, animated rain/snow, springy gesture-tilt miniature landmark scene, hourly temperature chart and haptic-enabled city/metric controls.
- True 3D OpenGL ES 2.0 viewer reachable from the landmark card, with touch orbit, model lighting colors and weather-driven day/night/snow color. Custom lightweight meshes were baked from the included `.glb` scene assets. These are artistically inspired procedural models, not detailed scans. **The app does not use Filament/SceneView yet**.
- Four original `.glb` assets: Taipei 101, Tokyo Skytree, Eiffel Tower and cottage, plus the matching tiny `.mesh` runtime assets.
- Five widget families × five variations = 25 distinct launcher widget entries. Widget data uses a shared preferences snapshot, background updates use WorkManager hourly plus refresh-triggered update. System launchers have OEM differences and may delay refreshes. Widgets show STATIC landmark artwork rather than continuous 3D animation. Flip-clock-inspired widgets show time AT WIDGET UPDATE, not a minute-accurate ticking clock.
- Persisted offline cache (SharedPreferences JSON); 15-minute repository freshness policy with stale data fallback. This is not a Room database.
- HTTPS API connections only; no location tracking analytics or account login.

## Compile an APK (Android Studio)

1. Open this folder in Android Studio, with JDK 17 and Android SDK Platform 35 installed.
2. Let Gradle synchronize, using network access for dependency downloads.
3. `Build > Build APK(s)` or run `gradle :app:assembleDebug` with Gradle **8.11.1**.
4. APK output: `app/build/outputs/apk/debug/app-debug.apk` **after a successful build**.
5. Test on a physical device running Android 12 or newer. Location permission is optional; all cities can be selected manually.

## Automatic APK build through GitHub Actions

This project includes `.github/workflows/android-apk.yml`. Create a GitHub repository, upload the **contents** of this project at repository root (not the ZIP nested inside another folder), and choose Actions → `Build installable Android APK` → Run workflow. After the workflow succeeds, the `thinn-khi-debug-APK` artifact contains `app-debug.apk`. This is a debug-signed APK (the Android SDK debug signing key), not a Google Play production-signed APK. Do not distribute commercially before licensing/auditing.

## Repository layout

- `app/src/main/java/io/atmos/weather/domain` — provider-independent weather/scene value objects
- `data/remote` — Open-Meteo, geocoding DTOs, API adapter
- `data/repository` — cache, fallback and stale policy
- `presentation/home` — glass UI, 2.5D landmark, hourly and metric cards, MVI/MVVM state
- `LandmarkViewerActivity.kt` — native GLES20 shader-based 3D viewer
- `widgets/` — 25 receiver classes, family renderer and WorkManager refresh
- `app/src/main/assets/landmarks` — GLB + native geometry vertex streams

## Remaining validation and production limitations

This is not a fully production-tested release. OEM device QA, tests of widget host refresh, power/battery profiling, accessibility audits, precise reverse-geocoded locations, advanced 3D physical shaders and actual background gaussian blur of Android content have not been completed. Glass panels here use layered translucent gradients, not physically exact backdrop filtering. The mini scene's wetness/snow effects are stylized; they are not complex GPU fluid simulation. Desktop widgets use periodic system-sanctioned refreshes; they cannot render ongoing 60fps models due to Android RemoteViews restrictions.

Open-Meteo's free tier is **non-commercial**. To monetize or redistribute commercially, review https://open-meteo.com/en/terms and obtain suitable licensing/endpoint credentials, plus validate local weather alerts with official sources. API attribution is in the UI. Do not mistake forecast rain probability for measured rainfall.

## Privacy

Precise location stays on-device except when coordinates are sent to the forecast provider for the requested weather; the app does not request background location. The last selected location coordinates can remain in the device's local settings to restore the view. Users can clear app data to remove them. See `AppContainer` for network providers.
