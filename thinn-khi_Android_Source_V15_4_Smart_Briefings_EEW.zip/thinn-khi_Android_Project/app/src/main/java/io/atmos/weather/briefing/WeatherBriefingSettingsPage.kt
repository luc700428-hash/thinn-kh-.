package io.atmos.weather.briefing

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AccessTime
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.atmos.weather.domain.model.WeatherBriefingPlan
import io.atmos.weather.domain.model.WeatherBriefingSlot
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val ink=Color.White
private val muted=Color(0xFFB8D6E8)
private val azure=Color(0xFF9ADFFF)
private val weekNames=listOf("一","二","三","四","五","六","日")
private fun dayNames(mask:Int):String = if(mask==127)"每天" else weekNames.indices.filter{mask and (1 shl it)!=0}.joinToString("、"){"週${weekNames[it]}"}

/** Native Material 3 sheets, keeping thinn-khi blue glass color system. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WeatherBriefingSettingsPage(onClose:()->Unit) {
    val context=LocalContext.current
    var slots by remember { mutableStateOf(WeatherBriefingStore.load(context)) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<WeatherBriefingSlot?>(null) }
    fun change(next:List<WeatherBriefingSlot>) { WeatherBriefingStore.save(context,next);slots=next }
    ModalBottomSheet(onDismissRequest=onClose,containerColor=Color(0xFF102D49),contentColor=ink) {
        Column(Modifier.fillMaxWidth().heightIn(max=750.dp).verticalScroll(rememberScrollState())
            .padding(horizontal=22.dp).padding(bottom=36.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Icon(Icons.Rounded.NotificationsActive,null,tint=azure,modifier=Modifier.size(28.dp))
                Spacer(Modifier.width(10.dp))
                Text("智慧天氣定時通知",fontWeight=FontWeight.Bold,fontSize=23.sp,color=ink)
            }
            Text("最多設定 5 組星期與時分。每次只分析從這次提醒到下一次提醒間的天氣，提供降雨、穿搭、溫差及外出建議。",
                fontSize=12.sp,color=muted)
            Text("採用手機目前時區 · 背景通知可能因 Android 省電策略延遲，不能保證精確分鐘。",
                fontSize=11.sp,color=Color(0xFFF1D49B))
            slots.sortedWith(compareBy({it.hour},{it.minute},{it.id})).forEach { slot ->
                Column(Modifier.fillMaxWidth().background(Color.White.copy(alpha=.09f),RoundedCornerShape(20.dp))
                    .border(1.dp,Color.White.copy(alpha=.13f),RoundedCornerShape(20.dp)).padding(14.dp)) {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Rounded.AccessTime,null,tint=azure)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text("%02d:%02d".format(Locale.US,slot.hour,slot.minute),fontSize=25.sp,color=ink,fontWeight=FontWeight.Bold)
                            Text(dayNames(slot.weekdays),fontSize=12.sp,color=muted)
                        }
                        Switch(checked=slot.enabled,onCheckedChange={on ->change(slots.map{if(it.id==slot.id)it.copy(enabled=on) else it})})
                    }
                    if(slot.enabled) {
                        val next=WeatherBriefingPlan.upcoming(listOf(slot),Instant.now(),ZoneId.systemDefault())
                        Text("下次預計：${next?.time?.format(DateTimeFormatter.ofPattern("MM/dd 週E HH:mm",Locale.TAIWAN)) ?: "未排程"}",
                            fontSize=11.sp,color=azure)
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick={editing=slot;showAdd=true}) {Text("編輯時間",color=ink,fontSize=12.sp)}
                        OutlinedButton(onClick={change(slots.filterNot{it.id==slot.id})}) {Text("刪除",color=ink,fontSize=12.sp)}
                    }
                }
            }
            Button(onClick={editing=null;showAdd=true},modifier=Modifier.fillMaxWidth(),enabled=slots.size<WeatherBriefingPlan.MAX_SLOTS) {
                Text(if(slots.size<5)"＋ 新增定時通知（${slots.size}/5）" else "已達 5 組通知上限")
            }
            Text("通知會使用你選擇的 8 款 thinn-khì 專屬音效，並嘗試相容裝置的焦點通知；無法保證顯示在超級島。",
                color=muted,fontSize=11.sp)
            Text("資料來源為 Open-Meteo 預報。若下一次提醒超出目前預報範圍，會明確標示資料尚未涵蓋，不會虛構。",
                color=muted,fontSize=11.sp)
        }
    }
    if(showAdd) {
        var hour by remember(editing) { mutableStateOf(editing?.hour?.toString()?.padStart(2,'0') ?: "08") }
        var minute by remember(editing) { mutableStateOf(editing?.minute?.toString()?.padStart(2,'0') ?: "00") }
        var days by remember(editing) { mutableIntStateOf(editing?.weekdays ?: 127) }
        var error by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest={showAdd=false},containerColor=Color(0xFF173653),
            title={Text(if(editing==null) "新增天氣提醒" else "編輯天氣提醒",color=ink)},
            text={ Column(verticalArrangement=Arrangement.spacedBy(9.dp)) {
                Text("設定當地時間（24 小時制）",color=muted,fontSize=12.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value=hour,onValueChange={if(it.length<=2)hour=it.filter(Char::isDigit)},
                        label={Text("時",color=muted)},modifier=Modifier.weight(1f),singleLine=true,
                        keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                    OutlinedTextField(value=minute,onValueChange={if(it.length<=2)minute=it.filter(Char::isDigit)},
                        label={Text("分",color=muted)},modifier=Modifier.weight(1f),singleLine=true,
                        keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number))
                }
                Text("選擇星期（至少一天）",color=muted,fontSize=12.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(2.dp),modifier=Modifier.fillMaxWidth()) {
                    weekNames.forEachIndexed{index,name ->
                        val on=days and (1 shl index)!=0
                        FilterChip(selected=on,onClick={days=days xor (1 shl index)},
                            label={Text(name,fontSize=11.sp)},modifier=Modifier.weight(1f).height(42.dp))
                    }
                }
                if(error.isNotBlank())Text(error,color=Color(0xFFFFB0A2),fontSize=12.sp)
            } },
            confirmButton={TextButton(onClick={
                val h=hour.toIntOrNull();val m=minute.toIntOrNull()
                error=when {
                    h==null || h !in 0..23 || m==null || m !in 0..59 -> "時間必須為 00:00～23:59"
                    days==0 -> "請至少選一個星期"
                    slots.any{it.id!=editing?.id && it.hour==h && it.minute==m && it.weekdays and days !=0} -> "相同時間的星期不可重複，請調整設定"
                    else -> ""
                }
                if(error.isEmpty() && h!=null && m!=null) {
                    if(editing!=null) {
                        change(slots.map{if(it.id==editing?.id)it.copy(hour=h,minute=m,weekdays=days) else it})
                    } else {
                        val id=(1..5).first{used->slots.none{it.id==used}}
                        change(slots+WeatherBriefingSlot(id,h,m,days))
                    }
                    showAdd=false
                }
            }){Text("儲存",color=azure)}},
            dismissButton={TextButton(onClick={showAdd=false}){Text("取消",color=muted)}})
    }
}
