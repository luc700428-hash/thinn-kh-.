package io.atmos.weather.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

private val glassBorder=Brush.linearGradient(listOf(Color.White.copy(alpha=.60f),Color.White.copy(alpha=.08f),Color(0xFF7AE2FE).copy(alpha=.35f)))

/** Native full-width bottom sheet with user-controlled drag handle. */
@Composable
fun GlassModalBottomSheet(onDismissRequest:()->Unit,containerColor:Color=Color(0xFF12344F),
    contentColor:Color=Color.White,content:@Composable ColumnScope.()->Unit) {
    Dialog(onDismissRequest=onDismissRequest,properties=DialogProperties(usePlatformDefaultWidth=false)) {
        Box(Modifier.fillMaxSize(),contentAlignment=Alignment.BottomCenter) {
            Column(Modifier.fillMaxWidth().heightIn(max=780.dp)
                .clip(RoundedCornerShape(topStart=36.dp,topEnd=36.dp))
                .background(Brush.verticalGradient(listOf(Color(0xED4A7997),containerColor,Color(0xFF091C30))))
                .border(1.dp,glassBorder,RoundedCornerShape(topStart=36.dp,topEnd=36.dp))
                .navigationBarsPadding()) {
                var dragged by remember { mutableFloatStateOf(0f) }
                val y by animateFloatAsState(dragged,label="滑動面板")
                Box(Modifier.fillMaxWidth().height(29.dp).offset(y=with(androidx.compose.ui.platform.LocalDensity.current){ y.toDp() })
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(onVerticalDrag={change,amount->
                            dragged=(dragged+amount).coerceIn(0f,250f);change.consume()
                        },onDragEnd={if(dragged>75f) onDismissRequest() else dragged=0f})
                    },contentAlignment=Alignment.Center) {
                    Box(Modifier.size(width=42.dp,height=5.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha=.64f)))
                }
                content()
            }
        }
    }
}

@Composable
fun GlassAlertDialog(onDismissRequest:()->Unit,confirmButton:@Composable ()->Unit,
    title:@Composable (()->Unit)?=null,text:@Composable (()->Unit)?=null) {
    Dialog(onDismissRequest=onDismissRequest) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(29.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF3A6582),Color(0xFF102C49))))
            .border(1.dp,glassBorder,RoundedCornerShape(29.dp)).padding(22.dp),
            verticalArrangement=Arrangement.spacedBy(14.dp)) {
            title?.invoke();text?.invoke()
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.End) {confirmButton()}
        }
    }
}

@Composable
fun GlassOutlinedTextField(value:String,onValueChange:(String)->Unit,
    modifier:Modifier=Modifier,singleLine:Boolean=true,
    keyboardOptions:KeyboardOptions=KeyboardOptions.Default,
    keyboardActions:KeyboardActions=KeyboardActions.Default,
    leadingIcon:(@Composable ()->Unit)?=null,
    label:(@Composable ()->Unit)?=null,
    colors:TextFieldColors?=null) {
    Row(modifier.defaultMinSize(minHeight=56.dp)
        .clip(RoundedCornerShape(18.dp))
        .background(Color.White.copy(alpha=.12f))
        .border(1.dp,glassBorder,RoundedCornerShape(18.dp))
        .padding(horizontal=14.dp,vertical=9.dp),verticalAlignment=Alignment.CenterVertically) {
        if(leadingIcon!=null) {leadingIcon();Spacer(Modifier.width(8.dp))}
        Box(Modifier.weight(1f)) {
            if(value.isBlank()) Box {label?.invoke()}
            BasicTextField(value,onValueChange,modifier=Modifier.fillMaxWidth(),singleLine=singleLine,
                textStyle=TextStyle(color=Color.White,fontSize=15.sp),
                keyboardOptions=keyboardOptions,keyboardActions=keyboardActions,
                cursorBrush=SolidColor(Color(0xFF87E4FA)))
        }
    }
}

@Composable
fun GlassDivider(modifier:Modifier=Modifier,color:Color=Color.White.copy(alpha=.19f)) {
    Box(modifier.fillMaxWidth().height(1.dp).background(color))
}

@Composable
fun GlassDropdownMenu(expanded:Boolean,onDismissRequest:()->Unit,
    content:@Composable ColumnScope.()->Unit) {
    if(expanded) androidx.compose.ui.window.Popup(
        alignment=Alignment.TopStart,
        onDismissRequest=onDismissRequest,
        properties=androidx.compose.ui.window.PopupProperties(focusable=true)
    ) {
        Column(Modifier.widthIn(min=230.dp,max=310.dp).heightIn(max=340.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF376783),Color(0xFF142F49))))
            .border(1.dp,glassBorder,RoundedCornerShape(22.dp))
            .verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(7.dp),content=content)
    }
}

@Composable
fun GlassDropdownMenuItem(text:@Composable ()->Unit,onClick:()->Unit) {
    Box(Modifier.fillMaxWidth().defaultMinSize(minHeight=48.dp)
        .clip(RoundedCornerShape(14.dp)).clickable(onClick=onClick)
        .padding(horizontal=12.dp,vertical=11.dp),contentAlignment=Alignment.CenterStart) {text()}
}

@Composable
fun GlassSurfaceBox(modifier:Modifier=Modifier,
    shape:androidx.compose.ui.graphics.Shape=RoundedCornerShape(18.dp),
    color:Color=Color.White.copy(alpha=.14f),
    border:androidx.compose.foundation.BorderStroke?=null,
    content:@Composable ()->Unit) {
    Box(modifier.clip(shape).background(color).border(border ?: androidx.compose.foundation.BorderStroke(1.dp,glassBorder),shape),
        contentAlignment=Alignment.Center) {content()}
}

@Composable
fun GlassAppTheme(content:@Composable ()->Unit) { content() }
