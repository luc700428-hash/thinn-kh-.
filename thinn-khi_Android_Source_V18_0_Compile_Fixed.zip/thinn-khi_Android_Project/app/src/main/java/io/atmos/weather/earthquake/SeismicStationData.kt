package io.atmos.weather.earthquake

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Metadata and live magnitudes are untrusted, independent third-party telemetry.
 * Never convert a single station's reading into a nationwide EEW alarm.
 */
data class SeismicStation(
    val id: String,
    val label: String,
    val latitude: Double?,
    val longitude: Double?,
    val intensity: Double?,
    val accelerationGal: Double?
)

object SeismicStationData {
    /** Provider can return a root map, nested keyed map, or array. Unknown frames stay empty. */
    fun parse(raw: String, metadata: Map<String, SeismicStation> = emptyMap()): List<SeismicStation> {
        val root = runCatching { if (raw.trimStart().startsWith("[")) JSONArray(raw) else JSONObject(raw) }.getOrNull()
            ?: return emptyList()
        val seen = LinkedHashMap<String, SeismicStation>()
        fun number(o: JSONObject, vararg names: String): Double? = names.firstNotNullOfOrNull { key ->
            o.opt(key)?.toString()?.toDoubleOrNull()?.takeIf { it.isFinite() }
        }
        fun walk(node: Any?, key: String?, depth: Int) {
            if (depth > 4 || seen.size >= 2500) return
            when (node) {
                is JSONArray -> for (i in 0 until minOf(node.length(), 2500)) walk(node.opt(i), null, depth + 1)
                is JSONObject -> {
                    val id = listOf("id", "stationId", "station_id", "code").firstNotNullOfOrNull { n ->
                        node.optString(n).takeIf { it.isNotBlank() }
                    } ?: key
                    val info = node.optJSONObject("info") ?: node.optJSONObject("position") ?: node.optJSONObject("location") ?: node
                    val lat = number(info, "lat", "latitude") ?: number(node,"lat","latitude")
                    val lon = number(info, "lon", "lng", "longitude") ?: number(node,"lon","lng","longitude")
                    val known = id?.let { metadata[it] }
                    val locLat = lat ?: known?.latitude
                    val locLon = lon ?: known?.longitude
                    // Read only explicitly supplied values; no synthetic or guessed station intensities.
                    val level = number(node, "i", "int", "intensity", "level")?.takeIf { it in 0.0..9.0 }
                    val pga = number(node, "pga", "gal", "acc", "acceleration")?.takeIf { it in 0.0..10000.0 }
                    if (id != null && id.length <= 100 && (locLat != null || known != null || level != null || pga != null)) {
                        val name = node.optString("name").ifBlank { node.optString("loc") }.ifBlank { known?.label ?: id }
                        val point = SeismicStation(id, name.take(70),
                            locLat?.takeIf { it in 21.0..26.5 }, locLon?.takeIf { it in 118.0..123.5 }, level, pga)
                        if (point.latitude != null && point.longitude != null) seen[id] = point
                    }
                    if (id == null || (!node.has("i") && !node.has("pga") && !node.has("lat") && !node.has("intensity"))) {
                        // Container objects and API envelopes; traverse only expected shapes.
                        for (next in listOf("data", "station", "stations", "list", "items", "rts", "result", "network")) {
                            if (node.has(next)) walk(node.opt(next),null,depth+1)
                        }
                        // Keyed station dictionary: { "123": { ... }, ... }
                        if (depth <= 3) for (name in node.keys()) {
                            if (name in setOf("data", "station", "stations", "list", "items", "rts", "result", "network", "time", "timestamp")) continue
                            val child = node.opt(name)
                            if (child is JSONObject && (child.has("lat") || child.has("pga") || child.has("i") || metadata.containsKey(name)))
                                walk(child,name,depth+1)
                        }
                    }
                }
            }
        }
        walk(root,null,0)
        return seen.values.toList()
    }

    /** Best-effort public station metadata; failure does not create fake map pins. */
    fun fetchMetadata(): Map<String, SeismicStation> {
        val conn = (URL("https://api-1.exptech.dev/api/v1/trem/station").openConnection() as HttpURLConnection).apply {
            connectTimeout = 7000; readTimeout = 10000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "thinn-khi/15.2 (station map)")
        }
        val text = try {
            if (conn.responseCode !in 200..299) return emptyMap()
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally { conn.disconnect() }
        return parse(text).associateBy { it.id }
    }
}
