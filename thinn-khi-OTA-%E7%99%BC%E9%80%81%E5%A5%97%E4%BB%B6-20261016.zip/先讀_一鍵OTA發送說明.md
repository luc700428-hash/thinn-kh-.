# thinn-khì｜可執行的 OTA 建置／發送包

這是**帶完整 Kotlin Android 原始碼、可在 Termux 進行 GitHub 編譯和正式 OTA 發布的發送包**，不是已簽署 APK。本包內**沒有** `thinn-khi.apk`。因為這個環境沒有 Android SDK、你的原始 Release 簽章金鑰，也無法替你在 GitHub 寫入，所以不能把它稱為可直接安裝的 OTA APK。

## Termux 發送指令

先確定 Termux 已執行 `termux-setup-storage`、GitHub CLI 已用你的帳號 `gh auth login` 登入：

```bash
pkg install gh git unzip coreutils -y
cd ~/storage/downloads
unzip -o thinn-khi-OTA-發送套件-20261016.zip -d thinn-ota
bash thinn-ota/發送OTA.sh
```

腳本：① 完整性校驗 → ② clone 目前 main → ③ 提交 `android-project/` 和新 workflow → ④ 觸發非發布的 Android 編譯與測試 → ⑤ **等你輸入「發送」才開始正式發版** → ⑥ Android 正式簽章、與最新正式 APK 簽章比對、雜湊／OTA manifest → ⑦ GitHub Release 附帶 `thinn-khi.apk`、`thinn-khi.apk.sha256`、`ota.json`。

所有項目有任何一步失敗就停止，不會發布舊 APK 冒充新功能。

### 發布前必備

- GitHub Repo：`luc700428-hash/thinn-kh-.` 的推送和 Actions 執行權限。
- GitHub Actions Secrets：`APK_KEYSTORE_BASE64`、`APK_KEYSTORE_PASSWORD`、`APK_KEY_PASSWORD`、`APK_KEY_ALIAS`，且必須對應**目前正式 APK 的同一組**簽章。
- 你的手機與朋友更新：目前安裝的 `io.atmos.weather` 必須是相同簽章的 APK；如果不同簽章，Android 不接受原地覆蓋。
- 不需把金鑰放在 ZIP；也不要貼金鑰給聊天。

### 必須誠實區分

- **完成**：候選 Kotlin 原始碼打包；GitHub 發版流程；公開 OTA manifest；簽章與安全檢查；本地 Python 與 Node 政策測試。
- **未驗收**：完整 Gradle/Compose 實際編譯；手機升級／動畫／通知／定位等全流程。
- **未完成**：所有臺灣 132 處地標的高精度 GLB 即時 3D 以及部分外部資料服務。

本工具不是「全部需求已完成」證明；只有 GitHub build success + 正式 release 資產 + 手機更新成功才算該版 OTA 發送成功。
