package io.atmos.weather.air

import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.*
import java.time.LocalDateTime
import java.time.Duration
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Official MOENV AQX_P_432 station AQI. No conversion from US AQI. */
data class TaiwanAqiReading(val aqi: Int, val station: String, val publishedAt: String, val kmAway: Int)
data class TaiwanAqiResult(val reading: TaiwanAqiReading?, val status: String)

object TaiwanAqiClient {
    private data class CacheEntry(val at: Long, val result: TaiwanAqiResult)
    private val cache = mutableMapOf<String, CacheEntry>()
    fun level(value: Int?): String = when (value) {
        null -> "尚無資料"
        in 0..50 -> "良好"
        in 51..100 -> "普通"
        in 101..150 -> "對敏感族群不健康"
        in 151..200 -> "對所有族群不健康"
        in 201..300 -> "非常不健康"
        else -> "危害"
    }

    /** Minimize network traffic: one HTTP request for all station observations, then select nearest. */
    suspend fun load(apiKey: String, latitude: Double, longitude: Double): TaiwanAqiResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext TaiwanAqiResult(null, "尚未設定環境部 API 金鑰；台灣 AQI 不會以美制數值代替。")
        val cacheKey = "${apiKey.hashCode()}:${(latitude * 100).toInt()}:${(longitude * 100).toInt()}"
        synchronized(cache) {
            val saved = cache[cacheKey]
            if (saved != null && System.currentTimeMillis() - saved.at < 30 * 60_000L) {
                return@withContext saved.result
            }
        }
        try {
            val key = URLEncoder.encode(apiKey, "UTF-8")
            val url = URL("https://data.moenv.gov.tw/api/v2/aqx_p_432?format=json&limit=1000&api_key=$key")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 9_000
            conn.readTimeout = 12_000
            conn.setRequestProperty("Accept", "application/json")
            conn.setRequestProperty("User-Agent", "thinn-khi-Android/10.3")
            val json = try {
                if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
                conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally { conn.disconnect() }
            val rows = JSONObject(json).optJSONArray("records")
                ?: return@withContext TaiwanAqiResult(null, "環境部 API 未回傳測站資料；請檢查金鑰或稍後再試。")
            var best: TaiwanAqiReading? = null
            var smallest = Double.MAX_VALUE
            for (i in 0 until rows.length()) {
                val row = rows.optJSONObject(i) ?: continue
                val aqi = row.optString("aqi").toIntOrNull() ?: continue
                val lat = row.optString("latitude").toDoubleOrNull() ?: continue
                val lon = row.optString("longitude").toDoubleOrNull() ?: continue
                if (aqi < 0 || aqi > 500) continue
                val distance = distanceKm(latitude, longitude, lat, lon)
                if (distance < smallest) {
                    smallest=distance
                    best=TaiwanAqiReading(aqi,row.optString("sitename", "未命名測站"),
                        row.optString("publishtime", "未提供時間"), distance.roundToInt())
                }
            }
            val site = best ?: return@withContext TaiwanAqiResult(null, "環境部暫無有效 AQI 測站資料。")
            if (smallest > 150.0) return@withContext TaiwanAqiResult(null, "附近 150 公里內沒有適用的環境部 AQI 測站。")
            val outOfDate = try {
                val t = LocalDateTime.parse(site.publishedAt,DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm"))
                Duration.between(t.atZone(ZoneId.of("Asia/Taipei")).toInstant(),java.time.Instant.now()).toHours() > 4
            } catch (_: Exception) { false }
            val result = TaiwanAqiResult(site, "環境部 AQI｜${site.station}測站（約 ${site.kmAway} 公里）；${if (outOfDate) "資料可能已過期" else "非所在地精確測值"}。")
            synchronized(cache) { cache[cacheKey] = CacheEntry(System.currentTimeMillis(), result) }
            result
        } catch (e: CancellationException) { throw e }
          catch (_: Exception) { TaiwanAqiResult(null, "環境部 AQI 讀取失敗；請檢查金鑰、網路或稍後重試。") }
    }

    fun distanceKm(lat1: Double,lon1: Double,lat2: Double,lon2: Double): Double {
        val p1=Math.toRadians(lat1)
        val p2=Math.toRadians(lat2)
        val dp=Math.toRadians(lat2-lat1)
        val dl=Math.toRadians(lon2-lon1)
        val a=sin(dp/2).pow(2.0)+cos(p1)*cos(p2)*sin(dl/2).pow(2.0)
        return 6371.0*2.0*atan2(sqrt(a),sqrt((1.0-a).coerceAtLeast(0.0)))
    }
}
