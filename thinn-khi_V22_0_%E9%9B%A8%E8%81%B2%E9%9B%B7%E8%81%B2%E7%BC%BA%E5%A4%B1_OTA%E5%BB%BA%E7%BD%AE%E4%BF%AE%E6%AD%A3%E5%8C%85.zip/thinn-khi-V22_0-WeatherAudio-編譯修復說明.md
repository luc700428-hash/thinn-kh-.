# thinn-khì V22.0 — 本次 Kotlin `R.raw` 音效缺失修復

## 你的 GitHub Actions 新錯誤

這次 `Verify pinned V22 source archive` 已通過。日誌顯示 `:app:compileDebugKotlin FAILED`，原因為 `WeatherAudio.kt` 引用 `R.raw.light_rain`、`R.raw.heavy_rain`、`R.raw.thunder_strike`，但 V22 專案原始碼 `res/raw/` 不包含這三個音檔。其餘 Kotlin 錯誤是這些資源未產生造成的連鎖影響。

## 修正方式（無須再上傳 Android ZIP）

1. 開啟 GitHub：`luc700428-hash/thinn-kh-.` → `.github/workflows/build-apk.yml`。
2. 直接將該檔案**全部內容**替換成本包 `thinn-khi-V22_0-build-apk-Archive-Audio-FIX.yml`，儲存至 `main`。不要上傳這個 ZIP 取代專案的 Android 原始碼。
3. GitHub Actions 將繼續從已在倉庫的 V22 修復整合包擷取原始碼，先檢查兩層 SHA-256，然後執行 `tools/prepare_real_weather_audio.py`，產生三個實際雨聲／雷聲 `.ogg` 檔，經 ffprobe 驗證 Ogg Vorbis 後才執行 Gradle 測試及編譯。
4. 第一次測試 `publish_release=false`，檢查 `Restore public-domain rain and thunder recordings BEFORE Kotlin compile` 步驟，以及 `Compile Android and run unit tests` 的結果。
5. 如果建置成功，確認正式簽章金鑰和手機上的版本碼後，才可設定 `publish_release=true` 釋出 OTA。

**音效來源與授權**：`cori: Rain_against_the_window.ogg`、`ezwa: Rain_(1).ogg`、`Caesar: Rain_and_thunder.ogg`，來源均為 Wikimedia Commons 標示 public domain 的自然錄音，請保留 Android 專案 `docs/WEATHER_AUDIO_SOURCES.md` 的來源記錄。腳本會在 CI 執行時從 Wikimedia 下載，而非在使用者使用 App 時下載。

## 驗證範圍與限制

- 已確認 V22 專案中 `R.raw` 缺少的資源恰好只有這三個；這次修正會在 Gradle 前生成它們。
- GitHub Actions YAML 已通過解析與步驟順序檢查、兩個封存檔 SHA-256 未變動。
- 未在此環境完成 GitHub Runner 的網路下載、完整 Android 編譯或正式 APK 簽章；若 Wikimedia 連線失敗，Action 會明確停止在音效下載階段，不會偽裝為編譯成功。
- 因此此整合包是 **CI／OTA 建置修正包，並非可直接安裝的 APK，也不代表新版 OTA 已發布**。

## 原始碼 ZIP 不用變更的原因

V22 原始碼已包含 `tools/prepare_real_weather_audio.py` 及 `docs/WEATHER_AUDIO_SOURCES.md`，但前一輪的 `build-apk.yml` 遺漏了原本應在 Gradle 之前執行的聲音素材準備階段；只修改 CI 可以避免重新上傳 2.5MB 專案並保持原始碼雙層 SHA-256 固定與可追溯性。
