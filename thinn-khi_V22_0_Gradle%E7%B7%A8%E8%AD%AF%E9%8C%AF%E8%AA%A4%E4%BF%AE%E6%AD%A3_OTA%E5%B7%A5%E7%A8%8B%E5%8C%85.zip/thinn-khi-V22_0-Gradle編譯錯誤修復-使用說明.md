# thinn-khì V22.0 GitHub Actions 編譯錯誤修正

## 原始 CI 失敗

```
app/build.gradle.kts:23:9 Unresolved reference: buildConfigField
Task :app:testDebugUnitTest was not started.
```

原本在 `android { ... }` 直接呼叫 `buildConfigField()`，需要移入 `defaultConfig { ... }`。本次已修改**實際 Android 原始碼**；不是只修工作流程。

## 這次要上傳兩個檔案

1. 把 `thinn-khi_Android_Source_V22_0_GradleDSL_Fixed.zip` 上傳至 GitHub repository `luc700428-hash/thinn-kh-.` 根目錄。
2. 使用 `thinn-khi-V22_0-build-apk-GRADLE-FIXED.yml` **完整替換** repository `.github/workflows/build-apk.yml` 的內容。這次工作流程鎖定原始碼 ZIP 的 SHA-256：`7254ce215fcfbfc20f06ddeda1f4e85613ca7fc819275067b55f1c9b4eb2b76e`。

## 測試與正式發布

先在 Actions → `Build thinn-khì V22.0 Android OTA (Gradle DSL fixed)` 選 `Run workflow`，`publish_release=false`。測試與編譯成功，再確認 APK **與已安裝版本完全相同的簽章憑證**、版本碼遞增、裝置相容後，才能用 `publish_release=true` 正式發布。

必要 GitHub Secrets（沿用原有值；不可貼給任何人）：`APK_KEYSTORE_BASE64`、`APK_KEYSTORE_PASSWORD`、`APK_KEY_PASSWORD`、`APK_KEY_ALIAS`。

此工作流程於 `publish_release=true` 才會用 GitHub Releases 發布；**僅上傳 ZIP 不會自動讓手機收到更新**。如有下一個錯誤，下載當次 Actions 的 `thinn-khi-V22-build-errors` 工件再提供即可。

## 已確認與限制

- 本次修正 GitHub Actions 實際日誌中的 `buildConfigField` Gradle Kotlin DSL 作用域錯誤。
- 後端 7 項 Node 測試已通過；原始碼 ZIP 完整性及工作流程 YAML 已檢查。
- **目前環境沒有安裝 Android SDK + Gradle，故不能確認所有 Android Kotlin 其他編譯錯誤都已消失，也沒有簽章 APK 或已發布 OTA。**
