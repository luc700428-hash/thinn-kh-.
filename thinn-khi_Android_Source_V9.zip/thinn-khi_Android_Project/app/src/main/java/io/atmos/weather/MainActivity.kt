package io.atmos.weather

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import io.atmos.weather.domain.visual.WeatherScene
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import io.atmos.weather.domain.model.GeoPoint
import io.atmos.weather.domain.model.WeatherCity
import io.atmos.weather.presentation.home.*
import io.atmos.weather.widgets.WidgetSync
import io.atmos.weather.location.ReverseGeocoder
import io.atmos.weather.alerts.CwaAlertWorker
import io.atmos.weather.permission.PermissionGuide
import io.atmos.weather.permission.FirstRunGuide
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.rgb(15, 26, 45)
        // Choose the fastest available mode as a preference only. Android may lower it
        // for thermal limits, battery, accessibility or app compatibility.
        @Suppress("DEPRECATION")
        val fastMode = windowManager.defaultDisplay.supportedModes.maxByOrNull { it.refreshRate }
        if (fastMode != null && fastMode.refreshRate > 60f) {
            window.attributes = window.attributes.apply { preferredRefreshRate = fastMode.refreshRate }
        }
        WidgetSync.schedule(this)
        CwaAlertWorker.schedule(this)
        CwaAlertWorker.checkNow(this)
        setContent {
            val vm: WeatherViewModel = viewModel(factory=WeatherViewModel.Factory(AppContainer.repository(applicationContext), applicationContext))
            // Queue runtime requests sequentially. Two simultaneous launchers may cause
            // the second system dialog to be dropped on some OEM Android variants.
            val consent = remember { getSharedPreferences("thinn_settings", MODE_PRIVATE) }
            var introComplete by remember { mutableStateOf(consent.getBoolean("v8_intro_completed",false)) }
            val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                if (granted) {
                    consent.edit().putBoolean("notification_ever_granted",true)
                        .putBoolean("notification_revoke_notice_shown",false).apply()
                    CwaAlertWorker.checkNow(this@MainActivity)
                }
            }
            val locationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
                if (results.values.any { it }) currentLocation(vm)
                if (android.os.Build.VERSION.SDK_INT >= 33 &&
                    !io.atmos.weather.permission.PermissionGuide.hasNotifications(this@MainActivity) &&
                    !consent.getBoolean("alert_permission_asked",false)) {
                    consent.edit().putBoolean("alert_permission_asked",true).apply()
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            LaunchedEffect(introComplete) {
                if (!introComplete) return@LaunchedEffect
                val hasLocation=io.atmos.weather.permission.PermissionGuide.hasLocation(this@MainActivity)
                val lastId=getSharedPreferences("atmos_settings", MODE_PRIVATE).getString("city_id",null)
                if (hasLocation && (lastId == null || lastId == "gps")) currentLocation(vm)
                if (!hasLocation && !consent.getBoolean("location_permission_asked",false)) {
                    consent.edit().putBoolean("location_permission_asked",true).apply()
                    locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION))
                } else if (android.os.Build.VERSION.SDK_INT >= 33 &&
                    !io.atmos.weather.permission.PermissionGuide.hasNotifications(this@MainActivity) &&
                    !consent.getBoolean("alert_permission_asked",false)) {
                    consent.edit().putBoolean("alert_permission_asked",true).apply()
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            if (!introComplete) FirstRunGuide(onContinue={
                consent.edit().putBoolean("v8_intro_completed",true).apply()
                introComplete = true
            }) else WeatherHomeScreen(viewModel=vm, onLocate={
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) currentLocation(vm)
                else locationLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION))
            })
        }
    }
    override fun onResume() {
        super.onResume()
        val prefs = getSharedPreferences("thinn_settings", MODE_PRIVATE)
        val nowAllowed = io.atmos.weather.permission.PermissionGuide.canNotify(this)
        val locationAllowed = io.atmos.weather.permission.PermissionGuide.hasLocation(this)
        if (locationAllowed && !prefs.getBoolean("location_ever_granted",false)) {
            prefs.edit().putBoolean("location_ever_granted",true).apply()
        }
        if (locationAllowed) prefs.edit().putBoolean("location_revoke_notice_shown",false).apply()
        if (!locationAllowed && prefs.getBoolean("location_ever_granted",false) &&
            !prefs.getBoolean("location_revoke_notice_shown",false)) {
            android.widget.Toast.makeText(this,
                "thinn-khì 定位權限已關閉；可從設定重新開啟定位天氣。",
                android.widget.Toast.LENGTH_LONG).show()
            prefs.edit().putBoolean("location_revoke_notice_shown",true).apply()
        }
        if (nowAllowed && !prefs.getBoolean("notification_ever_granted", false)) {
            prefs.edit().putBoolean("notification_ever_granted", true).apply()
        }
        if (nowAllowed) prefs.edit().putBoolean("notification_revoke_notice_shown",false).apply()
        if (!nowAllowed && prefs.getBoolean("notification_ever_granted", false) &&
            !prefs.getBoolean("notification_revoke_notice_shown", false)) {
            android.widget.Toast.makeText(this,
                "thinn-khì 通知權限已關閉，天氣特報提醒可能無法送達；可到設定重新開啟。",
                android.widget.Toast.LENGTH_LONG).show()
            prefs.edit().putBoolean("notification_revoke_notice_shown",true).apply()
        }
    }

    @SuppressLint("MissingPermission")
    private fun currentLocation(vm: WeatherViewModel) {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val provider = when {
            manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        } ?: return
        try {
            manager.getCurrentLocation(provider, null, mainExecutor) { location ->
                location?.let {
                    val coords = GeoPoint(it.latitude, it.longitude)
                    lifecycleScope.launch {
                        val place = ReverseGeocoder.resolve(applicationContext, coords)
                        vm.onIntent(WeatherIntent.SelectCity(WeatherCity("gps", place, coords)))
                    }
                }
            }
        } catch (_: SecurityException) { /* permission revoked between request and callback */ }
    }
}
