package io.atmos.weather.presentation.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.animation.animateContentSize
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import io.atmos.weather.haptics.HapticEngine
import io.atmos.weather.haptics.LocalHapticEngine
import kotlin.math.abs
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.atmos.weather.domain.model.WeatherSnapshot
import kotlin.math.roundToInt

private val white=Color.White
private val dim=Color.White.copy(alpha=.70f)

@Composable
fun WeatherDial(title:String, value:String, description:String, fraction:Float, tint:Color, modifier:Modifier=Modifier) {
    val shape=RoundedCornerShape(24.dp)
    Column(modifier.background(white.copy(alpha=.10f),shape)
        .border(1.dp,white.copy(alpha=.15f),shape).padding(15.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            val graphic = when {
                title.contains("紫外線") -> Icons.Rounded.WbSunny
                title.contains("濕度") -> Icons.Rounded.WaterDrop
                title.contains("體感") -> Icons.Rounded.Thermostat
                else -> Icons.Rounded.Air
            }
            androidx.compose.material3.Icon(graphic,contentDescription=title,
                modifier=Modifier.size(17.dp),tint=tint)
            Text(title,color=dim,fontSize=13.sp,maxLines=1)
        }
        Spacer(Modifier.height(5.dp))
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(value,color=white,fontSize=23.sp,fontWeight=FontWeight.Medium,
                    style=TextStyle(fontFeatureSettings="tnum"))
                Text(description,color=dim,fontSize=10.sp,maxLines=2)
            }
            Box(Modifier.size(65.dp),contentAlignment=Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw=5.dp.toPx()
                    drawArc(Color.White.copy(alpha=.14f),startAngle=135f,sweepAngle=270f,useCenter=false,
                        style=Stroke(width=sw,cap=StrokeCap.Round))
                    drawArc(Brush.sweepGradient(listOf(tint.copy(alpha=.72f),tint)),startAngle=135f,
                        sweepAngle=270f*fraction.coerceIn(0f,1f),useCenter=false,
                        style=Stroke(width=sw,cap=StrokeCap.Round))
                }
            }
        }
    }
}

fun windDirectionLabel(degrees: Int?):String {
    if (degrees == null) return "風向未提供"
    val directions=listOf("北","東北","東","東南","南","西南","西","西北")
    return "${directions[((degrees+22)%360)/45]}風"
}

/** 2 x 2 responsive weather tiles. Long-press to reorder without capturing normal scroll. */
@Composable
fun WeatherIndicatorGrid(weather:WeatherSnapshot) {
    val ctx=LocalContext.current
    val haptic=LocalHapticEngine.current
    val pref=remember(ctx) { ctx.getSharedPreferences("thinn_settings",android.content.Context.MODE_PRIVATE) }
    val saved=remember { pref.getString("v8_metric_order","0,1,2,3") ?: "0,1,2,3" }
    val valid=remember(saved) {
        saved.split(',').mapNotNull { it.toIntOrNull() }.let { if(it.toSet()==setOf(0,1,2,3) && it.size==4) it else listOf(0,1,2,3) }
    }
    val order=remember { mutableStateListOf<Int>().apply{addAll(valid)} }
    Column(Modifier.fillMaxWidth().animateContentSize()) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            for(i in 0..1) MetricTile(order[i],i,weather,Modifier.weight(1f)) { moveFrom,moveTo ->
                val idx=order.indexOf(moveFrom)
                if(idx>=0){order.removeAt(idx);order.add(moveTo.coerceIn(0,order.size),moveFrom)
                    pref.edit().putString("v8_metric_order",order.joinToString(",")).apply()
                    haptic?.play(HapticEngine.Event.RELEASE) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)) {
            for(i in 2..3) MetricTile(order[i],i,weather,Modifier.weight(1f)) { moveFrom,moveTo ->
                val idx=order.indexOf(moveFrom)
                if(idx>=0){order.removeAt(idx);order.add(moveTo.coerceIn(0,order.size),moveFrom)
                    pref.edit().putString("v8_metric_order",order.joinToString(",")).apply()
                    haptic?.play(HapticEngine.Event.RELEASE) }
            }
        }
        Text("長按儀表卡片後向左、右或上下拖動，可重新排列",color=dim,fontSize=11.sp,
            modifier=Modifier.padding(top=8.dp))
    }
}

@Composable
private fun MetricTile(id:Int,position:Int, weather:WeatherSnapshot, modifier:Modifier, onReorder:(Int,Int)->Unit) {
    val haptics=LocalHapticEngine.current
    var accumulatedX by remember(id){ mutableFloatStateOf(0f) }
    var accumulatedY by remember(id){ mutableFloatStateOf(0f) }
    var moved by remember(id){ mutableStateOf(false) }
    var pressed by remember(id){ mutableStateOf(false) }
    val emphasis by androidx.compose.animation.core.animateFloatAsState(
        if(pressed) 1.035f else 1f, label="card drag emphasis")
    val gesture=Modifier.pointerInput(id) {
        detectDragGesturesAfterLongPress(onDragStart={
            accumulatedX=0f;accumulatedY=0f;moved=false;pressed=true
            haptics?.play(HapticEngine.Event.TAP)
        },onDragEnd={
            pressed=false
            if(moved) {
                val dx=when {accumulatedX>54f -> 1;accumulatedX< -54f -> -1;else -> 0}
                val dy=when {accumulatedY>72f -> 2;accumulatedY< -72f -> -2;else -> 0}
                onReorder(id,(position+if(abs(accumulatedY)>abs(accumulatedX))dy else dx).coerceIn(0,3))
            }
        },onDragCancel={moved=false;pressed=false}) { change,amount ->
            change.consume()
            accumulatedX+=amount.x;accumulatedY+=amount.y
            moved=abs(accumulatedX)>54f || abs(accumulatedY)>72f
        }
    }
    when(id){
        0->WeatherDial("紫外線",weather.currentUv?.let { String.format("%.1f",it) } ?: "—",
            if((weather.currentUv ?: 0.0)>=8) "過量" else "目前紫外線",
            ((weather.currentUv ?: 0.0)/11.0).toFloat(),Color(0xFFFFBD71),modifier.graphicsLayer { scaleX=emphasis;scaleY=emphasis }.then(gesture))
        1->WeatherDial("濕度",weather.humidityPct?.let{"$it%"} ?: "—", "相對濕度",
            (weather.humidityPct ?: 0)/100f,Color(0xFF46C4FF),modifier.graphicsLayer { scaleX=emphasis;scaleY=emphasis }.then(gesture))
        2->WeatherDial("體感",weather.feelsLikeC?.let{"${it.roundToInt()}°"} ?: "—", "體感溫度",
            (((weather.feelsLikeC ?: 15.0)+10)/50).toFloat(),Color(0xFF80D1E7),modifier.graphicsLayer { scaleX=emphasis;scaleY=emphasis }.then(gesture))
        else->WeatherDial("風向 · ${windDirectionLabel(weather.windDirectionDeg)}",
            weather.windKmh?.let{"${it.roundToInt()}"} ?: "—", "km/h",
            ((weather.windKmh ?: 0.0)/60).toFloat(),Color(0xFF78D6B4),modifier.graphicsLayer { scaleX=emphasis;scaleY=emphasis }.then(gesture))
    }
}

fun usAqiLabel(value:Int?):String = when {
    value==null -> "暫無資料"
    value<=50 -> "良好"
    value<=100 -> "普通"
    value<=150 -> "敏感族群注意"
    value<=200 -> "不健康"
    value<=300 -> "非常不健康"
    else -> "危害"
}
