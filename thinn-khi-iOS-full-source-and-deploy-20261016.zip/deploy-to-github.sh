#!/usr/bin/env bash
# One-time migration to tracked-source GitHub Actions. NEVER auto-publishes a Release.
set -euo pipefail
repo='luc700428-hash/thinn-kh-.'
base="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for bin in gh git; do
  command -v "$bin" >/dev/null 2>&1 || { echo "需要安裝 $bin"; exit 2; }
done
test -s "$base/android-project/app/src/main/java/io/atmos/weather/MainActivity.kt" || {
  echo '缺少 android-project 原始碼。請先將交付 ZIP 完整解壓。'; exit 2; }
test -s "$base/.github/workflows/build-apk.yml" || { echo '缺少 GitHub Actions 工作流程'; exit 2; }
gh auth status >/dev/null || { echo '請先使用 gh auth login 登入你自己的 GitHub 帳號'; exit 2; }
gh auth setup-git
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
printf '正在從 GitHub 取得目前 main 分支…\n'
gh repo clone "$repo" "$work/repo" -- --depth 1
# Replace only the dedicated, generated Android source folder; keep other repo content untouched.
rm -rf "$work/repo/android-project"
cp -R "$base/android-project" "$work/repo/android-project"
mkdir -p "$work/repo/.github/workflows"
cp "$base/.github/workflows/build-apk.yml" "$work/repo/.github/workflows/build-apk.yml"
cd "$work/repo"
git add -A -- android-project .github/workflows/build-apk.yml
if git diff --cached --quiet; then
  echo 'GitHub 已有相同的新版 Android 專案，無須重複提交。'; exit 0
fi
git -c user.name='thinn-khì Termux publisher' -c user.email='termux@users.noreply.github.com' \
  commit -m 'feat: track Android source and integrate consistent iOS-inspired UI'
# Never force-push: branch protection and newer remote commits must be respected.
git push origin HEAD:main
printf '\n已推送完整 Kotlin 原始碼與新 workflow。push 會自動執行 CI；沒有發布正式 OTA。\n'
echo "檢查 CI：gh run list --repo '$repo' --workflow build-apk.yml --limit 3"
echo '只有 CI 通過且手機驗收成功，才使用原本的 publish_release=true 指令。'
