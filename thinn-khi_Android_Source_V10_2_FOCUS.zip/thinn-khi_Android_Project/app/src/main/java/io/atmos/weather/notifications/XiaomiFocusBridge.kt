package io.atmos.weather.notifications

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.drawable.Icon
import androidx.core.app.NotificationCompat
import io.atmos.weather.MainActivity
import io.atmos.weather.R
import org.json.JSONObject

/**
 * Client-side Xiaomi HyperOS 2 Focus Notification / HyperOS 3 Super Island integration.
 * Only sends vendor extensions if the actual device and *app* are granted focus permission.
 * Otherwise retains a fully functional standard Android notification.
 *
 * Official guides:
 * https://dev.mi.com/xiaomihyperos/documentation/detail?pId=2131
 * https://dev.mi.com/xiaomihyperos/documentation/detail?pId=2146
 * A vendor permission and an approved notification scenario may be required.
 */
object XiaomiFocusBridge {
    enum class Availability { NOT_XIAOMI, UNSUPPORTED, PERMISSION_NOT_GRANTED, ENABLED }

    fun isXiaomi(): Boolean {
        val name = "${Build.MANUFACTURER} ${Build.BRAND}".lowercase()
        return listOf("xiaomi", "redmi", "poco").any { name.contains(it) }
    }

    fun protocol(context: Context): Int {
        if (!isXiaomi()) return 0
        return runCatching { Settings.System.getInt(context.contentResolver, "notification_focus_protocol", 0) }
            .getOrDefault(0).coerceIn(0, 3)
    }

    /** Does not attempt to bypass Xiaomi's application allowlist. Call from a worker/background thread. */
    fun availability(context: Context): Availability {
        if (!isXiaomi()) return Availability.NOT_XIAOMI
        if (protocol(context) < 2) return Availability.UNSUPPORTED
        return try {
            val extras = Bundle().apply { putString("package", context.packageName) }
            val answer = context.contentResolver.call(
                Uri.parse("content://miui.statusbar.notification.public"),
                "canShowFocus", null, extras
            )
            if (answer?.getBoolean("canShowFocus", false) == true) Availability.ENABLED
            else Availability.PERMISSION_NOT_GRANTED
        } catch (_: Exception) { Availability.PERMISSION_NOT_GRANTED }
    }

    /** Construct compact, single-purpose official-warning metadata. No marketing or fake alarm. */
    internal fun focusJson(protocol: Int, title: String, location: String): String {
        val heading = title.take(36)
        val area = location.take(44)
        val p = JSONObject().apply {
            put("protocol", 1)
            put("business", "weather")
            put("islandFirstFloat", true)
            put("enableFloat", true)
            put("updatable", false)
            put("timeout", 45)
            put("filterWhenNoPermission", false)
            put("ticker", heading.take(18))
            put("aodTitle", heading.take(24))
            put("baseInfo", JSONObject().apply {
                put("type", 2)
                put("title", heading)
                put("content", area)
                put("colorTitle", "#E74747")
            })
            if (protocol >= 3) {
                put("param_island", JSONObject().apply {
                    put("islandProperty", 1)
                    put("islandTimeout", 10)
                    put("smallIslandArea", JSONObject().apply {
                        put("picInfo", JSONObject().apply {
                            put("type", 1)
                            put("pic", "miui.focus.pic_alert")
                        })
                    })
                    put("bigIslandArea", JSONObject().apply {
                        put("imageTextInfoLeft", JSONObject().apply {
                            put("type", 1)
                            put("picInfo", JSONObject().apply {
                                put("type", 1)
                                put("pic", "miui.focus.pic_alert")
                            })
                            // Same property name as Xiaomi's current example payload.
                            put("miui.focus.paramtextInfo", JSONObject().apply {
                                put("frontTitle", "特報")
                                put("title", heading.take(20))
                                put("content", area.take(25))
                                put("useHighLight", true)
                            })
                        })
                    })
                })
            }
        }
        return JSONObject().put("param_v2", p).toString()
    }

    /** Adds HyperOS focus/island extras to an already-built notification only when authorized. */
    fun decorate(context: Context, notification: Notification, title: String, location: String): Boolean {
        if (availability(context) != Availability.ENABLED) return false
        return runCatching {
            val p = protocol(context)
            notification.extras.putString("miui.focus.param", focusJson(p, title, location))
            val pics = Bundle().apply {
                putParcelable("miui.focus.pic_alert", Icon.createWithResource(context, R.mipmap.ic_launcher))
            }
            notification.extras.putBundle("miui.focus.pics", pics)
            true
        }.getOrDefault(false)
    }

    /** Explicit user-triggered demonstration only. Never impersonate a real CWA warning. */
    fun sendTest(context: Context): Availability {
        val state = availability(context)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "thinn_focus_demo"
        manager.createNotificationChannel(NotificationChannel(channelId, "焦點通知測試", NotificationManager.IMPORTANCE_HIGH))
        val intent = PendingIntent.getActivity(context, 2001,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("thinn-khì · 焦點通知測試")
            .setContentText("這是測試訊息，不是中央氣象署發布的警報。")
            .setStyle(NotificationCompat.BigTextStyle().bigText("僅用於確認 HyperOS 焦點通知／超級島相容性，這不是正式氣象警報。"))
            .setAutoCancel(true)
            .setContentIntent(intent)
            .build()
        decorate(context, n, "thinn-khì 測試", "不是正式氣象警報")
        manager.notify(201101, n)
        return state
    }
}
