package io.atmos.weather.presentation.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.atmos.weather.domain.model.HourlyWeather
import io.atmos.weather.haptics.LocalHapticEngine
import io.atmos.weather.haptics.HapticEngine
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.math.roundToInt

/** Whole-width scrubber: first observation at the far left, last at far right.
 * Horizontal gestures select hours; vertical gestures remain available to the page.
 */
@Composable
fun InteractiveForecast(hours: List<HourlyWeather>, timeZoneId: String?=null, modifier: Modifier=Modifier) {
    val readings = remember(hours) { hours.take(24) }
    if (readings.size < 2) return
    val zone = remember(timeZoneId) { runCatching { ZoneId.of(timeZoneId ?: "Asia/Taipei") }.getOrDefault(ZoneId.of("Asia/Taipei")) }
    var selected by remember(readings) { mutableIntStateOf(0) }
    var plotWidth by remember { mutableFloatStateOf(1f) }
    val haptic = LocalHapticEngine.current
    var previous by remember(readings) { mutableIntStateOf(0) }
    LaunchedEffect(selected) {
        if (selected != previous) haptic?.play(HapticEngine.Event.DRAG, variation=.18f)
        previous = selected
    }
    fun choose(x:Float) {
        selected = ((x / plotWidth.coerceAtLeast(1f)) * (readings.size-1)).roundToInt().coerceIn(0,readings.lastIndex)
    }
    val hour = readings[selected]
    val local = hour.at.atZone(zone)
    Column(modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
            Text("24 小時預報 · 拖動曲線查看",fontSize=14.sp,color=Color.White,fontWeight=FontWeight.SemiBold)
            Text("${local.format(DateTimeFormatter.ofPattern("HH:mm"))}  ${hour.temperatureC?.roundToInt()?.let { "$it°" } ?: "—"}",
                color=Color(0xFFFFD68A),fontSize=14.sp,style=TextStyle(fontFeatureSettings="tnum"))
        }
        Spacer(Modifier.height(9.dp))
        Row(verticalAlignment=Alignment.CenterVertically) {
            Icon(weatherVector(hour.weatherCode,local.hour),null,tint=Color(0xFF91D2FC),modifier=Modifier.size(24.dp))
            Spacer(Modifier.width(8.dp))
            Text(hourlyWeatherName(hour.weatherCode, local.hour),color=Color.White,fontSize=15.sp,fontWeight=FontWeight.Medium)
            Spacer(Modifier.weight(1f))
            Text("降雨 ${hour.precipitationProbabilityPct?.let { "$it%" } ?: "—"}",color=Color.White.copy(alpha=.77f),fontSize=12.sp)
        }
        Spacer(Modifier.height(13.dp))
        val temperatures = readings.map { it.temperatureC ?: 0.0 }
        val low=(temperatures.minOrNull() ?: 0.0)-1.5
        val high=(temperatures.maxOrNull() ?: 1.0)+1.5
        val span=(high-low).coerceAtLeast(3.0)
        Canvas(Modifier.fillMaxWidth().height(136.dp).onSizeChanged { plotWidth=it.width.toFloat() }
            .pointerInput(readings) { detectTapGestures { choose(it.x) } }
            .pointerInput(readings) {
                detectHorizontalDragGestures(onDragStart={choose(it.x)}) { change, _ ->
                    choose(change.position.x)
                    change.consume()
                }
            }) {
            val count=readings.lastIndex
            val left=3.dp.toPx();val right=size.width-left
            val usable=(right-left).coerceAtLeast(1f)
            val coords=readings.mapIndexed { index,h ->
                val x=left+usable*index/count
                val y=size.height*.83f-((( (h.temperatureC ?: low)-low)/span).toFloat()*size.height*.67f)
                Offset(x,y)
            }
            for(i in 0..3) {
                val y=size.height*(.19f+.21f*i)
                drawLine(Color.White.copy(alpha=.13f),Offset(0f,y),Offset(size.width,y),1.dp.toPx())
            }
            val shape=Path().apply {
                moveTo(coords.first().x,coords.first().y)
                for(i in 1 until coords.size) {
                    val a=coords[i-1];val b=coords[i];val mid=(a.x+b.x)/2f
                    cubicTo(mid,a.y,mid,b.y,b.x,b.y)
                }
            }
            drawPath(shape,Brush.horizontalGradient(listOf(Color(0xFFFFD48E), Color(0xFFFFA94F))),
                style=Stroke(width=3.dp.toPx(),cap=StrokeCap.Round))
            val point=coords[selected]
            drawLine(Color.White.copy(alpha=.69f),Offset(point.x,0f),Offset(point.x,size.height),1.dp.toPx())
            drawCircle(Color(0xFFFFCA70),6.dp.toPx(),point)
            drawCircle(Color.White,3.dp.toPx(),point)
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
            listOf(0,5,11,17,23).forEach { index ->
                Text(readings[index.coerceAtMost(readings.lastIndex)].at.atZone(zone)
                    .format(DateTimeFormatter.ofPattern("HH:mm")),fontSize=10.sp,
                    color=Color.White.copy(alpha=.75f),style=TextStyle(fontFeatureSettings="tnum"))
            }
        }
        Spacer(Modifier.height(5.dp))
        Text("選取 ${local.format(DateTimeFormatter.ofPattern("MM/dd HH:mm"))} · ${hourlyWeatherName(hour.weatherCode,local.hour)} · 風速 ${hour.windKmh?.roundToInt()?.let { "$it km/h" } ?: "—"}",
            fontSize=11.sp,color=Color.White.copy(alpha=.78f),style=TextStyle(fontFeatureSettings="tnum"))
    }
}

/** Open-Meteo / WMO weather interpretation, separate nighttime icon selection. */
fun hourlyWeatherName(code: Int?, hour: Int): String = when(code) {
    0 -> if(hour < 6 || hour >= 18) "晴朗夜晚" else "晴天"
    1 -> if(hour < 6 || hour >= 18) "夜間晴時多雲" else "晴時多雲"
    2 -> "局部多雲"
    3 -> "陰天"
    45,48 -> "起霧"
    51,53,55,56,57 -> "毛毛雨"
    61,66 -> "小雨"
    63 -> "中雨"
    65,67,82 -> "大雨"
    80 -> "短暫小雨"
    81 -> "短暫中雨"
    71,77,85 -> "小雪"
    73 -> "中雪"
    75,86 -> "大雪"
    95 -> "雷雨"
    96,99 -> "強雷雨"
    else -> "天氣變化"
}

fun weatherVector(code:Int?,hour:Int):androidx.compose.ui.graphics.vector.ImageVector = when(code) {
    0,1 -> if(hour < 6 || hour >= 18) Icons.Rounded.NightsStay else Icons.Rounded.WbSunny
    2,3 -> Icons.Rounded.Cloud
    45,48 -> Icons.Rounded.Dehaze
    51,53,55,56,57,61,63,65,66,67,80,81,82 -> Icons.Rounded.Grain
    71,73,75,77,85,86 -> Icons.Rounded.AcUnit
    95,96,99 -> Icons.Rounded.Thunderstorm
    else -> Icons.Rounded.CloudQueue
}
