package io.atmos.weather.domain.visual

import io.atmos.weather.domain.model.WeatherCondition
import io.atmos.weather.domain.model.WeatherSnapshot

/** UI / Filament share a value object. No engine types leak into domain. */
enum class LandmarkId { TAIPEI_101, TOKYO_SKYTREE, EIFFEL_TOWER, WEATHER_COTTAGE }

data class WeatherScene(
    val landmark: LandmarkId,
    val wetness: Float,
    val snowAccumulation: Float,
    val nightLight: Float,
    val precipitationIntensity: Float,
    val showLightning: Boolean
)

fun sceneFor(weather: WeatherSnapshot): WeatherScene {
    val lat = weather.city.coordinate.latitude
    val lon = weather.city.coordinate.longitude
    // Illustrative city-level bounding boxes: replace with landmark geofences & location catalog.
    val landmark = when {
        lat in 24.90..25.25 && lon in 121.35..121.75 -> LandmarkId.TAIPEI_101
        lat in 35.50..35.85 && lon in 139.50..139.95 -> LandmarkId.TOKYO_SKYTREE
        lat in 48.75..48.95 && lon in 2.20..2.50 -> LandmarkId.EIFFEL_TOWER
        else -> LandmarkId.WEATHER_COTTAGE
    }
    val rain = weather.condition == WeatherCondition.RAIN || weather.condition == WeatherCondition.THUNDERSTORM
    val snow = weather.condition == WeatherCondition.SNOW
    return WeatherScene(
        landmark = landmark,
        wetness = if (rain) 0.8f else 0f,
        snowAccumulation = if (snow) 0.85f else 0f,
        nightLight = if (weather.isDay) 0f else 1f,
        precipitationIntensity = if (rain || snow) 0.65f else 0f,
        showLightning = weather.condition == WeatherCondition.THUNDERSTORM
    )
}
