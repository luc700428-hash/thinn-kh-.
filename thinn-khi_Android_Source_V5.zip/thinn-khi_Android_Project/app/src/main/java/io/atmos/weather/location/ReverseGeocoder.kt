package io.atmos.weather.location

import android.content.Context
import android.location.Geocoder
import io.atmos.weather.domain.model.GeoPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

object ReverseGeocoder {
    @Suppress("DEPRECATION")
    suspend fun resolve(context: Context, point: GeoPoint): String = withContext(Dispatchers.IO) {
        val fallback = LocationLabels.fallback(point)
        try {
            if (!Geocoder.isPresent()) return@withContext fallback
            val result = Geocoder(context, Locale.TRADITIONAL_CHINESE)
                .getFromLocation(point.latitude, point.longitude, 1)?.firstOrNull()
                ?: return@withContext fallback
            val country = result.countryName
            val countryCode = result.countryCode
            val region = result.adminArea
            // Prefer village/district if provided so GPS displays meaningful *local* location.
            val district = result.subLocality ?: result.locality ?: result.subAdminArea
            val label = LocationLabels.name(countryCode, country, region, district)
            if (label == "未知地點") fallback else label
        } catch (_: Exception) { fallback }
    }
}
