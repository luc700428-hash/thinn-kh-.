package io.atmos.weather.presentation.home

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import io.atmos.weather.AppContainer
import io.atmos.weather.domain.model.*
import io.atmos.weather.domain.repository.WeatherDataRepository
import io.atmos.weather.domain.repository.WeatherLoadResult
import io.atmos.weather.domain.visual.*
import io.atmos.weather.widgets.WidgetSync
import io.atmos.weather.widgets.WidgetSnapshotStore
import io.atmos.weather.alerts.CwaWarningFeed
import io.atmos.weather.alerts.CwaWarning
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed interface WeatherIntent {
    data class SelectCity(val city: WeatherCity) : WeatherIntent
    data object Refresh : WeatherIntent
}
data class WeatherUiState(
    val city: WeatherCity = SampleCities.all.first(),
    val loading: Boolean = false,
    val weather: WeatherSnapshot? = null,
    val scene: WeatherScene? = null,
    val fromCache: Boolean = false,
    val stale: Boolean = false,
    val error: String? = null,
    val searching: Boolean = false,
    val searchResults: List<WeatherCity> = emptyList(),
    val cwaWarnings: List<CwaWarning> = emptyList()
)
class WeatherViewModel(
    private val repository: WeatherDataRepository,
    private val context: Context
) : ViewModel() {
    private val prefs = context.getSharedPreferences("atmos_settings", Context.MODE_PRIVATE)
    private val startCity = run {
        val id = prefs.getString("city_id", null)
        SampleCities.all.find { it.id == id } ?: if (id != null && prefs.contains("lat")) {
            WeatherCity(id, prefs.getString("city_name", "自訂地點") ?: "自訂地點",
                GeoPoint(Double.fromBits(prefs.getLong("lat", 0)), Double.fromBits(prefs.getLong("lon", 0))))
        } else SampleCities.all.first()
    }
    private val mutableState = MutableStateFlow(WeatherUiState(city = startCity))
    val uiState: StateFlow<WeatherUiState> = mutableState.asStateFlow()
    private var requestJob: Job? = null
    private var searchJob: Job? = null
    private var warningJob: Job? = null
    init { load(false); loadWarnings() }
    fun onIntent(intent: WeatherIntent) = when (intent) {
        is WeatherIntent.SelectCity -> {
            val c = intent.city
            prefs.edit().putString("city_id", c.id).putString("city_name", c.name)
                .putLong("lat", c.coordinate.latitude.toBits()).putLong("lon", c.coordinate.longitude.toBits()).apply()
            WidgetSnapshotStore.clear(context)
            mutableState.update { it.copy(city=c, weather=null, scene=null, error=null, searchResults= emptyList()) }
            load(false)
            loadWarnings()
        }
        WeatherIntent.Refresh -> load(true)
    }
    fun search(query: String) {
        searchJob?.cancel()
        if (query.trim().length < 2) {
            mutableState.update { it.copy(searchResults = emptyList(), searching = false) }
            return
        }
        searchJob = viewModelScope.launch {
            mutableState.update { it.copy(searching = true) }
            try {
                val results = AppContainer.geoApi.search(query.trim()).results.orEmpty().map { it.asCity() }
                mutableState.update { it.copy(searching=false, searchResults=results) }
            } catch (cancel: CancellationException) { throw cancel }
            catch (_: Exception) { mutableState.update { it.copy(searching=false, searchResults= emptyList()) } }
        }
    }
    private fun loadWarnings() {
        warningJob?.cancel()
        val city = mutableState.value.city
        if (!city.name.startsWith("台灣") && !city.name.startsWith("臺灣")) {
            mutableState.update { it.copy(cwaWarnings = emptyList()) }
            return
        }
        warningJob = viewModelScope.launch {
            val list = CwaWarningFeed.forLocation(city.name)
            if (mutableState.value.city.id == city.id) {
                mutableState.update { it.copy(cwaWarnings = list) }
            }
        }
    }
    private fun load(force: Boolean) {
        if (force) loadWarnings()
        requestJob?.cancel()
        val city = mutableState.value.city
        requestJob = viewModelScope.launch {
            mutableState.update { it.copy(loading = true, error = null) }
            when (val result = repository.load(city, force)) {
                is WeatherLoadResult.Success -> {
                    mutableState.update {
                        it.copy(loading = false, weather = result.value, scene = sceneFor(result.value),
                            fromCache = result.fromCache, stale = result.stale)
                    }
                    if(mutableState.value.city.id == city.id) {
                        WidgetSnapshotStore.publish(context,result.value)
                        WidgetSync.updateVisible(context)
                    }
                }
                is WeatherLoadResult.Failure -> mutableState.update { it.copy(loading=false,error=result.cause) }
            }
        }
    }
    class Factory(private val repository: WeatherDataRepository, private val context: Context) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T: ViewModel> create(modelClass: Class<T>): T {
            require(modelClass.isAssignableFrom(WeatherViewModel::class.java))
            return WeatherViewModel(repository, context.applicationContext) as T
        }
    }
}
