package io.atmos.weather

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.content.Intent
import io.atmos.weather.domain.visual.WeatherScene
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import io.atmos.weather.domain.model.GeoPoint
import io.atmos.weather.domain.model.WeatherCity
import io.atmos.weather.presentation.home.*
import io.atmos.weather.widgets.WidgetSync
import io.atmos.weather.location.ReverseGeocoder
import io.atmos.weather.alerts.CwaAlertWorker
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.rgb(15, 26, 45)
        WidgetSync.schedule(this)
        CwaAlertWorker.schedule(this)
        setContent {
            val vm: WeatherViewModel = viewModel(factory=WeatherViewModel.Factory(AppContainer.repository(applicationContext), applicationContext))
            val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
                if (results.values.any { it }) currentLocation(vm)
            }
            LaunchedEffect(Unit) {
                val enabled = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val lastId = getSharedPreferences("atmos_settings", MODE_PRIVATE).getString("city_id", null)
                if (enabled && (lastId == null || lastId == "gps")) currentLocation(vm)
                else if (!enabled) {
                    val prefs = getSharedPreferences("thinn_settings", MODE_PRIVATE)
                    if (!prefs.getBoolean("location_permission_asked", false)) {
                        prefs.edit().putBoolean("location_permission_asked", true).apply()
                        launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                    }
                }
            }
            val alertPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
            LaunchedEffect(Unit) {
                if (android.os.Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
                    !getSharedPreferences("thinn_settings", MODE_PRIVATE).getBoolean("alert_permission_asked", false)) {
                    getSharedPreferences("thinn_settings", MODE_PRIVATE).edit().putBoolean("alert_permission_asked", true).apply()
                    alertPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
            WeatherHomeScreen(viewModel=vm, onOpen3D={ scene ->
                startActivity(Intent(this, LandmarkViewerActivity::class.java).apply {
                    putExtra("landmark",scene?.landmark?.name ?: "WEATHER_COTTAGE")
                    putExtra("night",(scene?.nightLight ?: 0f)>0f)
                    putExtra("rain",(scene?.wetness ?: 0f)>0f)
                    putExtra("snow",(scene?.snowAccumulation ?: 0f)>0f)
                })
            }, onLocate={
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) currentLocation(vm)
                else launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION))
            })
        }
    }
    @SuppressLint("MissingPermission")
    private fun currentLocation(vm: WeatherViewModel) {
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        val provider = when {
            manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        } ?: return
        try {
            manager.getCurrentLocation(provider, null, mainExecutor) { location ->
                location?.let {
                    val coords = GeoPoint(it.latitude, it.longitude)
                    lifecycleScope.launch {
                        val place = ReverseGeocoder.resolve(applicationContext, coords)
                        vm.onIntent(WeatherIntent.SelectCity(WeatherCity("gps", place, coords)))
                    }
                }
            }
        } catch (_: SecurityException) { /* permission revoked between request and callback */ }
    }
}
