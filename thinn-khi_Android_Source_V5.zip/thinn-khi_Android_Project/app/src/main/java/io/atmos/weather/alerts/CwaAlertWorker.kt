package io.atmos.weather.alerts

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import io.atmos.weather.MainActivity
import java.util.concurrent.TimeUnit

class CwaAlertWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val context = applicationContext
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return Result.success()
        val prefs = context.getSharedPreferences("atmos_settings", Context.MODE_PRIVATE)
        val cityName = prefs.getString("city_name", null) ?: return Result.success()
        if (!cityName.startsWith("台灣") && !cityName.startsWith("臺灣")) return Result.success()
        val alert = CwaWarningFeed.forLocation(cityName).firstOrNull() ?: return Result.success()
        if (alert.issuedAt.isBefore(java.time.Instant.now().minusSeconds(30 * 60))) return Result.success()
        val shownId = "${alert.title}|${alert.issuedAt.epochSecond}"
        val settings = context.getSharedPreferences("thinn_settings", Context.MODE_PRIVATE)
        if (settings.getString("last_cwa_alert", null) == shownId) return Result.success()
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(NotificationChannel("cwa_weather_warnings", "中央氣象署警特報", NotificationManager.IMPORTANCE_HIGH))
        val action = PendingIntent.getActivity(context, 0,
            Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(context, "cwa_weather_warnings")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("中央氣象署：${alert.title}")
            .setContentText(alert.summary.take(120).ifBlank { "請查看官方最新警特報資訊。" })
            .setStyle(NotificationCompat.BigTextStyle().bigText(alert.summary.take(500)))
            .setAutoCancel(true).setContentIntent(action).build()
        notificationManager.notify(2018, notification)
        settings.edit().putString("last_cwa_alert", shownId).apply()
        return Result.success()
    }
    companion object {
        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<CwaAlertWorker>(30, TimeUnit.MINUTES).build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork("cwa_alert_rss", ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
