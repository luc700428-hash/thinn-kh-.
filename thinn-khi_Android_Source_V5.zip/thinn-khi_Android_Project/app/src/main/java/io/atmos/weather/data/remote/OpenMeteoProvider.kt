package io.atmos.weather.data.remote

import io.atmos.weather.domain.model.HourlyWeather
import io.atmos.weather.domain.model.WeatherCity
import io.atmos.weather.domain.model.WeatherCondition
import io.atmos.weather.domain.model.WeatherSnapshot
import java.time.Clock
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId

class OpenMeteoProvider(
    private val api: OpenMeteoApi,
    private val clock: Clock = Clock.systemUTC()
) : WeatherProvider {
    override val id = "open-meteo"

    override suspend fun get(city: WeatherCity): WeatherSnapshot {
        val response = api.forecast(city.coordinate.latitude, city.coordinate.longitude)
        val zone = ZoneId.of(response.timezone ?: "UTC")
        val current = requireNotNull(response.current) { "Missing current weather" }
        val now = requireNotNull(current.time) { "Missing observation timestamp" }.asInstant(zone)
        val temp = requireNotNull(current.temperature) { "Missing temperature" }
        val times = response.hourly?.time.orEmpty()
        val series = times.mapIndexedNotNull { index, timestamp ->
            runCatching {
                HourlyWeather(
                    at = timestamp.asInstant(zone),
                    temperatureC = response.hourly?.temperatures?.getOrNull(index),
                    precipitationProbabilityPct = response.hourly?.rainProbabilities?.getOrNull(index),
                    uvIndex = response.hourly?.uvIndices?.getOrNull(index)
                )
            }.getOrNull()
        }
        return WeatherSnapshot(
            city = city,
            observedAt = now,
            fetchedAt = clock.instant(),
            sourceId = id,
            temperatureC = temp,
            feelsLikeC = current.feelsLike,
            humidityPct = current.humidity,
            windKmh = current.wind,
            pressureHpa = current.pressure,
            condition = conditionFromWmo(current.code),
            isDay = current.isDay == 1,
            sunrise = response.daily?.sunrise?.firstOrNull()?.asInstant(zone),
            sunset = response.daily?.sunset?.firstOrNull()?.asInstant(zone),
            hourly = series,
            maxTempC = response.daily?.highs?.firstOrNull(),
            minTempC = response.daily?.lows?.firstOrNull(),
            currentUv = current.uv,
            weatherCode = current.code
        )
    }
}

private fun String.asInstant(zone: ZoneId): Instant = LocalDateTime.parse(this).atZone(zone).toInstant()

/** Open-Meteo current weather_code uses WMO numeric codes. */
fun conditionFromWmo(code: Int?): WeatherCondition = when (code) {
    0 -> WeatherCondition.CLEAR
    1, 2 -> WeatherCondition.PARTLY_CLOUDY
    3 -> WeatherCondition.CLOUDY
    45, 48 -> WeatherCondition.FOG
    in 51..67, in 80..82 -> WeatherCondition.RAIN
    in 71..77, 85, 86 -> WeatherCondition.SNOW
    in 95..99 -> WeatherCondition.THUNDERSTORM
    else -> WeatherCondition.UNKNOWN
}
