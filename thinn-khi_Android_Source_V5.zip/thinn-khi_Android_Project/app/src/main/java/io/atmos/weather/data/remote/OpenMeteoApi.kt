package io.atmos.weather.data.remote

import com.google.gson.annotations.SerializedName
import retrofit2.http.GET
import retrofit2.http.Query

interface OpenMeteoApi {
    @GET("v1/forecast")
    suspend fun forecast(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,surface_pressure,uv_index",
        @Query("hourly") hourly: String = "temperature_2m,precipitation_probability,uv_index",
        @Query("daily") daily: String = "sunrise,sunset,temperature_2m_max,temperature_2m_min",
        @Query("timezone") timezone: String = "auto",
        @Query("forecast_days") forecastDays: Int = 3
    ): OpenMeteoResponse
}

data class OpenMeteoResponse(val timezone: String?, val current: CurrentDto?, val hourly: HourlyDto?, val daily: DailyDto?)
data class CurrentDto(
    val time: String?,
    @SerializedName("temperature_2m") val temperature: Double?,
    @SerializedName("relative_humidity_2m") val humidity: Int?,
    @SerializedName("apparent_temperature") val feelsLike: Double?,
    @SerializedName("is_day") val isDay: Int?,
    @SerializedName("weather_code") val code: Int?,
    @SerializedName("wind_speed_10m") val wind: Double?,
    @SerializedName("surface_pressure") val pressure: Double?,
    @SerializedName("uv_index") val uv: Double?
)
data class HourlyDto(
    val time: List<String>?,
    @SerializedName("temperature_2m") val temperatures: List<Double?>?,
    @SerializedName("precipitation_probability") val rainProbabilities: List<Int?>?,
    @SerializedName("uv_index") val uvIndices: List<Double?>?
)
data class DailyDto(
    val sunrise: List<String>?,
    val sunset: List<String>?,
    @SerializedName("temperature_2m_max") val highs: List<Double?>?,
    @SerializedName("temperature_2m_min") val lows: List<Double?>?
)
