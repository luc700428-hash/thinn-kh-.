# thinn-khì V5 — Liquid Glass & Haptic Engine

Android 12+ / Kotlin / Jetpack Compose. Builds on the V4 architecture, including weather forecasts, location, alerts, interactive 3D landmarks and 25 widgets.

## V5 changes
- New glass-style brand icon in all launcher density buckets and main header.
- `haptics/HapticSettings.kt`: continuous per-category user preferences persisted to `thinn_settings`.
- `haptics/HapticEngine.kt`: Android VibratorManager and VibrationEffect controller with device amplitude detection, minimum intervals, power-save and silence policies.
- Compose settings page: master switch, five continuous intensity sliders, rain/thunder opt-in, silent/power-save switches, haptic preview buttons.
- Tap / drag / spring feedback on key UI controls and landmark interaction.
- Foreground-only rain sample haptics and lightning haptics (opt-in, not per particle). Does not run weather haptics when app is backgrounded.

## Important limits
- Device amplitude precision varies, so numeric slider values are a *request*, not physical acceleration guarantees.
- Rain and storm haptics are opt-in, rate-limited and suspended when the app is not in the foreground. No continuous vibration loop.
- Home-screen widgets cannot vibrate for passive weather animations, nor can they run true continuous glass blur; widget updates use native constraints.
- Weather warnings remain subject to official source feed availability; haptics are supplementary and never substitute emergency warnings.
- This source package has **not** passed a full Android SDK build/device QA in the present environment. Use the attached GitHub Actions workflow; compiler logs are uploaded when builds fail.

## Build
Upload `thinn-khi_Android_Source_V5.zip` to your GitHub repository root, and replace `.github/workflows/build-apk.yml` with `thinn-khi-V5-build-apk.yml`.
The workflow extracts this archive, invokes `:app:assembleDebug`, and publishes `thinn-khi-V5-APK` only when the build succeeds.

## Fine-haptics implementation update
- Uses native calibrated `VibrationEffect.Composition` primitives when available (`PRIMITIVE_LOW_TICK`, `TICK`, `CLICK`, `QUICK_FALL`, `SLOW_RISE`, `THUD`) with per-device capability detection.
- Falls back to short, amplitude-controlled effects on motors without composition primitives.
- Global continuous intensity slider combined with per-category continuous intensity sliders; nonlinear fine response at quiet strengths.
- Samples actual rain particles crossing the rendered screen boundary instead of an independent random timer. Only foreground; rain and thunder effects opt-in.
- Frequent cues are rate limited to reduce fatigue and battery drain. Manufacturer/actuator limitations mean comparative superiority over other devices cannot be guaranteed without real hardware studies.
