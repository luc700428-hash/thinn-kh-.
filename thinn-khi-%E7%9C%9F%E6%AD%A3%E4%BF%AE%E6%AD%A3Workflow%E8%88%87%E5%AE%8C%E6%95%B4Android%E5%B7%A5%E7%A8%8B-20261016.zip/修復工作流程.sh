#!/usr/bin/env bash
# Apply only the verified fallback workflow. Does not publish a GitHub Release.
set -euo pipefail
REPO='luc700428-hash/thinn-kh-.'
BASE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKFLOW="$BASE/.github/workflows/build-apk.yml"
[[ -s "$WORKFLOW" ]] || WORKFLOW="$BASE/build-apk.yml"
[[ -s "$WORKFLOW" ]] || { echo '找不到已修正的 build-apk.yml' >&2; exit 1; }
command -v gh >/dev/null || { echo '缺少 gh：pkg install gh git -y' >&2; exit 1; }
command -v git >/dev/null || { echo '缺少 git：pkg install gh git -y' >&2; exit 1; }
gh auth status >/dev/null || { echo '請先執行 gh auth login' >&2; exit 1; }
gh auth setup-git >/dev/null
WORK="$(mktemp -d "${TMPDIR:-$HOME}/thinn-ci-fix-XXXXXX")"
trap 'rm -rf "$WORK"' EXIT
gh repo clone "$REPO" "$WORK/repo" -- --depth 1
cd "$WORK/repo"
[[ "$(git branch --show-current)" == main ]] || { echo 'main 分支不存在，為安全起見停止' >&2; exit 1; }
mkdir -p .github/workflows
cp "$WORKFLOW" .github/workflows/build-apk.yml
git add .github/workflows/build-apk.yml
if git diff --cached --quiet; then
  echo 'GitHub 已有相同的工作流程，沒有其他變更。'
else
  git -c user.name='thinn-khi CI repair' -c user.email='ci-repair@users.noreply.github.com' \
    commit -m 'fix(ci): restore verified bundled Android source before building'
  git push origin HEAD:main
  echo '已推送：新版工作流程會自動觸發測試建置（不會發布正式 OTA）。'
fi
printf '\nGitHub Actions：https://github.com/%s/actions\n' "$REPO"
gh run list --repo "$REPO" --workflow build-apk.yml --limit 3 || true
