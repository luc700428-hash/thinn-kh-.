# thinn-khì — GitHub Actions 修正版（2026-10-16）

**這份修復針對實際出錯的 GitHub Actions #115：`Verify tracked Android source` exit code 1。** 不是高精度 3D 地標完成版，也不是已簽署的可安裝 APK。

## 已查證根因

- GitHub 儲存庫：`luc700428-hash/thinn-kh-.`，`main` 在檢查時沒有 `android-project/` 資料夾。
- 已上傳完整工程 ZIP；其 Git Blob SHA 為 `d28451d86ea26c90c78c26d0c6da4afae5581851`，與本地檔案一致。
- 原始建置工作流程要從 `android-project/` 讀取 Kotlin，因此一開始就失敗，沒有嘗試編譯 APK。
- 之前的綠色 CI 是使用舊版 V22 ZIP 建置，**不能代表新功能已安裝**。

## 這次實際修改

`.github/workflows/build-apk.yml` 先判斷儲存庫是否已追蹤 `android-project/`。有就用它；沒有就從已上傳的完整工程 ZIP 找出**唯一 SHA-256 完全相符**的檔案，驗證 ZIP、安全檢查路徑，再只解出 `android-project/`，並進行原本的原始碼檢查、Python / Node 測試、Gradle、簽章、與上一版憑證核對和正式 OTA 流程。檔名採百分號編碼也可處理。

已存在的完整工程 ZIP SHA-256 必須為：
`f0893f77cf0ce6760f2bf4646d8d8b8038534a49b16ae1a19ffd90d362382a01`

這是**相容性過渡方案**，避免 GitHub 網頁只上傳 ZIP 而無法立即建置。最終仍建議將原始碼檔案本身正式提交 Git 追蹤，因為這樣才有逐檔差異與審查能力。

## 檔案

- **`build-apk.yml`**：可直接取代 GitHub 的 `.github/workflows/build-apk.yml`。
- **`.github/workflows/build-apk.yml`**：同一份 YAML，保留正確儲存庫相對路徑。
- **`android-project/`**：包含先前整合的完整候選 Android 工程，可在電腦開啟編修。
- **`修復工作流程.sh`**：Termux 上傳 *一個* YAML 檔的輔助腳本；不自動發布 OTA。

## 最少操作

若你使用 GitHub 網頁，開啟 `luc700428-hash/thinn-kh-.` → `.github/workflows/build-apk.yml` → 編輯，將本包 `build-apk.yml` 的**全部內容**貼上並提交到 `main`。這將觸發一次非正式發布建置。

若使用 Termux，將**整包 ZIP 解壓**後，在其根目錄執行 `bash 修復工作流程.sh`。需先有 `gh`、`git` 和已登入 GitHub。

## 本地驗證（已實際執行）

1. 模擬 GitHub checkout 缺少 `android-project/`，只保留舊的完整工程 ZIP；新的解壓步驟成功。
2. 解壓後 `Verify ... Android project files` 所有檢查成功。
3. `python3 -m unittest discover -s android-project/tools/tests -p 'test_*.py' -v`：**36/36 通過**。
4. `node --test android-project/backend/tests/*.test.cjs`：**7/7 通過**。
5. YAML 解析、Bash 靜態語法與 ZIP 內容完整性通過。

## 尚未完成的部分 — 務必區分

- **尚未**完成 Android SDK/Gradle APK 完整編譯；可能仍有 Kotlin/Compose 編譯問題。CI 解決原始碼缺失後才能知道。
- **尚未**由此環境推送 GitHub。連接器的寫入操作回傳 403。
- **尚未**正式簽署發布新 OTA，也沒有新安裝包供手機直接安裝。
- **尚未**完成你聊天室全部需求；高精度微縮 3D、全頁面實機驗收和部分外部服務仍待製作與測試。

**標準是 CI 成功編譯真正的新程式、APK 記錄原始碼指紋，手機安裝後功能改變，才叫做完成更新。**
