package io.atmos.weather.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import kotlin.math.roundToInt
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import io.atmos.weather.presentation.home.WeatherAppearance
import kotlin.math.roundToInt

/** Foundation-first controls inspired by MIT-licensed iOS27 design tokens.
 * The supplied liquid-glass SVG/CSS displacement effect is WEB-only; this native
 * Android implementation uses gradients, light edges, high contrast and touch tracking.
 * Does not claim Apple native material rendering.
 */
private val ink = Color.White
private val mist = Color.White.copy(alpha=.76f)
private val shell = RoundedCornerShape(34.dp)

@Composable
fun GlassSurface(modifier: Modifier=Modifier, content: @Composable ColumnScope.() -> Unit) {
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered=true }
    val appearance by animateFloatAsState(if(entered) 1f else .96f,
        animationSpec=tween(280),label="玻璃卡片入場")
    Column(modifier.graphicsLayer { scaleX=appearance;scaleY=appearance;alpha=appearance }
        .clip(shell)
        .background(Brush.linearGradient(listOf(Color(0x665E8EA9),Color(0x53314D6B),Color(0x86314661))))
        .border(1.2.dp,Brush.linearGradient(listOf(Color(0xC8FFFFFF),Color(0x44FFFFFF),Color(0x88AEEBFF))),shell)
        .padding(18.dp), content = content)
}

@Composable
fun GlassAction(title: String, subtitle: String = "", modifier: Modifier=Modifier, onClick: () -> Unit) {
    val interaction=remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if(pressed).965f else 1f,
        animationSpec=spring(dampingRatio=.72f,stiffness=440f),label="玻璃選項按下")
    Column(modifier.fillMaxWidth().graphicsLayer { scaleX=scale;scaleY=scale }.clip(RoundedCornerShape(22.dp))
        .background(Color.White.copy(alpha=.12f))
        .border(1.dp,Color.White.copy(alpha=.23f),RoundedCornerShape(22.dp))
        .clickable(interactionSource=interaction,indication=null,onClick=onClick)
        .padding(horizontal=17.dp,vertical=15.dp)) {
        Text(title,color=ink,fontSize=16.sp,fontWeight=FontWeight.SemiBold)
        if(subtitle.isNotBlank()) Text(subtitle,color=mist,fontSize=12.sp,lineHeight=17.sp)
    }
}

@Composable
fun GlassToggle(label:String, description:String, value:Boolean, change:(Boolean)->Unit) {
    Row(Modifier.fillMaxWidth().clickable{change(!value)}.padding(vertical=11.dp),
        verticalAlignment=Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label,color=ink,fontSize=15.sp,fontWeight=FontWeight.Medium)
            Text(description,color=mist,fontSize=11.sp)
        }
        Box(Modifier.size(width=52.dp,height=30.dp).clip(CircleShape)
            .background(if(value) Color(0xFF53D5A4) else Color.White.copy(alpha=.28f)),
            contentAlignment=if(value)Alignment.CenterEnd else Alignment.CenterStart) {
            Box(Modifier.padding(3.dp).size(24.dp).background(Color.White,CircleShape))
        }
    }
}

@Composable
fun GlassTrackingSlider(title:String, value:Float, change:(Float)->Unit) {
    val bounded=value.coerceIn(0f,1f)
    Column(Modifier.fillMaxWidth().padding(vertical=9.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text(title,color=ink,fontSize=14.sp)
            Text("${(bounded*100f).roundToInt()}%",color=mist,fontSize=13.sp)
        }
        Spacer(Modifier.height(10.dp))
        Canvas(Modifier.fillMaxWidth().height(36.dp)
            .pointerInput(change) {
                detectTapGestures { point -> change((point.x/size.width).coerceIn(0f,1f)) }
            }
            .pointerInput(change) {
                detectDragGestures(onDragStart={pos->change((pos.x/size.width).coerceIn(0f,1f))}) { event, _ ->
                    change((event.position.x/size.width).coerceIn(0f,1f));event.consume()
                }
            }) {
            val center=size.height/2f
            drawLine(Color.White.copy(alpha=.24f),Offset(9f,center),Offset(size.width-9f,center),12f)
            drawLine(Color(0xFF95E2FF),Offset(9f,center),Offset(9f+(size.width-18f)*bounded,center),12f)
            drawCircle(Color(0xFFC5F4FF),13.dp.toPx(),Offset(9f+(size.width-18f)*bounded,center))
            drawCircle(Color.White.copy(alpha=.65f),13.dp.toPx(),Offset(9f+(size.width-18f)*bounded,center),style=Stroke(1.dp.toPx()))
        }
    }
}

/** A real draggable glass tab capsule. Swipes across page content are handled by HorizontalPager. */
@Composable
fun AppGlassNavigation(selected:Int, onSelect:(Int)->Unit, modifier:Modifier=Modifier) {
    val items=listOf("天氣" to "☀", "地震" to "◎", "工具" to "◇", "設定" to "⚙")
    var dragging by remember { mutableFloatStateOf(0f) }
    val selectedPosition by animateFloatAsState(
        targetValue=selected.coerceIn(0,3).toFloat(),
        animationSpec=spring(dampingRatio=.78f,stiffness=380f),label="玻璃分頁滑動")
    val density=LocalDensity.current
    BoxWithConstraints(modifier.fillMaxWidth().padding(horizontal=18.dp)) {
        val cellWidth=(maxWidth-10.dp)/4
        val cellPx=with(density) { cellWidth.toPx() }
        Box(Modifier.fillMaxWidth().height(68.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(Brush.verticalGradient(listOf(Color(0xE56E93B0),Color(0xD90A2442))))
            .border(1.2.dp,Brush.linearGradient(listOf(Color.White.copy(alpha=.73f),Color.White.copy(alpha=.09f),Color(0xFF94CEEE).copy(alpha=.40f))),RoundedCornerShape(32.dp))
            .pointerInput(cellPx,selected,onSelect) {
                detectHorizontalDragGestures(
                    onDragEnd={
                        val next=(selected+dragging/cellPx).roundToInt().coerceIn(0,3)
                        dragging=0f
                        if(next!=selected) onSelect(next)
                    },
                    onDragCancel={dragging=0f}
                ) { change,dx ->
                    dragging=(dragging+dx).coerceIn(-selected*cellPx,(3-selected)*cellPx)
                    change.consume()
                }
            }) {
            Box(Modifier.padding(5.dp).width(cellWidth).fillMaxHeight()
                .graphicsLayer { translationX=cellPx*selectedPosition+dragging }
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(Color(0xA6C2EAF8),Color(0x5A6BB3D9),Color(0x82517BA3))))
                .border(1.dp,Color.White.copy(alpha=.62f),RoundedCornerShape(28.dp)))
            Row(Modifier.fillMaxSize().padding(horizontal=5.dp),verticalAlignment=Alignment.CenterVertically) {
                items.forEachIndexed { index, entry ->
                    Column(Modifier.weight(1f).fillMaxHeight()
                        .clip(RoundedCornerShape(26.dp))
                        .clickable { onSelect(index) },
                        verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally) {
                        Text(entry.second,fontSize=21.sp,color=if(selected==index) Color.White else mist)
                        Text(entry.first,fontSize=12.sp,fontWeight=if(selected==index)FontWeight.Bold else FontWeight.Medium,
                            color=ink)
                    }
                }
            }
        }
    }
}

@Composable
fun AppGlassToolsPage(onBriefings:()->Unit,onUpdates:()->Unit,onDiagnostics:()->Unit,onSeismic:()->Unit) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF081A33),Color(0xFF174467))))
        .verticalScroll(rememberScrollState()).padding(start=20.dp,end=20.dp,top=58.dp,bottom=118.dp)) {
        Text("工具中心",fontSize=32.sp,fontWeight=FontWeight.Bold,color=ink)
        Text("功能入口與偏好設定分開呈現",fontSize=13.sp,color=mist)
        Spacer(Modifier.height(26.dp))
        GlassSurface {
            GlassAction("智慧天氣定時提醒", "最多五組星期、時間與專屬天氣建議",onClick=onBriefings)
            Spacer(Modifier.height(12.dp))
            GlassAction("臺灣地震監測", "EEW、TREM-Net 測站與歷史事件",onClick=onSeismic)
            Spacer(Modifier.height(12.dp))
            GlassAction("檢查版本更新", "安全 OTA、目前版本及完整更新紀錄",onClick=onUpdates)
            Spacer(Modifier.height(12.dp))
            GlassAction("設定健康檢查", "通知、定位、排程及背景限制診斷",onClick=onDiagnostics)
        }
        Spacer(Modifier.height(18.dp))
        Text("重大地震資訊請以中央氣象署正式公告及手機災防告警為準。",color=mist,fontSize=12.sp)
    }
}

@Composable
fun AppGlassSettingsPage(appearance:WeatherAppearance,onAppearance:(WeatherAppearance)->Unit,
    automaticUpdates:Boolean,onUpdates:(Boolean)->Unit,onAdvanced:()->Unit,onDiagnostics:()->Unit) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A213D),Color(0xFF235B80))))
        .verticalScroll(rememberScrollState()).padding(start=20.dp,end=20.dp,top=58.dp,bottom=118.dp)) {
        Text("個人化設定",color=ink,fontSize=32.sp,fontWeight=FontWeight.Bold)
        Text("每一項設定都有實際功能；系統不支援時會顯示限制",color=mist,fontSize=13.sp)
        Spacer(Modifier.height(25.dp))
        GlassSurface {
            Text("Liquid Glass · 介面效果",color=ink,fontSize=18.sp,fontWeight=FontWeight.Bold)
            Text("跟手滑桿 · 高光與半透明材質",color=mist,fontSize=12.sp)
            Spacer(Modifier.height(9.dp))
            GlassTrackingSlider("玻璃透明感",appearance.glassOpacity){onAppearance(appearance.copy(glassOpacity=it))}
            GlassTrackingSlider("玻璃霧化",appearance.glassFrost){onAppearance(appearance.copy(glassFrost=it))}
            GlassTrackingSlider("邊緣光效",appearance.edgeLight){onAppearance(appearance.copy(edgeLight=it))}
            GlassTrackingSlider("流動速度",appearance.liquidMotion){onAppearance(appearance.copy(liquidMotion=it))}
        }
        Spacer(Modifier.height(15.dp))
        GlassSurface {
            GlassToggle("自動檢查版本更新","允許 Android 定期安排版本檢查；實際時間可能延遲",automaticUpdates,onUpdates)
            Spacer(Modifier.height(11.dp))
            GlassAction("完整外觀、環境音與觸覺設定", "進階控制、8 款通知音及演練",onClick=onAdvanced)
            Spacer(Modifier.height(12.dp))
            GlassAction("檢查設定是否生效", "確認通知權限與背景工作",onClick=onDiagnostics)
        }
        Spacer(Modifier.height(17.dp))
        Text("此介面為 Android 原生 Compose 仿 iOS 27 設計語彙；不使用 Apple 私有的 UI 程式庫。",color=mist,fontSize=11.sp)
    }
}
