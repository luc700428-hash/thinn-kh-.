package io.atmos.weather.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.SliderColors
import androidx.compose.material3.SwitchColors
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

// MIT iOS-inspired dimensions; independently authored Compose implementation.
// Core controls are Foundation-only; Android system menus/notifications remain OS-owned.
private val edge=Brush.linearGradient(listOf(Color.White.copy(alpha=.72f),Color.White.copy(alpha=.08f),Color(0xFF86DBFB).copy(alpha=.46f)))

@Composable
private fun GlassPill(onClick:()->Unit, modifier:Modifier, enabled:Boolean,
    padding:PaddingValues, outlined:Boolean, content:@Composable RowScope.()->Unit) {
    val corner=RoundedCornerShape(24.dp)
    val interaction=remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    var entered by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entered=true }
    val pressScale by animateFloatAsState(if(pressed) .945f else 1f,
        animationSpec=spring(dampingRatio=.68f,stiffness=490f),label="玻璃按鈕回彈")
    val appear by animateFloatAsState(if(entered) 1f else .94f,
        animationSpec=tween(220),label="玻璃按鈕入場")
    val fill=if(outlined) listOf(Color(0x365A86A7),Color(0x3855819A)) else listOf(Color(0x994A93B2),Color(0xA92A5179))
    Row(modifier.defaultMinSize(minHeight=44.dp)
        .graphicsLayer { scaleX=pressScale*appear;scaleY=pressScale*appear;alpha=appear }
        .clip(corner)
        .background(Brush.linearGradient(fill))
        .border(1.dp,edge,corner)
        .clickable(interactionSource=interaction,indication=null,enabled=enabled,onClick=onClick)
        .padding(padding), horizontalArrangement=Arrangement.Center,verticalAlignment=Alignment.CenterVertically,
        content=content)
}

@Composable
fun GlassButton(onClick:()->Unit,modifier:Modifier=Modifier,enabled:Boolean=true,
    contentPadding:PaddingValues=PaddingValues(horizontal=18.dp,vertical=10.dp),
    colors:ButtonColors?=null,border:androidx.compose.foundation.BorderStroke?=null,
    content:@Composable RowScope.()->Unit) {
    GlassPill(onClick,modifier,enabled,contentPadding,false,content)
}

@Composable
fun GlassOutlinedButton(onClick:()->Unit,modifier:Modifier=Modifier,enabled:Boolean=true,
    contentPadding:PaddingValues=PaddingValues(horizontal=18.dp,vertical=10.dp),
    border:androidx.compose.foundation.BorderStroke?=null,
    colors:ButtonColors?=null,content:@Composable RowScope.()->Unit) {
    GlassPill(onClick,modifier,enabled,contentPadding,true,content)
}

@Composable
fun GlassTextButton(onClick:()->Unit,modifier:Modifier=Modifier,enabled:Boolean=true,
    contentPadding:PaddingValues=PaddingValues(horizontal=11.dp,vertical=9.dp),
    content:@Composable RowScope.()->Unit) {
    GlassPill(onClick,modifier,enabled,contentPadding,true,content)
}

@Composable
fun GlassIconButton(onClick:()->Unit,modifier:Modifier=Modifier,enabled:Boolean=true,
    content:@Composable ()->Unit) {
    val interaction=remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if(pressed).91f else 1f,
        animationSpec=spring(dampingRatio=.65f,stiffness=420f),label="玻璃圖示按鈕回彈")
    Box(modifier.defaultMinSize(44.dp,44.dp)
        .graphicsLayer { scaleX=scale;scaleY=scale }
        .clip(CircleShape)
        .background(Color.White.copy(alpha=.11f))
        .border(1.dp,Color.White.copy(alpha=.25f),CircleShape)
        .clickable(interactionSource=interaction,indication=null,enabled=enabled,onClick=onClick),contentAlignment=Alignment.Center){ content() }
}

@Composable
fun GlassSwitch(checked:Boolean,onCheckedChange:((Boolean)->Unit)?,modifier:Modifier=Modifier,
    enabled:Boolean=true,colors:SwitchColors?=null) {
    val pos by animateFloatAsState(if(checked) 1f else 0f,
        animationSpec=spring(dampingRatio=.72f,stiffness=350f),label="玻璃開關回彈")
    var drag by remember { mutableFloatStateOf(0f) }
    Canvas(modifier.size(54.dp,32.dp)
        .pointerInput(checked,enabled,onCheckedChange) {
            detectTapGestures { if(enabled) onCheckedChange?.invoke(!checked) }
        }
        .pointerInput(checked,enabled,onCheckedChange) {
            detectDragGestures(onDragStart={drag=0f},onDragEnd={
                if(enabled && kotlin.math.abs(drag)>6.dp.toPx())
                    onCheckedChange?.invoke(drag>0f)
                drag=0f
            }) { event,amount ->
                if(enabled) { drag+=amount.x;event.consume() }
            }
        }) {
        val radius=size.height/2f
        drawRoundRect(if(checked)Color(0xFF30B9C5) else Color(0x996F8499),
            cornerRadius=androidx.compose.ui.geometry.CornerRadius(radius,radius))
        drawRoundRect(Color.White.copy(alpha=.37f),
            cornerRadius=androidx.compose.ui.geometry.CornerRadius(radius,radius),style=Stroke(1.dp.toPx()))
        val x=radius+(size.width-size.height)*pos
        drawCircle(Color.White, radius-4.dp.toPx(),Offset(x,radius))
    }
}

@Composable
fun GlassSlider(value:Float,onValueChange:(Float)->Unit,modifier:Modifier=Modifier,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f, steps:Int=0,
    onValueChangeFinished:(()->Unit)?=null, colors:SliderColors?=null,enabled:Boolean=true) {
    val delta=(valueRange.endInclusive-valueRange.start).coerceAtLeast(.00001f)
    val fraction=((value-valueRange.start)/delta).coerceIn(0f,1f)
    fun update(f:Float) {
        val normalized=f.coerceIn(0f,1f)
        val snapped=if(steps>0) kotlin.math.round(normalized*(steps+1))/(steps+1) else normalized
        onValueChange(valueRange.start+delta*snapped)
    }
    Canvas(modifier.fillMaxWidth().height(42.dp)
        .pointerInput(enabled,valueRange,steps) {
            detectTapGestures { offset -> if(enabled) {update(offset.x/size.width);onValueChangeFinished?.invoke()} }
        }
        .pointerInput(enabled,valueRange,steps) {
            detectDragGestures(onDragEnd={onValueChangeFinished?.invoke()},onDragStart={pos->if(enabled) update(pos.x/size.width)}) {event,_->
                if(enabled) {update(event.position.x/size.width);event.consume()}
            }
        }) {
        val y=size.height/2f
        val pad=16.dp.toPx()
        val track=(size.width-2*pad).coerceAtLeast(1f)
        drawLine(Color(0x889FB6C7),Offset(pad,y),Offset(size.width-pad,y),9.dp.toPx())
        drawLine(Color(0xFF7AD4F4),Offset(pad,y),Offset(pad+fraction*track,y),9.dp.toPx())
        drawCircle(Color.White,12.dp.toPx(),Offset(pad+fraction*track,y))
        drawCircle(Color(0xA83FC9EE),12.dp.toPx(),Offset(pad+fraction*track,y),style=Stroke(1.dp.toPx()))
    }
}
