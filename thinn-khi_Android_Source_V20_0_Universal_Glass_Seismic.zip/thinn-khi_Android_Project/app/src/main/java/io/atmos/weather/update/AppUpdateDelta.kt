package io.atmos.weather.update

import io.atmos.weather.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

/** Delta-only release notes. Do not present a cumulative history as new features.
 * A release without a dedicated incremental block is reported as undocumented.
 */
object AppUpdateDelta {
    const val MARKER = "<!-- THINN_INCREMENTAL_CHANGES -->"

    internal fun version(value: String): List<Int> = value.trim().removePrefix("v")
        .split('.').map { it.takeWhile(Char::isDigit).toIntOrNull() ?: 0 }

    internal fun compare(a: String, b: String): Int {
        val left=version(a); val right=version(b)
        for (index in 0 until maxOf(left.size,right.size)) {
            val difference=left.getOrElse(index){0}.compareTo(right.getOrElse(index){0})
            if (difference!=0) return difference
        }
        return 0
    }

    internal fun changes(notes: String): List<String>? {
        val start=notes.indexOf(MARKER)
        if(start<0) return null
        val block=notes.substring(start+MARKER.length)
            .substringBefore("<!-- END_THINN_INCREMENTAL_CHANGES -->")
        return block.lineSequence().map { it.trim() }
            .filter { it.startsWith("- ") }.map { it.removePrefix("- ").replace("**", "") }
            .filter(String::isNotBlank).take(8).toList()
    }

    suspend fun describe(installed: String, latest: ReleaseInfo): String = withContext(Dispatchers.IO) {
        val releases=try {
            val url=URL("https://api.github.com/repos/luc700428-hash/thinn-kh-./releases?per_page=50")
            val conn=url.openConnection() as HttpURLConnection
            conn.connectTimeout=10000;conn.readTimeout=12000
            conn.setRequestProperty("Accept","application/vnd.github+json")
            try { JSONArray(conn.inputStream.bufferedReader().use { it.readText().take(1500000) }) }
            finally { conn.disconnect() }
        } catch (_: Exception) { JSONArray() }
        val matched=mutableListOf<Pair<String,String>>()
        for(i in 0 until releases.length()) {
            val item=releases.optJSONObject(i) ?: continue
            if (item.optBoolean("draft") || item.optBoolean("prerelease")) continue
            val tag=item.optString("tag_name")
            if (compare(tag,installed)>0 && compare(tag,latest.version)<=0)
                matched.add(tag to item.optString("body"))
        }
        if(matched.none { compare(it.first,latest.version)==0 })
            matched.add(latest.version to latest.notes)
        if(matched.isEmpty()) return@withContext "目前版本 $installed → ${latest.version}：尚無可用的差異紀錄。"
        val output=mutableListOf("$installed → ${latest.version}")
        matched.sortedWith { a,b -> compare(a.first,b.first) }.forEach { (tag,body) ->
            output.add("## $tag")
            val details=changes(body)
            if(details.isNullOrEmpty()) output.add("- 此版未提供獨立的新增／修復清單。")
            else details.forEach { output.add("- $it") }
        }
        output.joinToString("\n")
    }
}
