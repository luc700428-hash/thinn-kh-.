package io.atmos.weather.permission

import io.atmos.weather.ui.GlassButton as Button
import androidx.compose.animation.core.*
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import kotlinx.coroutines.delay
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import io.atmos.weather.R

/** First run explanation BEFORE system dialogs. All prompts are optional and requested once. */
@Composable
fun FirstRunGuide(onContinue: () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(160); visible=true }
    val animated=rememberInfiniteTransition(label="onboarding gentle logo")
    val pulse by animated.animateFloat(0.96f,1.035f,infiniteRepeatable(tween(2400,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="logo breath")
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06172B),Color(0xFF104275),Color(0xFF166FBA))))
        .verticalScroll(rememberScrollState()).padding(horizontal=28.dp,vertical=42.dp),
        horizontalAlignment=Alignment.CenterHorizontally) {
        Spacer(Modifier.height(34.dp))
        Box(Modifier.size(152.dp).background(Brush.radialGradient(listOf(Color.White.copy(alpha=.15f),Color.Transparent))),contentAlignment=Alignment.Center) {
            Image(painterResource(R.drawable.brand_symbol),"thinn-khì",Modifier.size(124.dp).scale(pulse))
        }
        Spacer(Modifier.height(18.dp))
        Text("thinn-khì",color=Color.White,fontSize=31.sp,fontWeight=FontWeight.Bold)
        Text("你的天氣，從所在的地方開始",color=Color.White.copy(alpha=.8f),fontSize=15.sp)
        Spacer(Modifier.height(32.dp))
        AnimatedVisibility(visible=visible,
            enter=fadeIn(tween(600)) + slideInVertically(animationSpec=tween(650)) { it/9 }) {
          Column {
        FirstRunFeature(Icons.Rounded.LocationOn,"位置資訊","取得當地預報與地名；不授權仍可搜尋城市。")
        Spacer(Modifier.height(12.dp))
        FirstRunFeature(Icons.Rounded.NotificationsActive,"天氣警特報通知","在你允許後提示符合條件的官方天氣警特報。")
        Spacer(Modifier.height(12.dp))
        FirstRunFeature(Icons.Rounded.BatteryChargingFull,"背景更新說明","可自行調整省電策略；不保證即時通知。")
          }
        }
        Spacer(Modifier.height(28.dp))
        Button(onClick=onContinue,modifier=Modifier.fillMaxWidth().height(56.dp),
            colors=ButtonDefaults.buttonColors(containerColor=Color(0xFF2B9CF4))) {
            Text("開始使用 · 選擇權限",fontSize=16.sp,fontWeight=FontWeight.SemiBold)
        }
        Spacer(Modifier.height(12.dp))
        Text("所有權限可拒絕；之後仍能在系統設定中重新授權。",
            color=Color.White.copy(alpha=.75f),fontSize=12.sp,textAlign=TextAlign.Center)
    }
}
@Composable
private fun FirstRunFeature(icon:androidx.compose.ui.graphics.vector.ImageVector,title:String,detail:String) {
    Row(Modifier.fillMaxWidth().background(Color.White.copy(alpha=.10f),RoundedCornerShape(22.dp))
        .border(1.dp,Color.White.copy(alpha=.18f),RoundedCornerShape(22.dp)).padding(16.dp),
        verticalAlignment=Alignment.CenterVertically) {
        Icon(icon,contentDescription=null,tint=Color(0xFFB7E9FF),modifier=Modifier.size(27.dp))
        Spacer(Modifier.width(13.dp))
        Column {Text(title,color=Color.White,fontSize=15.sp,fontWeight=FontWeight.SemiBold)
            Text(detail,color=Color.White.copy(alpha=.8f),fontSize=12.sp,lineHeight=18.sp)}
    }
}
