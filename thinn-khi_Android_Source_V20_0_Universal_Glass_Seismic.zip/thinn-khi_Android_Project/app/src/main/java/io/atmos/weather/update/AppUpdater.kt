package io.atmos.weather.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import io.atmos.weather.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Github Releases self-update for the sideloaded edition, with SHA256 verification.
 * A release must be signed by the SAME key as the installed APK; Android enforces that on install.
 * No silent installation is attempted or permitted.
 */
data class ReleaseInfo(val version:String,val notes:String,val url:String,val sha256:String)
object AppUpdater {
    private const val api="https://api.github.com/repos/luc700428-hash/thinn-kh-./releases/latest"
    private fun newer(latest:String, installed:String):Boolean {
        val a=latest.removePrefix("v").split('.').map { it.takeWhile(Char::isDigit).toIntOrNull() ?: 0 }
        val b=installed.removePrefix("v").split('.').map { it.takeWhile(Char::isDigit).toIntOrNull() ?: 0 }
        for(i in 0 until maxOf(a.size,b.size)) {
            val left=a.getOrElse(i){0};val right=b.getOrElse(i){0}
            if(left!=right) return left>right
        }
        return false
    }
    suspend fun findUpdate(context:Context):ReleaseInfo?=withContext(Dispatchers.IO) {
        val conn=(URL(api).openConnection() as HttpURLConnection)
        conn.setRequestProperty("Accept","application/vnd.github+json")
        conn.connectTimeout=12000;conn.readTimeout=15000
        val json=try {JSONObject(conn.inputStream.bufferedReader().use{it.readText()})}finally{conn.disconnect()}
        val version=json.optString("tag_name")
        if(!newer(version,BuildConfig.VERSION_NAME)) return@withContext null
        val assets=json.getJSONArray("assets")
        for(i in 0 until assets.length()) {
            val entry=assets.getJSONObject(i)
            if(entry.optString("name") == "thinn-khi.apk") {
                val digest=entry.optString("digest").removePrefix("sha256:")
                val url=entry.getString("browser_download_url")
                require(url.startsWith("https://github.com/")) { "不受信任的下載來源" }
                // Some GitHub releases expose a digest directly, others only the uploaded .sha256 asset.
                val expectedSha = if (digest.matches(Regex("[A-Fa-f0-9]{64}"))) digest else {
                    var checksumUrl: String? = null
                    for (j in 0 until assets.length()) {
                        val other = assets.getJSONObject(j)
                        if (other.optString("name") == "thinn-khi.apk.sha256") {
                            checksumUrl = other.optString("browser_download_url")
                            break
                        }
                    }
                    val safeUrl = requireNotNull(checksumUrl) { "正式版本未提供 APK SHA-256 驗證檔" }
                    require(safeUrl.startsWith("https://github.com/")) { "驗證檔來源不受信任" }
                    val checkConn = URL(safeUrl).openConnection() as HttpURLConnection
                    checkConn.connectTimeout=12000; checkConn.readTimeout=15000
                    val checkText=try { checkConn.inputStream.bufferedReader().use { it.readText() } }
                        finally { checkConn.disconnect() }
                    requireNotNull(Regex("""^([A-Fa-f0-9]{64})\s+\*?thinn-khi\.apk\s*$""")
                        .find(checkText.trim())?.groupValues?.get(1)) { "正式版本 SHA-256 格式不正確" }
                }
                return@withContext ReleaseInfo(version,json.optString("body"),url,expectedSha)
            }
        }
        error("此 Release 沒有 thinn-khi.apk 安裝檔")
    }
    suspend fun downloadAndInstall(
        context: Context,
        release: ReleaseInfo,
        onProgress: suspend (downloaded:Long,total:Long?)->Unit = { _, _ -> }
    )=withContext(Dispatchers.IO) {
        val target=File(context.cacheDir,"updates/thinn-khi.apk")
        target.parentFile?.mkdirs()
        val conn=(URL(release.url).openConnection() as HttpURLConnection)
        conn.instanceFollowRedirects=true;conn.connectTimeout=15000;conn.readTimeout=35000
        // GitHub redirects downloads to their CDN; require HTTPS before consuming bytes.
        try {
            val expected=conn.contentLengthLong.takeIf { it > 0L }
            conn.inputStream.use { input ->
                target.outputStream().use { output ->
                    val buffer=ByteArray(64*1024)
                    var received=0L
                    var lastNotify=0L
                    while(true) {
                        val n=input.read(buffer)
                        if(n < 0) break
                        output.write(buffer,0,n)
                        received+=n
                        if(received-lastNotify >= 256*1024 || (expected!=null && received>=expected)) {
                            lastNotify=received
                            withContext(Dispatchers.Main) {onProgress(received,expected)}
                        }
                    }
                    if(received == 0L) error("APK 下載內容為空")
                    withContext(Dispatchers.Main) {onProgress(received,expected)}
                }
            }
        } finally {conn.disconnect()}
        val md=MessageDigest.getInstance("SHA-256")
        target.inputStream().use { input ->
            val buffer=ByteArray(65536)
            while(true) {
                val n=input.read(buffer)
                if(n < 0) break
                md.update(buffer,0,n)
            }
        }
        val sha=md.digest().joinToString("") {"%02x".format(it.toInt() and 0xff)}
        if(!sha.equals(release.sha256,ignoreCase=true)) {
            target.delete()
            error("APK SHA-256 驗證失敗，不會安裝")
        }
        val pm=context.packageManager
        @Suppress("DEPRECATION")
        val packageInfo=requireNotNull(pm.getPackageArchiveInfo(target.path,android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES)) {
            "無法辨識下載 APK 的套件或簽章"
        }
        if(packageInfo.packageName != context.packageName) {
            target.delete(); error("APK 套件名稱不符，已取消更新")
        }
        @Suppress("DEPRECATION")
        val installed=pm.getPackageInfo(context.packageName,android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES)
        if (packageInfo.longVersionCode <= installed.longVersionCode) {
            target.delete()
            error("更新 APK 的版本號沒有高於已安裝版本，請重新發布遞增版號的 APK")
        }
        // Give a clear error before opening the installer when old cloud-built debug APKs have
        // different signing certificates. Without the original key Android cannot upgrade them.
        val currentCerts=installed.signingInfo?.apkContentsSigners?.map { signer ->
            MessageDigest.getInstance("SHA-256").digest(signer.toByteArray()).toList()
        }?.toSet()
        val updateCerts=packageInfo.signingInfo?.apkContentsSigners?.map { signer ->
            MessageDigest.getInstance("SHA-256").digest(signer.toByteArray()).toList()
        }?.toSet()
        if (currentCerts.isNullOrEmpty() || updateCerts.isNullOrEmpty() || currentCerts != updateCerts) {
            target.delete()
            error("此 APK 與目前已安裝版本的簽章不同，無法覆蓋。若之前裝的是使用不同金鑰的 Debug 版，請先備份資料，再換裝一次固定簽章正式版。")
        }
        if(android.os.Build.VERSION.SDK_INT>=26 && !pm.canRequestPackageInstalls()) {
            // Installation permission is user-controlled and granted separately.
            val intent=Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            withContext(Dispatchers.Main) { context.startActivity(intent) }
            error("請允許此 App 安裝更新後，再按一次下載並安裝")
        }
        val uri=FileProvider.getUriForFile(context,"${context.packageName}.update.files",target)
        val intent=Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        withContext(Dispatchers.Main) { context.startActivity(intent) }
    }
}
