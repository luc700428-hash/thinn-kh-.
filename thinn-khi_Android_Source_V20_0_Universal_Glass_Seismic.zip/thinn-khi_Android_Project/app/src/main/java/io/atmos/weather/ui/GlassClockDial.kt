package io.atmos.weather.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.roundToInt
import kotlin.math.PI

/** Original iOS-inspired touch-following 24-hour glass time dial.
 * Clock is a local editable component; no Material time picker or native OS dialog.
 */
@Composable
fun GlassClockDial(hour:Int,minute:Int,onHour:(Int)->Unit,onMinute:(Int)->Unit) {
    var selectingHour by remember { mutableStateOf(true) }
    val afternoon=hour>=12
    Column(horizontalAlignment=Alignment.CenterHorizontally) {
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
            GlassTextButton(onClick={selectingHour=true}) {
                Text("%02d".format(hour),fontSize=27.sp,fontWeight=FontWeight.Bold,color=if(selectingHour)Color(0xFF87EAFF) else Color.White)
            }
            Text(":",fontSize=26.sp,color=Color.White)
            GlassTextButton(onClick={selectingHour=false}) {
                Text("%02d".format(minute),fontSize=27.sp,fontWeight=FontWeight.Bold,color=if(!selectingHour)Color(0xFF87EAFF) else Color.White)
            }
        }
        Spacer(Modifier.height(6.dp))
        if(selectingHour) Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            GlassTextButton(onClick={if(afternoon) onHour(hour-12)}) {Text("上午 00–11",color=if(!afternoon)Color(0xFF87EAFF) else Color.White)}
            GlassTextButton(onClick={if(!afternoon) onHour(hour+12)}) {Text("下午 12–23",color=if(afternoon)Color(0xFF87EAFF) else Color.White)}
        }
        Spacer(Modifier.height(8.dp))
        fun update(point:Offset,size:androidx.compose.ui.unit.IntSize) {
            val deltaX=point.x-size.width/2f
            val deltaY=point.y-size.height/2f
            var angle=atan2(deltaY,deltaX)+PI.toFloat()/2f
            if(angle<0) angle+=(2*PI).toFloat()
            if(selectingHour) {
                val twelve=(angle/(2*PI)*12).roundToInt()%12
                onHour(twelve+if(afternoon)12 else 0)
            } else onMinute((angle/(2*PI)*60).roundToInt()%60)
        }
        val moving by animateFloatAsState(if(selectingHour)(hour%12).toFloat() else minute.toFloat(),
            animationSpec=spring(dampingRatio=.81f,stiffness=420f),label="錶盤指針")
        Canvas(Modifier.size(256.dp)
            .pointerInput(selectingHour,afternoon) { detectTapGestures {update(it,size)} }
            .pointerInput(selectingHour,afternoon) {detectDragGestures(onDragStart={update(it,size)}) {event,_->update(event.position,size);event.consume()}}) {
            val c=Offset(size.width/2f,size.height/2f)
            val r=size.minDimension*.46f
            drawCircle(Color(0x285A9ABB),r,c)
            drawCircle(Color.White.copy(alpha=.38f),r,c,style=Stroke(1.dp.toPx()))
            val active=if(selectingHour)hour%12 else minute
            val segments=if(selectingHour)12 else 60
            repeat(segments) {i->
                val a=2*PI*i/segments-PI/2
                val major=selectingHour || i%5==0
                val start=Offset(c.x+cos(a).toFloat()*r*(if(major).80f else .91f),c.y+sin(a).toFloat()*r*(if(major).80f else .91f))
                val end=Offset(c.x+cos(a).toFloat()*r*.96f,c.y+sin(a).toFloat()*r*.96f)
                drawLine(if(i==active)Color(0xFF83F1FF) else Color.White.copy(alpha=.65f),start,end,if(major)3.dp.toPx() else 1.dp.toPx())
            }
            val a=2*PI*moving/segments-PI/2
            val needle=Offset(c.x+cos(a).toFloat()*r*.66f,c.y+sin(a).toFloat()*r*.66f)
            drawLine(Color(0xFF85E2F9),c,needle,4.dp.toPx())
            drawCircle(Color(0xFF8CEBFF),12.dp.toPx(),needle)
            drawCircle(Color.White,5.dp.toPx(),c)
        }
        Text(if(selectingHour) "在錶盤滑動選擇小時" else "在錶盤滑動選擇分鐘",fontSize=12.sp,color=Color(0xFFCAE7F5))
    }
}
